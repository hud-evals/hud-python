# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Defines the Warp kernels used by the Proximal-ADMM solver."""

import functools
from typing import Any

import warp as wp

from ...core.math import FLOAT32_EPS, FLOAT32_MAX
from ...core.types import float32, int32, vec2f, vec3f
from .math import (
    compute_cwise_vec_div,
    compute_cwise_vec_mul,
    compute_desaxce_corrections,
    compute_dot_product,
    compute_double_dot_product,
    compute_gemv,
    compute_inverse_preconditioned_iterate_residual,
    compute_l2_norm,
    compute_ncp_complementarity_residual,
    compute_ncp_dual_residual,
    compute_ncp_natural_map_residual,
    compute_ncp_primal_residual,
    compute_preconditioned_iterate_residual,
    compute_vector_sum,
    project_to_coulomb_cone,
)
from .types import PADMMConfigStruct, PADMMPenalty, PADMMPenaltyUpdate, PADMMStatus

###
# Module interface
###

__all__ = [
    "_apply_dual_preconditioner_to_solution",
    "_apply_dual_preconditioner_to_state",
    "_compute_complementarity_residuals",
    "_compute_desaxce_correction",
    "_compute_final_desaxce_correction",
    "_compute_projection_argument",
    "_compute_projection_argument_and_project",
    "_compute_solution_vectors",
    "_compute_velocity_bias",
    "_make_compute_infnorm_residuals_accel_kernel",
    "_make_compute_infnorm_residuals_kernel",
    "_project_to_feasible_cone",
    "_reset_solver_data",
    "_update_acceleration_and_cache_previous",
    "_update_delassus_proximal_regularization",
    "_update_delassus_proximal_regularization_sparse",
    "_update_state_with_acceleration",
    "_warmstart_contact_constraints",
    "_warmstart_desaxce_correction",
    "_warmstart_joint_constraints",
    "_warmstart_limit_constraints",
    "make_collect_solver_info_kernel",
    "make_collect_solver_info_kernel_sparse",
    "make_desaxce_correction_and_velocity_bias_kernel",
    "make_initialize_solver_kernel",
    "make_update_dual_and_all_residuals",
    "make_update_dual_variables_and_compute_primal_dual_residuals",
    "make_update_proximal_regularization_kernel",
]


###
# Module configs
###

wp.set_module_options({"enable_backward": False})


###
# Kernels
###


@wp.kernel
def _reset_solver_data(
    # Outputs:
    world_mask: wp.array[int32],
    problem_vio: wp.array[int32],
    problem_maxdim: wp.array[int32],
    lambdas: wp.array[float32],
    v_plus: wp.array[float32],
):
    # Retrieve the world and constraint indices from the 2D thread grid
    wid, tid = wp.tid()

    # Retrieve the maximum number of constraints in the world
    maxncts = problem_maxdim[wid]

    # Skip operation if the world is masked out
    if world_mask[wid] == 0 or tid >= maxncts:
        return

    # Retrieve the index offset of the vector block of the world
    vio = problem_vio[wid]

    # Compute the index offset of the vector block of the world
    thread_offset = vio + tid

    # Reset the solver state variables to zero
    lambdas[thread_offset] = 0.0
    v_plus[thread_offset] = 0.0


@wp.kernel
def _warmstart_desaxce_correction(
    problem_nc: wp.array[int32],
    problem_cio: wp.array[int32],
    problem_ccgo: wp.array[int32],
    problem_vio: wp.array[int32],
    problem_mu: wp.array[float32],
    # Outputs:
    solver_z: wp.array[float32],
):
    # Retrieve the thread index
    wid, cid = wp.tid()

    # Retrieve the number of contact active in the world
    nc = problem_nc[wid]

    # Retrieve the limit constraint group offset of the world
    ccgo = problem_ccgo[wid]

    # Skip if row index exceed the problem size or if the solver has already converged
    if cid >= nc:
        return

    # Retrieve the index offset of the vector block of the world
    cio = problem_cio[wid]

    # Retrieve the index offset of the vector block of the world
    vio = problem_vio[wid]

    # Retrieve the friction coefficient for this contact
    mu = problem_mu[cio + cid]

    # Compute the vector index offset of the corresponding contact constraint
    ccio_k = vio + ccgo + 3 * cid

    # Compute the norm of the tangential components, where:
    #   s = G(v_plus)
    #   v_plus = z - s  =>  z = v_plus + s
    vtx = solver_z[ccio_k]
    vty = solver_z[ccio_k + 1]
    vn = solver_z[ccio_k + 2]
    vt_norm = wp.sqrt(vtx * vtx + vty * vty)

    # Store De Saxce correction for this block
    solver_z[ccio_k + 2] = vn + mu * vt_norm


@wp.kernel
def _warmstart_joint_constraints(
    # Inputs:
    model_time_dt: wp.array[float32],
    joint_wid: wp.array[int32],
    joint_num_dynamic_cts: wp.array[int32],
    joint_num_kinematic_cts: wp.array[int32],
    joint_dynamic_cts_offset_joint_cts: wp.array[int32],
    joint_kinematic_cts_offset_joint_cts: wp.array[int32],
    joint_dynamic_cts_offset_total_cts: wp.array[int32],
    joint_kinematic_cts_offset_total_cts: wp.array[int32],
    joint_lambda_j: wp.array[float32],
    problem_P: wp.array[float32],
    # Outputs:
    x_0: wp.array[float32],
    y_0: wp.array[float32],
    z_0: wp.array[float32],
):
    # Retrieve the thread index as the joint index
    jid = wp.tid()

    # Retrieve the joint-specific model info
    wid_j = joint_wid[jid]
    num_dynamic_cts_j = joint_num_dynamic_cts[jid]
    num_kinematic_cts_j = joint_num_kinematic_cts[jid]

    # Retrieve the world-specific info
    dt = model_time_dt[wid_j]

    # Retrieve offsets in the joint-only and total constraints vector
    joint_dyn_cts_start = joint_dynamic_cts_offset_joint_cts[jid]
    joint_kin_cts_start = joint_kinematic_cts_offset_joint_cts[jid]
    dyn_cts_row_start_j = joint_dynamic_cts_offset_total_cts[jid]
    kin_cts_row_start_j = joint_kinematic_cts_offset_total_cts[jid]

    # For each joint constraint, scale the constraint force by the time-step and
    # the preconditioner and initialize the solver state variables accordingly
    for j in range(num_dynamic_cts_j):
        P_j = problem_P[dyn_cts_row_start_j + j]
        lambda_j = (dt / P_j) * joint_lambda_j[joint_dyn_cts_start + j]
        x_0[dyn_cts_row_start_j + j] = lambda_j
        y_0[dyn_cts_row_start_j + j] = lambda_j
        z_0[dyn_cts_row_start_j + j] = 0.0
    for j in range(num_kinematic_cts_j):
        P_j = problem_P[kin_cts_row_start_j + j]
        lambda_j = (dt / P_j) * joint_lambda_j[joint_kin_cts_start + j]
        x_0[kin_cts_row_start_j + j] = lambda_j
        y_0[kin_cts_row_start_j + j] = lambda_j
        z_0[kin_cts_row_start_j + j] = 0.0


@wp.kernel
def _warmstart_limit_constraints(
    # Inputs:
    model_time_dt: wp.array[float32],
    model_info_total_cts_offset: wp.array[int32],
    data_info_limit_cts_group_offset: wp.array[int32],
    limit_model_num_active: wp.array[int32],
    limit_wid: wp.array[int32],
    limit_lid: wp.array[int32],
    limit_reaction: wp.array[float32],
    limit_velocity: wp.array[float32],
    problem_P: wp.array[float32],
    # Outputs:
    x_0: wp.array[float32],
    y_0: wp.array[float32],
    z_0: wp.array[float32],
):
    # Retrieve the thread index as the limit index
    lid = wp.tid()

    # Retrieve the number of limits active in the model
    model_nl = limit_model_num_active[0]

    # Skip if lid is greater than the number of limits active in the model
    if lid >= model_nl:
        return

    # Retrieve the limit-specific data
    wid = limit_wid[lid]
    lid_l = limit_lid[lid]
    lambda_l = limit_reaction[lid]
    v_plus_l = limit_velocity[lid]

    # Retrieve the world-specific info
    dt = model_time_dt[wid]
    total_cts_offset = model_info_total_cts_offset[wid]
    limit_cts_offset = data_info_limit_cts_group_offset[wid]

    # Compute block offsets of the limit constraints within
    # the limit-only constraints and total constraints arrays
    vio_l = total_cts_offset + limit_cts_offset + lid_l

    # Load the diagonal preconditioner for the limit constraints
    # NOTE: We only need to load the first element since by necessity
    # the preconditioner is constant across the 3 constraint dimensions
    P_l = problem_P[vio_l]

    # Scale the limit force by the time-step to
    # render an impulse and by the preconditioner
    lambda_l *= dt / P_l

    # Scale the limit velocity by the preconditioner
    v_plus_l *= P_l

    # Compute and store the limit-constraint reaction forces
    x_0[vio_l] = lambda_l
    y_0[vio_l] = lambda_l
    z_0[vio_l] = v_plus_l


@wp.kernel
def _warmstart_contact_constraints(
    # Inputs:
    model_time_dt: wp.array[float32],
    model_info_total_cts_offset: wp.array[int32],
    data_info_contact_cts_group_offset: wp.array[int32],
    contact_model_num_contacts: wp.array[int32],
    contact_wid: wp.array[int32],
    contact_cid: wp.array[int32],
    contact_material: wp.array[vec2f],
    contact_reaction: wp.array[vec3f],
    contact_velocity: wp.array[vec3f],
    problem_P: wp.array[float32],
    # Outputs:
    x_0: wp.array[float32],
    y_0: wp.array[float32],
    z_0: wp.array[float32],
):
    # Retrieve the thread index as the contact index
    cid = wp.tid()

    # Retrieve the number of contacts active in the model
    model_nc = contact_model_num_contacts[0]

    # Skip if cid is greater than the number of contacts active in the model
    if cid >= model_nc:
        return

    # Retrieve the contact-specific data
    wid = contact_wid[cid]
    cid_k = contact_cid[cid]
    material_k = contact_material[cid]
    lambda_k = contact_reaction[cid]
    v_plus_k = contact_velocity[cid]

    # Retrieve the world-specific info
    dt = model_time_dt[wid]
    total_cts_offset = model_info_total_cts_offset[wid]
    contact_cts_offset = data_info_contact_cts_group_offset[wid]

    # Compute block offsets of the contact constraints within
    # the contact-only constraints and total constraints arrays
    vio_k = total_cts_offset + contact_cts_offset + 3 * cid_k

    # Load the diagonal preconditioner for the contact constraints
    # NOTE: We only need to load the first element since by necessity
    # the preconditioner is constant across the 3 constraint dimensions
    P_k = problem_P[vio_k]

    # Scale the contact force by the time-step to
    # render an impulse and by the preconditioner
    lambda_k *= dt / P_k

    # Scale the contact velocity by the preconditioner
    # and apply the De Saxce correction to the post-event
    # contact velocity to render solver dual variables
    v_plus_k *= P_k
    mu_k = material_k[0]
    vt_norm = wp.sqrt(v_plus_k.x * v_plus_k.x + v_plus_k.y * v_plus_k.y)
    v_plus_k.z += mu_k * vt_norm

    # Compute and store the contact-constraint reaction forces
    for k in range(3):
        x_0[vio_k + k] = lambda_k[k]
    for k in range(3):
        y_0[vio_k + k] = lambda_k[k]
    for k in range(3):
        z_0[vio_k + k] = v_plus_k[k]


def make_initialize_solver_kernel(use_acceleration: bool = False):
    """
    Creates a kernel to initialize the PADMM solver state, status, and penalty parameters.

    Specialized for whether acceleration is enabled to reduce unnecessary overhead and branching.

    Args:
        use_acceleration (bool, optional): Flag indicating whether acceleration is enabled. Defaults to False.

    Returns:
        wp.kernel: The kernel function to initialize the PADMM solver.
    """

    @wp.kernel
    def _initialize_solver(
        # Inputs:
        solver_config: wp.array[PADMMConfigStruct],
        # Outputs:
        solver_status: wp.array[PADMMStatus],
        solver_penalty: wp.array[PADMMPenalty],
        solver_state_sigma: wp.array[vec2f],
        solver_state_a_p: wp.array[float32],
        linear_solver_atol: wp.array[float32],
    ):
        # Retrieve the world index as thread index
        wid = wp.tid()

        # Retrieve the per-world solver data
        config = solver_config[wid]
        status = solver_status[wid]
        penalty = solver_penalty[wid]
        sigma = solver_state_sigma[wid]

        # Initialize solver status
        status.iterations = int32(0)
        status.converged = int32(0)
        status.r_p = float32(0.0)
        status.r_d = float32(0.0)
        status.r_c = float32(0.0)
        # NOTE: We initialize acceleration-related
        # entries only if acceleration is enabled
        if wp.static(use_acceleration):
            status.r_dx = float32(0.0)
            status.r_dy = float32(0.0)
            status.r_dz = float32(0.0)
            status.r_a = FLOAT32_MAX
            status.r_a_p = FLOAT32_MAX
            status.r_a_pp = FLOAT32_MAX
            status.restart = int32(0)
            status.num_restarts = int32(0)

        # Initialize ALM penalty parameter and relevant meta-data
        # NOTE: Currently only fixed penalty is used
        penalty.rho = config.rho_0
        penalty.rho_p = float32(0.0)
        penalty.num_updates = int32(0)

        # Initialize the total proximal regularization
        sigma[0] = config.eta + config.rho_0
        sigma[1] = float32(0.0)

        # Store the initialized per-world solver data
        solver_status[wid] = status
        solver_penalty[wid] = penalty
        solver_state_sigma[wid] = sigma

        # Initialize the previous acclereration
        # variables only if acceleration is used
        if wp.static(use_acceleration):
            solver_state_a_p[wid] = config.a_0

        # Initialize the iterative solver tolerance
        if linear_solver_atol:
            linear_solver_atol[wid] = wp.where(
                config.linear_solver_tolerance > 0.0, config.linear_solver_tolerance, FLOAT32_EPS
            )

    # Return the initialization kernel
    return _initialize_solver


def make_update_proximal_regularization_kernel(method: PADMMPenaltyUpdate):
    @wp.kernel
    def _update_proximal_regularization(
        # Inputs:
        solver_config: wp.array[PADMMConfigStruct],
        solver_penalty: wp.array[PADMMPenalty],
        solver_status: wp.array[PADMMStatus],
        # Outputs:
        solver_state_sigma: wp.array[vec2f],
    ):
        # Retrieve the world index from the thread index
        wid = wp.tid()

        # Retrieve the solver status
        status = solver_status[wid]

        # Skip if row index exceed the problem size or if the solver has already converged
        if status.converged > 0:
            return

        # Retrieve the solver parameters
        cfg = solver_config[wid]
        pen = solver_penalty[wid]

        # Retrieve the (current, previous) proximal regularization pair
        sigma = solver_state_sigma[wid]

        # Extract the regularization parameters
        rho = pen.rho
        eta = cfg.eta

        # TODO: Add penalty update methods here

        # Update the diagonal proximal regularization
        sigma[1] = sigma[0]
        sigma[0] = eta + rho

    # Return the proximal regularization update kernel
    return _update_proximal_regularization


@wp.kernel
def _update_delassus_proximal_regularization(
    # Inputs:
    problem_dim: wp.array[int32],
    problem_mio: wp.array[int32],
    solver_status: wp.array[PADMMStatus],
    solver_state_sigma: wp.array[vec2f],
    # Outputs:
    D: wp.array[float32],
):
    # Retrieve the thread index
    wid, tid = wp.tid()

    # Retrieve the number of active constraints in the world
    ncts = problem_dim[wid]

    # Retrieve the solver status
    status = solver_status[wid]

    # Skip if row index exceed the problem size or if the solver has already converged
    if tid >= ncts or status.converged > 0:
        return

    # Retrieve the matrix index offset of the world
    mio = problem_mio[wid]

    # Retrieve the (current, previous) proximal regularization pair
    sigma = solver_state_sigma[wid]

    # Add the proximal regularization to the diagonal of the Delassus matrix
    D[mio + ncts * tid + tid] += sigma[0] - sigma[1]


@wp.kernel
def _update_delassus_proximal_regularization_sparse(
    # Inputs:
    problem_dim: wp.array[int32],
    problem_vio: wp.array[int32],
    solver_config: wp.array[PADMMConfigStruct],
    solver_penalty: wp.array[PADMMPenalty],
    solver_status: wp.array[PADMMStatus],
    # Outputs:
    delassus_eta: wp.array[float32],
):
    # Retrieve the thread index
    wid, tid = wp.tid()

    # Retrieve the number of active constraints in the world
    ncts = problem_dim[wid]

    # Retrieve the solver status
    status = solver_status[wid]

    # Skip if row index exceed the problem size
    if tid >= ncts:
        return

    # Retrieve the vector index offset of the world
    mio = problem_vio[wid]

    # Set regularization to 0.0 if the solver has already converged
    if status.converged > 0:
        delassus_eta[mio + tid] = 0.0
        return

    # Set the proximal regularization term: eta + rho
    delassus_eta[mio + tid] = solver_config[wid].eta + solver_penalty[wid].rho


@wp.kernel
def _compute_desaxce_correction(
    # Inputs:
    problem_nc: wp.array[int32],
    problem_cio: wp.array[int32],
    problem_ccgo: wp.array[int32],
    problem_vio: wp.array[int32],
    problem_mu: wp.array[float32],
    solver_status: wp.array[PADMMStatus],
    solver_z_p: wp.array[float32],
    # Outputs:
    solver_s: wp.array[float32],
):
    # Retrieve the thread index as the contact index
    wid, cid = wp.tid()

    # Retrieve the number of contact active in the world
    nc = problem_nc[wid]

    # Retrieve the solver status
    status = solver_status[wid]

    # Skip if row index exceed the problem size or if the solver has already converged
    if cid >= nc or status.converged > 0:
        return

    # Retrieve the contacts index offset of the world
    cio = problem_cio[wid]

    # Retrieve the index offset of the vector block of the world
    vio = problem_vio[wid]

    # Retrieve the contact constraints group offset of the world
    ccgo = problem_ccgo[wid]

    # Compute the index offset of the corresponding contact constraint
    ccio_k = vio + ccgo + 3 * cid

    # Retrieve the contact index w.r.t the model
    cio_k = cio + cid

    # Compute the norm of the tangential components
    vtx = solver_z_p[ccio_k]
    vty = solver_z_p[ccio_k + 1]
    vt_norm = wp.sqrt(vtx * vtx + vty * vty)

    # Store De Saxce correction for this block
    solver_s[ccio_k] = 0.0
    solver_s[ccio_k + 1] = 0.0
    solver_s[ccio_k + 2] = problem_mu[cio_k] * vt_norm


@wp.kernel
def _compute_velocity_bias(
    # Inputs:
    problem_dim: wp.array[int32],
    problem_vio: wp.array[int32],
    problem_v_f: wp.array[float32],
    solver_config: wp.array[PADMMConfigStruct],
    solver_penalty: wp.array[PADMMPenalty],
    solver_status: wp.array[PADMMStatus],
    solver_s: wp.array[float32],
    solver_x_p: wp.array[float32],
    solver_y_p: wp.array[float32],
    solver_z_p: wp.array[float32],
    # Outputs:
    solver_v: wp.array[float32],
):
    # Retrieve the thread indices as the world and constraint index
    wid, tid = wp.tid()

    # Retrieve the total number of active constraints in the world
    ncts = problem_dim[wid]

    # Retrieve the solver status
    status = solver_status[wid]

    # Skip if row index exceed the problem size or if the solver has already converged
    if tid >= ncts or status.converged > 0:
        return

    # Retrieve the index offset of the vector block of the world
    vio = problem_vio[wid]

    # Retrieve solver parameters
    eta = solver_config[wid].eta
    rho = solver_penalty[wid].rho

    # Compute the index offset of the vector block of the world
    thread_offset = vio + tid

    # Retrieve the solver state
    v_f = problem_v_f[thread_offset]
    s = solver_s[thread_offset]
    x_p = solver_x_p[thread_offset]
    y_p = solver_y_p[thread_offset]
    z_p = solver_z_p[thread_offset]

    # Compute the total velocity bias for the thread_offset-th constraint
    solver_v[thread_offset] = -v_f - s + eta * x_p + rho * y_p + z_p


@functools.cache
def make_desaxce_correction_and_velocity_bias_kernel(has_contacts: bool, collect_info: bool = False):
    """Factory for fused De Saxce correction + velocity bias kernel.

    Specialized at compile time on whether contacts are present, eliminating
    runtime branches for the common no-contacts case.  When ``collect_info``
    is True, the intermediate De Saxce correction is also written to
    ``solver_s`` so that the info kernel can read the original ``norm_s``.

    Args:
        has_contacts: Whether the problem has contact constraints.
        collect_info: Whether to persist the De Saxce correction to solver_s.
    """

    @wp.kernel
    def _compute_desaxce_correction_and_velocity_bias(
        # Inputs:
        problem_dim: wp.array[int32],
        problem_nc: wp.array[int32],
        problem_cio: wp.array[int32],
        problem_ccgo: wp.array[int32],
        problem_vio: wp.array[int32],
        problem_mu: wp.array[float32],
        problem_v_f: wp.array[float32],
        solver_config: wp.array[PADMMConfigStruct],
        solver_penalty: wp.array[PADMMPenalty],
        solver_status: wp.array[PADMMStatus],
        solver_x_p: wp.array[float32],
        solver_y_p: wp.array[float32],
        solver_z_p: wp.array[float32],
        # Outputs:
        solver_v: wp.array[float32],
        solver_s: wp.array[float32],
    ):
        wid, tid = wp.tid()

        ncts = problem_dim[wid]
        status = solver_status[wid]

        if tid >= ncts or status.converged > 0:
            return

        vio = problem_vio[wid]
        thread_offset = vio + tid

        eta = solver_config[wid].eta
        rho = solver_penalty[wid].rho

        v_f = problem_v_f[thread_offset]
        x_p = solver_x_p[thread_offset]
        y_p = solver_y_p[thread_offset]
        z_p = solver_z_p[thread_offset]

        s = float32(0.0)

        if wp.static(has_contacts):
            nc = problem_nc[wid]
            if nc > 0:
                ccgo = problem_ccgo[wid]
                local_offset = tid - ccgo
                if local_offset >= 0 and local_offset < 3 * nc:
                    cid = local_offset // 3
                    component = local_offset - 3 * cid
                    if component == 2:
                        cio = problem_cio[wid]
                        ccio_k = vio + ccgo + 3 * cid
                        vtx = solver_z_p[ccio_k]
                        vty = solver_z_p[ccio_k + 1]
                        s = problem_mu[cio + cid] * wp.sqrt(vtx * vtx + vty * vty)

        solver_v[thread_offset] = -v_f - s + eta * x_p + rho * y_p + z_p

        if wp.static(collect_info):
            solver_s[thread_offset] = s

    return _compute_desaxce_correction_and_velocity_bias


@wp.kernel
def _compute_projection_argument(
    # Inputs
    problem_dim: wp.array[int32],
    problem_vio: wp.array[int32],
    solver_penalty: wp.array[PADMMPenalty],
    solver_status: wp.array[PADMMStatus],
    solver_z_hat: wp.array[float32],
    solver_x: wp.array[float32],
    # Outputs
    solver_y: wp.array[float32],
):
    # Retrieve the thread indices as the world and constraint index
    wid, tid = wp.tid()

    # Retrieve the total number of active constraints in the world
    ncts = problem_dim[wid]

    # Retrieve the solver status
    status = solver_status[wid]

    # Skip if row index exceed the problem size or if the solver has already converged
    if tid >= ncts or status.converged > 0:
        return

    # Retrieve the index offset of the vector block of the world
    vio = problem_vio[wid]

    # Capture the ALM penalty
    rho = solver_penalty[wid].rho

    # Compute the index offset of the vector block of the world
    thread_offset = vio + tid

    # Retrieve the solver state variables
    z_hat = solver_z_hat[thread_offset]
    x = solver_x[thread_offset]

    # Compute and store the updated values back to the solver state
    solver_y[thread_offset] = x - (1.0 / rho) * z_hat


@wp.kernel
def _project_to_feasible_cone(
    # Inputs:
    problem_nl: wp.array[int32],
    problem_nc: wp.array[int32],
    problem_cio: wp.array[int32],
    problem_lcgo: wp.array[int32],
    problem_ccgo: wp.array[int32],
    problem_vio: wp.array[int32],
    problem_mu: wp.array[float32],
    solver_status: wp.array[PADMMStatus],
    # Outputs:
    solver_y: wp.array[float32],
):
    # Retrieve the thread index as the unilateral entity index
    wid, uid = wp.tid()

    # Retrieve the solver status
    status = solver_status[wid]

    # Retrieve the number of active limits and contacts in the world
    nl = problem_nl[wid]
    nc = problem_nc[wid]

    # Skip if row index exceed the problem size or if the solver has already converged
    if uid >= (nl + nc) or status.converged > 0:
        return

    # Retrieve the index offset of the vector block of the world
    vio = problem_vio[wid]

    # Check if the thread should handle a limit
    if nl > 0 and uid < nl:
        # Retrieve the limit constraint group offset of the world
        lcgo = problem_lcgo[wid]
        # Compute the constraint index offset of the limit element
        lcio_j = vio + lcgo + uid
        # Project to the non-negative orthant
        solver_y[lcio_j] = wp.max(solver_y[lcio_j], 0.0)

    # Check if the thread should handle a contact
    elif nc > 0 and uid >= nl:
        # Retrieve the contact index offset of the world
        cio = problem_cio[wid]
        # Retrieve the limit constraint group offset of the world
        ccgo = problem_ccgo[wid]
        # Compute the index of the contact element in the unilaterals array
        # NOTE: We need to subtract the number of active limits
        cid = uid - nl
        # Compute the index offset of the contact constraint
        ccio_j = vio + ccgo + 3 * cid
        # Capture a 3D vector
        x = vec3f(solver_y[ccio_j], solver_y[ccio_j + 1], solver_y[ccio_j + 2])
        # Project to the coulomb friction cone
        y_proj = project_to_coulomb_cone(x, problem_mu[cio + cid])
        # Copy vec3 projection into the slack variable array
        solver_y[ccio_j] = y_proj[0]
        solver_y[ccio_j + 1] = y_proj[1]
        solver_y[ccio_j + 2] = y_proj[2]


@wp.kernel
def _compute_projection_argument_and_project(
    # Inputs:
    problem_dim: wp.array[int32],
    problem_nl: wp.array[int32],
    problem_nc: wp.array[int32],
    problem_cio: wp.array[int32],
    problem_lcgo: wp.array[int32],
    problem_ccgo: wp.array[int32],
    problem_vio: wp.array[int32],
    problem_mu: wp.array[float32],
    solver_penalty: wp.array[PADMMPenalty],
    solver_status: wp.array[PADMMStatus],
    solver_z_hat: wp.array[float32],
    solver_x: wp.array[float32],
    # Outputs:
    solver_y: wp.array[float32],
):
    """Fused kernel: compute projection argument and project to feasible set.

    Combines _compute_projection_argument and _project_to_feasible_cone into a single kernel
    to reduce kernel launch overhead. Iterates over max_total_cts and conditionally applies
    the cone projection for unilateral constraints (limits and contacts).
    """
    wid, tid = wp.tid()

    ncts = problem_dim[wid]
    status = solver_status[wid]

    if tid >= ncts or status.converged > 0:
        return

    vio = problem_vio[wid]
    rho = solver_penalty[wid].rho
    thread_offset = vio + tid

    # Step 1: Compute projection argument y = x - (1/rho) * z_hat
    z_hat = solver_z_hat[thread_offset]
    x = solver_x[thread_offset]
    y_val = x - (1.0 / rho) * z_hat

    # Step 2: Project unilateral constraints to the feasible set
    nl = problem_nl[wid]
    nc = problem_nc[wid]
    lcgo = problem_lcgo[wid]
    ccgo = problem_ccgo[wid]

    # Check if this constraint index falls within the limit range
    if nl > 0 and tid >= lcgo and tid < lcgo + nl:
        solver_y[thread_offset] = wp.max(y_val, 0.0)

    # Check if this constraint index falls within a contact block
    # Contact constraints are 3D blocks: [tx, ty, n] at offsets ccgo + 3*cid + {0,1,2}
    elif nc > 0 and tid >= ccgo and tid < ccgo + 3 * nc:
        local_offset = tid - ccgo
        cid = local_offset // 3
        component = local_offset - 3 * cid
        if component == 0:
            # This thread handles the first component of a contact — do the full 3D projection
            # Recompute y for all 3 components locally so no other thread writes this contact block.
            cio = problem_cio[wid]
            ccio_j = vio + ccgo + 3 * cid
            inv_rho = 1.0 / rho
            y0 = solver_x[ccio_j] - inv_rho * solver_z_hat[ccio_j]
            y1 = solver_x[ccio_j + 1] - inv_rho * solver_z_hat[ccio_j + 1]
            y2 = solver_x[ccio_j + 2] - inv_rho * solver_z_hat[ccio_j + 2]
            y_proj = project_to_coulomb_cone(vec3f(y0, y1, y2), problem_mu[cio + cid])
            solver_y[ccio_j] = y_proj[0]
            solver_y[ccio_j + 1] = y_proj[1]
            solver_y[ccio_j + 2] = y_proj[2]
    else:
        solver_y[thread_offset] = y_val


def make_update_dual_variables_and_compute_primal_dual_residuals(use_acceleration: bool = False):
    """
    Creates a kernel to update the dual variables and compute the primal and dual residuals.

    Specialized for whether acceleration is enabled to reduce unnecessary overhead and branching.

    Args:
        use_acceleration (bool, optional): Flag indicating whether acceleration is enabled. Defaults to False.

    Returns:
        wp.kernel: The kernel function to update dual variables and compute residuals.
    """

    @wp.kernel
    def _update_dual_variables_and_compute_primal_dual_residuals(
        # Inputs:
        problem_dim: wp.array[int32],
        problem_vio: wp.array[int32],
        problem_P: wp.array[float32],
        solver_config: wp.array[PADMMConfigStruct],
        solver_penalty: wp.array[PADMMPenalty],
        solver_status: wp.array[PADMMStatus],
        solver_x: wp.array[float32],
        solver_y: wp.array[float32],
        solver_x_p: wp.array[float32],
        solver_y_p: wp.array[float32],
        solver_z_p: wp.array[float32],
        # Outputs:
        solver_z: wp.array[float32],
        solver_r_prim: wp.array[float32],
        solver_r_dual: wp.array[float32],
        solver_r_dx: wp.array[float32],
        solver_r_dy: wp.array[float32],
        solver_r_dz: wp.array[float32],
    ):
        # Retrieve the thread indices as the world and constraint index
        wid, tid = wp.tid()

        # Retrieve the total number of active constraints in the world
        ncts = problem_dim[wid]

        # Retrieve the solver status
        status = solver_status[wid]

        # Skip if row index exceed the problem size or if the solver has already converged
        if tid >= ncts or status.converged > 0:
            return

        # Retrieve the index offset of the vector block of the world
        vio = problem_vio[wid]

        # Capture proximal parameter and the ALM penalty
        eta = solver_config[wid].eta
        rho = solver_penalty[wid].rho

        # Compute the index offset of the vector block of the world
        thread_offset = vio + tid

        # Retrieve
        P_i = problem_P[thread_offset]

        # Retrieve the solver state inputs
        x = solver_x[thread_offset]
        y = solver_y[thread_offset]
        x_p = solver_x_p[thread_offset]
        y_p = solver_y_p[thread_offset]
        z_p = solver_z_p[thread_offset]

        # Compute and store the dual variable update
        z = z_p + rho * (y - x)
        solver_z[thread_offset] = z

        # Compute the primal residual as the consensus of the primal and slack variable
        solver_r_prim[thread_offset] = P_i * (x - y)

        # Compute the dual residual using the ADMM-specific shortcut
        solver_r_dual[thread_offset] = (1.0 / P_i) * (eta * (x - x_p) + rho * (y - y_p))

        # Compute the individual iterate residuals only if acceleration is enabled
        # NOTE: These are used to compute the combined residual
        # for checking the acceleration restart criteria
        if wp.static(use_acceleration):
            solver_r_dx[thread_offset] = P_i * (x - x_p)
            solver_r_dy[thread_offset] = P_i * (y - y_p)
            solver_r_dz[thread_offset] = (1.0 / P_i) * (z - z_p)

    # Return the dual update and residual computation kernel
    return _update_dual_variables_and_compute_primal_dual_residuals


def make_update_dual_and_all_residuals(use_acceleration: bool = False):
    """Creates a fused kernel: dual variable update + primal/dual residuals + complementarity residuals.

    Combines make_update_dual_variables_and_compute_primal_dual_residuals and
    _compute_complementarity_residuals into a single kernel to reduce launch overhead.
    The complementarity residual is computed inline for unilateral constraint indices.
    """

    @wp.kernel
    def _update_dual_and_all_residuals(
        # Inputs:
        problem_dim: wp.array[int32],
        problem_nl: wp.array[int32],
        problem_nc: wp.array[int32],
        problem_cio: wp.array[int32],
        problem_lcgo: wp.array[int32],
        problem_ccgo: wp.array[int32],
        problem_vio: wp.array[int32],
        problem_uio: wp.array[int32],
        problem_P: wp.array[float32],
        solver_config: wp.array[PADMMConfigStruct],
        solver_penalty: wp.array[PADMMPenalty],
        solver_status: wp.array[PADMMStatus],
        solver_x: wp.array[float32],
        solver_y: wp.array[float32],
        solver_x_p: wp.array[float32],
        solver_y_p: wp.array[float32],
        solver_z_p: wp.array[float32],
        # Outputs:
        solver_z: wp.array[float32],
        solver_r_prim: wp.array[float32],
        solver_r_dual: wp.array[float32],
        solver_r_compl: wp.array[float32],
        solver_r_dx: wp.array[float32],
        solver_r_dy: wp.array[float32],
        solver_r_dz: wp.array[float32],
    ):
        wid, tid = wp.tid()

        ncts = problem_dim[wid]
        status = solver_status[wid]

        if tid >= ncts or status.converged > 0:
            return

        vio = problem_vio[wid]

        eta = solver_config[wid].eta
        rho = solver_penalty[wid].rho

        thread_offset = vio + tid

        P_i = problem_P[thread_offset]

        x = solver_x[thread_offset]
        y = solver_y[thread_offset]
        x_p = solver_x_p[thread_offset]
        y_p = solver_y_p[thread_offset]
        z_p = solver_z_p[thread_offset]

        # Dual variable update
        z = z_p + rho * (y - x)
        solver_z[thread_offset] = z

        # Primal residual
        solver_r_prim[thread_offset] = P_i * (x - y)

        # Dual residual
        solver_r_dual[thread_offset] = (1.0 / P_i) * (eta * (x - x_p) + rho * (y - y_p))

        # Iterate residuals for acceleration restart
        if wp.static(use_acceleration):
            solver_r_dx[thread_offset] = P_i * (x - x_p)
            solver_r_dy[thread_offset] = P_i * (y - y_p)
            solver_r_dz[thread_offset] = (1.0 / P_i) * (z - z_p)

        # Complementarity residuals for unilateral constraints
        nl = problem_nl[wid]
        nc = problem_nc[wid]
        lcgo = problem_lcgo[wid]
        ccgo = problem_ccgo[wid]

        # Limit constraints: scalar complementarity x_j * z_j
        limit_start = lcgo
        if nl > 0 and tid >= limit_start and tid < limit_start + nl:
            uio = problem_uio[wid]
            uid = tid - limit_start
            solver_r_compl[uio + uid] = x * z

        # Contact constraints: dot product of 3D vectors x_c dot z_c
        # Recompute z locally for all 3 components to avoid inter-thread race
        elif nc > 0 and tid >= ccgo:
            local_offset = tid - ccgo
            cid = local_offset // 3
            component = local_offset - 3 * cid
            if cid < nc and component == 0:
                uio = problem_uio[wid]
                ccio_j = vio + ccgo + 3 * cid
                x_c = vec3f(solver_x[ccio_j], solver_x[ccio_j + 1], solver_x[ccio_j + 2])
                # Recompute z for all 3 components locally
                z0 = solver_z_p[ccio_j] + rho * (solver_y[ccio_j] - solver_x[ccio_j])
                z1 = solver_z_p[ccio_j + 1] + rho * (solver_y[ccio_j + 1] - solver_x[ccio_j + 1])
                z2 = solver_z_p[ccio_j + 2] + rho * (solver_y[ccio_j + 2] - solver_x[ccio_j + 2])
                solver_r_compl[uio + nl + cid] = wp.dot(x_c, vec3f(z0, z1, z2))

    return _update_dual_and_all_residuals


@wp.kernel
def _compute_complementarity_residuals(
    # Inputs:
    problem_nl: wp.array[int32],
    problem_nc: wp.array[int32],
    problem_vio: wp.array[int32],
    problem_uio: wp.array[int32],
    problem_lcgo: wp.array[int32],
    problem_ccgo: wp.array[int32],
    solver_status: wp.array[PADMMStatus],
    solver_x: wp.array[float32],
    solver_z: wp.array[float32],
    # Outputs:
    solver_r_c: wp.array[float32],
):
    # Retrieve the thread index as the unilateral entity index
    wid, uid = wp.tid()

    # Retrieve the solver status
    status = solver_status[wid]

    # Retrieve the number of active limits and contacts in the world
    nl = problem_nl[wid]
    nc = problem_nc[wid]

    # Skip if row index exceed the problem size or if the solver has already converged
    if uid >= (nl + nc) or status.converged > 0:
        return

    # Retrieve the index offsets of the unilateral elements
    uio = problem_uio[wid]

    # Retrieve the index offset of the vector block of the world
    vio = problem_vio[wid]

    # Compute the index offset of the vector block of the world
    uio_u = uio + uid

    # Check if the thread should handle a limit
    if nl > 0 and uid < nl:
        # Retrieve the limit constraint group offset of the world
        lcgo = problem_lcgo[wid]
        # Compute the constraint index offset of the limit element
        lcio_j = vio + lcgo + uid
        # Compute the scalar product of the primal and dual variables
        solver_r_c[uio_u] = solver_x[lcio_j] * solver_z[lcio_j]

    # Check if the thread should handle a contact
    elif nc > 0 and uid >= nl:
        # Retrieve the limit constraint group offset of the world
        ccgo = problem_ccgo[wid]
        # Compute the index of the contact element in the unilaterals array
        # NOTE: We need to subtract the number of active limits
        cid = uid - nl
        # Compute the index offset of the contact constraint
        ccio_j = vio + ccgo + 3 * cid
        # Capture 3D vectors
        x_c = vec3f(solver_x[ccio_j], solver_x[ccio_j + 1], solver_x[ccio_j + 2])
        z_c = vec3f(solver_z[ccio_j], solver_z[ccio_j + 1], solver_z[ccio_j + 2])
        # Compute the inner product of the primal and dual variables
        solver_r_c[uio_u] = wp.dot(x_c, z_c)


@wp.func
def _update_penalty(config: PADMMConfigStruct, pen: PADMMPenalty, iterations: int32, r_p: float32, r_d: float32):
    """Adaptively updates the ADMM penalty parameter based on the configured strategy.

    For BALANCED mode, rho is scaled up when the primal residual dominates and
    scaled down (to ``config.rho_min``) when the dual residual dominates, every
    ``config.penalty_update_freq`` iterations.  For FIXED mode this is a no-op.
    """
    if config.penalty_update_method == int32(PADMMPenaltyUpdate.BALANCED):
        freq = config.penalty_update_freq
        if freq > 0 and iterations > 0 and iterations % freq == 0:
            rho = pen.rho
            if r_p > config.alpha * r_d:
                rho = rho * config.tau
            elif r_d > config.alpha * r_p:
                rho = wp.max(rho / config.tau, config.rho_min)
            pen.rho = rho
            pen.num_updates += int32(1)
    return pen


@wp.func
def less_than_op(i: wp.int32, threshold: wp.int32) -> wp.float32:
    return 1.0 if i < threshold else 0.0


@wp.func
def mul_mask(mask: Any, value: Any):
    """Return value if mask is positive, else 0"""
    return wp.where(mask > type(mask)(0), value, type(value)(0))


@functools.cache
def _make_compute_infnorm_residuals_kernel(tile_size: int, n_cts_max: int, n_u_max: int):
    num_tiles_cts = (n_cts_max + tile_size - 1) // tile_size
    num_tiles_u = (n_u_max + tile_size - 1) // tile_size

    @wp.kernel
    def _compute_infnorm_residuals(
        # Inputs:
        problem_nl: wp.array[int32],
        problem_nc: wp.array[int32],
        problem_uio: wp.array[int32],
        problem_dim: wp.array[int32],
        problem_vio: wp.array[int32],
        solver_config: wp.array[PADMMConfigStruct],
        solver_r_p: wp.array[float32],
        solver_r_d: wp.array[float32],
        solver_r_c: wp.array[float32],
        # Outputs:
        solver_state_done: wp.array[int32],
        solver_status: wp.array[PADMMStatus],
        solver_penalty: wp.array[PADMMPenalty],
        linear_solver_atol: wp.array[float32],
    ):
        # Retrieve the thread index as the world index + thread index within block
        wid, tid = wp.tid()

        # Retrieve the solver status
        status = solver_status[wid]

        # Skip this step if already converged
        if status.converged:
            return

        # Update iteration counter
        status.iterations += 1

        # Capture the size of the residuals arrays
        nl = problem_nl[wid]
        nc = problem_nc[wid]
        ncts = problem_dim[wid]

        # Retrieve the solver configurations
        config = solver_config[wid]

        # Retrieve the index offsets of the vector block and unilateral elements
        vio = problem_vio[wid]
        uio = problem_uio[wid]

        # Extract the solver tolerances
        eps_p = config.primal_tolerance
        eps_d = config.dual_tolerance
        eps_c = config.compl_tolerance

        # Extract the maximum number of iterations
        maxiters = config.max_iterations

        # Compute element-wise max over each residual vector to compute the infinity-norm
        r_p_max = float32(0.0)
        r_d_max = float32(0.0)
        if wp.static(num_tiles_cts > 1):
            r_p_max_acc = wp.tile_zeros(num_tiles_cts, dtype=float32, storage="shared")
            r_d_max_acc = wp.tile_zeros(num_tiles_cts, dtype=float32, storage="shared")
        for tile_id in range(num_tiles_cts):
            ct_id_tile = tile_id * tile_size
            if ct_id_tile >= ncts:
                break
            rio_tile = vio + ct_id_tile

            # Mask out extra entries in case of heterogenous worlds
            need_mask = ct_id_tile > ncts - tile_size
            if need_mask:
                mask = wp.tile_map(less_than_op, wp.tile_arange(tile_size, dtype=int32), ncts - ct_id_tile)

            tile = wp.tile_load(solver_r_p, shape=tile_size, offset=rio_tile)
            tile = wp.tile_map(wp.abs, tile)
            if need_mask:
                tile = wp.tile_map(mul_mask, mask, tile)
            if wp.static(num_tiles_cts > 1):
                r_p_max_acc[tile_id] = wp.tile_max(tile)[0]
            else:
                r_p_max = wp.tile_max(tile)[0]

            tile = wp.tile_load(solver_r_d, shape=tile_size, offset=rio_tile)
            tile = wp.tile_map(wp.abs, tile)
            if need_mask:
                tile = wp.tile_map(mul_mask, mask, tile)
            if wp.static(num_tiles_cts > 1):
                r_d_max_acc[tile_id] = wp.tile_max(tile)[0]
            else:
                r_d_max = wp.tile_max(tile)[0]
        if wp.static(num_tiles_cts > 1):
            r_p_max = wp.tile_max(r_p_max_acc)[0]
            r_d_max = wp.tile_max(r_d_max_acc)[0]

        # Compute the infinity-norm of the complementarity residuals
        nu = nl + nc
        r_c_max = float32(0.0)
        if wp.static(num_tiles_u > 1):
            r_c_max_acc = wp.tile_zeros(num_tiles_u, dtype=float32, storage="shared")
        for tile_id in range(num_tiles_u):
            u_id_tile = tile_id * tile_size
            if u_id_tile >= nu:
                break
            uio_tile = uio + u_id_tile

            # Mask out extra entries in case of heterogenous worlds
            need_mask = u_id_tile > nu - tile_size
            if need_mask:
                mask = wp.tile_map(less_than_op, wp.tile_arange(tile_size, dtype=int32), nu - u_id_tile)

            tile = wp.tile_load(solver_r_c, shape=tile_size, offset=uio_tile)
            tile = wp.tile_map(wp.abs, tile)
            if need_mask:
                tile = wp.tile_map(mul_mask, mask, tile)
            if wp.static(num_tiles_u > 1):
                r_c_max_acc[tile_id] = wp.tile_max(tile)[0]
            else:
                r_c_max = wp.tile_max(tile)[0]
        if wp.static(num_tiles_u > 1):
            r_c_max = wp.tile_max(r_c_max_acc)[0]

        if tid == 0:
            # Store the scalar metric residuals in the solver status
            status.r_p = r_p_max
            status.r_d = r_d_max
            status.r_c = r_c_max

            # Check and store convergence state
            if status.iterations > 1 and r_p_max <= eps_p and r_d_max <= eps_d and r_c_max <= eps_c:
                status.converged = 1

            # If converged or reached max iterations, decrement the number of active worlds
            if status.converged or status.iterations >= maxiters:
                solver_state_done[0] -= 1

            # Store the updated status
            solver_status[wid] = status

            # Adaptive penalty update
            solver_penalty[wid] = _update_penalty(config, solver_penalty[wid], status.iterations, r_p_max, r_d_max)

    return _compute_infnorm_residuals


@functools.cache
def _make_compute_infnorm_residuals_accel_kernel(tile_size: int, n_cts_max: int, n_u_max: int):
    num_tiles_cts = (n_cts_max + tile_size - 1) // tile_size
    num_tiles_u = (n_u_max + tile_size - 1) // tile_size

    @wp.kernel
    def _compute_infnorm_residuals_accel(
        # Inputs:
        problem_nl: wp.array[int32],
        problem_nc: wp.array[int32],
        problem_uio: wp.array[int32],
        problem_dim: wp.array[int32],
        problem_vio: wp.array[int32],
        solver_config: wp.array[PADMMConfigStruct],
        solver_r_p: wp.array[float32],
        solver_r_d: wp.array[float32],
        solver_r_c: wp.array[float32],
        solver_r_dx: wp.array[float32],
        solver_r_dy: wp.array[float32],
        solver_r_dz: wp.array[float32],
        solver_state_a_p: wp.array[float32],
        # Outputs:
        solver_state_done: wp.array[int32],
        solver_state_a: wp.array[float32],
        solver_state_a_factor: wp.array[float32],
        solver_status: wp.array[PADMMStatus],
        solver_penalty: wp.array[PADMMPenalty],
        linear_solver_atol: wp.array[float32],
    ):
        # Retrieve the thread index as the world index + thread index within block
        wid, tid = wp.tid()

        # Retrieve the solver status
        status = solver_status[wid]

        # Skip this step if already converged
        if status.converged:
            return

        # Update iteration counter
        status.iterations += 1

        # Capture the size of the residuals arrays
        nl = problem_nl[wid]
        nc = problem_nc[wid]
        ncts = problem_dim[wid]

        # Retrieve the solver configurations
        config = solver_config[wid]

        # Retrieve the index offsets of the vector block and unilateral elements
        vio = problem_vio[wid]
        uio = problem_uio[wid]

        # Extract the solver tolerances
        eps_p = config.primal_tolerance
        eps_d = config.dual_tolerance
        eps_c = config.compl_tolerance

        # Extract the maximum number of iterations
        maxiters = config.max_iterations

        # Extract the penalty parameters
        pen = solver_penalty[wid]
        rho = pen.rho

        # Compute element-wise max over each residual vector to compute the infinity-norm
        r_p_max = float32(0.0)
        r_d_max = float32(0.0)
        r_dx_l2_sum = float32(0.0)
        r_dy_l2_sum = float32(0.0)
        r_dz_l2_sum = float32(0.0)
        if wp.static(num_tiles_cts > 1):
            r_p_max_acc = wp.tile_zeros(num_tiles_cts, dtype=float32, storage="shared")
            r_d_max_acc = wp.tile_zeros(num_tiles_cts, dtype=float32, storage="shared")
            r_dx_l2_sum_acc = wp.tile_zeros(num_tiles_cts, dtype=float32, storage="shared")
            r_dy_l2_sum_acc = wp.tile_zeros(num_tiles_cts, dtype=float32, storage="shared")
            r_dz_l2_sum_acc = wp.tile_zeros(num_tiles_cts, dtype=float32, storage="shared")
        for tile_id in range(num_tiles_cts):
            ct_id_tile = tile_id * tile_size
            if ct_id_tile >= ncts:
                break
            rio_tile = vio + ct_id_tile

            # Mask out extra entries in case of heterogenous worlds
            need_mask = ct_id_tile > ncts - tile_size
            if need_mask:
                mask = wp.tile_map(less_than_op, wp.tile_arange(tile_size, dtype=int32), ncts - ct_id_tile)

            tile = wp.tile_load(solver_r_p, shape=tile_size, offset=rio_tile)
            tile = wp.tile_map(wp.abs, tile)
            if need_mask:
                tile = wp.tile_map(mul_mask, mask, tile)
            if wp.static(num_tiles_cts > 1):
                r_p_max_acc[tile_id] = wp.tile_max(tile)[0]
            else:
                r_p_max = wp.tile_max(tile)[0]

            tile = wp.tile_load(solver_r_d, shape=tile_size, offset=rio_tile)
            tile = wp.tile_map(wp.abs, tile)
            if need_mask:
                tile = wp.tile_map(mul_mask, mask, tile)
            if wp.static(num_tiles_cts > 1):
                r_d_max_acc[tile_id] = wp.tile_max(tile)[0]
            else:
                r_d_max = wp.tile_max(tile)[0]

            tile = wp.tile_load(solver_r_dx, shape=tile_size, offset=rio_tile)
            tile = wp.tile_map(wp.mul, tile, tile)
            if need_mask:
                tile = wp.tile_map(mul_mask, mask, tile)
            if wp.static(num_tiles_cts > 1):
                r_dx_l2_sum_acc[tile_id] = wp.tile_sum(tile)[0]
            else:
                r_dx_l2_sum = wp.tile_sum(tile)[0]

            tile = wp.tile_load(solver_r_dy, shape=tile_size, offset=rio_tile)
            tile = wp.tile_map(wp.mul, tile, tile)
            if need_mask:
                tile = wp.tile_map(mul_mask, mask, tile)
            if wp.static(num_tiles_cts > 1):
                r_dy_l2_sum_acc[tile_id] = wp.tile_sum(tile)[0]
            else:
                r_dy_l2_sum = wp.tile_sum(tile)[0]

            tile = wp.tile_load(solver_r_dz, shape=tile_size, offset=rio_tile)
            tile = wp.tile_map(wp.mul, tile, tile)
            if need_mask:
                tile = wp.tile_map(mul_mask, mask, tile)
            if wp.static(num_tiles_cts > 1):
                r_dz_l2_sum_acc[tile_id] = wp.tile_sum(tile)[0]
            else:
                r_dz_l2_sum = wp.tile_sum(tile)[0]
        if wp.static(num_tiles_cts > 1):
            r_p_max = wp.tile_max(r_p_max_acc)[0]
            r_d_max = wp.tile_max(r_d_max_acc)[0]
            r_dx_l2_sum = wp.tile_sum(r_dx_l2_sum_acc)[0]
            r_dy_l2_sum = wp.tile_sum(r_dy_l2_sum_acc)[0]
            r_dz_l2_sum = wp.tile_sum(r_dz_l2_sum_acc)[0]

        # Compute the infinity-norm of the complementarity residuals
        nu = nl + nc
        r_c_max = float32(0.0)
        if wp.static(num_tiles_u > 1):
            r_c_max_acc = wp.tile_zeros(num_tiles_u, dtype=float32, storage="shared")
        for tile_id in range(num_tiles_u):
            u_id_tile = tile_id * tile_size
            if u_id_tile >= nu:
                break
            uio_tile = uio + u_id_tile

            # Mask out extra entries in case of heterogenous worlds
            need_mask = u_id_tile > nu - tile_size
            if need_mask:
                mask = wp.tile_map(less_than_op, wp.tile_arange(tile_size, dtype=int32), nu - u_id_tile)

            tile = wp.tile_load(solver_r_c, shape=tile_size, offset=uio_tile)
            tile = wp.tile_map(wp.abs, tile)
            if need_mask:
                tile = wp.tile_map(mul_mask, mask, tile)
            if wp.static(num_tiles_u > 1):
                r_c_max_acc[tile_id] = wp.tile_max(tile)[0]
            else:
                r_c_max = wp.tile_max(tile)[0]
        if wp.static(num_tiles_u > 1):
            r_c_max = wp.tile_max(r_c_max_acc)[0]

        if tid == 0:
            # Store the scalar metric residuals in the solver status
            status.r_p = r_p_max
            status.r_d = r_d_max
            status.r_c = r_c_max
            status.r_dx = wp.sqrt(r_dx_l2_sum)
            status.r_dy = wp.sqrt(r_dy_l2_sum)
            status.r_dz = wp.sqrt(r_dz_l2_sum)
            status.r_a = rho * status.r_dy + (1.0 / rho) * status.r_dz

            # Check and store convergence state
            if status.iterations > 1 and r_p_max <= eps_p and r_d_max <= eps_d and r_c_max <= eps_c:
                status.converged = 1

            # If converged or reached max iterations, decrement the number of active worlds
            if status.converged or status.iterations >= maxiters:
                solver_state_done[0] -= 1

            # Restart acceleration if the residuals are not decreasing sufficiently
            # TODO: Use a warp function that is wrapped with wp.static for conditionally compiling this
            if status.r_a < config.restart_tolerance * status.r_a_p:
                status.restart = 0
                a_p = solver_state_a_p[wid]
                a = (1.0 + wp.sqrt(1.0 + 4.0 * a_p * a_p)) / 2.0
                solver_state_a[wid] = a
                solver_state_a_factor[wid] = (a_p - 1.0) / a
            else:
                status.restart = 1
                status.num_restarts += 1
                status.r_a = status.r_a_p / config.restart_tolerance
                solver_state_a[wid] = float(config.a_0)
                solver_state_a_factor[wid] = float32(0.0)
            status.r_a_pp = status.r_a_p
            status.r_a_p = status.r_a

            # Store the updated status
            solver_status[wid] = status

            # Adaptive penalty update
            solver_penalty[wid] = _update_penalty(config, solver_penalty[wid], status.iterations, r_p_max, r_d_max)

    return _compute_infnorm_residuals_accel


@wp.kernel
def _update_state_with_acceleration(
    # Inputs:
    problem_dim: wp.array[int32],
    problem_vio: wp.array[int32],
    solver_status: wp.array[PADMMStatus],
    solver_state_a: wp.array[float32],
    solver_state_y: wp.array[float32],
    solver_state_z: wp.array[float32],
    solver_state_a_p: wp.array[float32],
    solver_state_y_p: wp.array[float32],
    solver_state_z_p: wp.array[float32],
    # Outputs:
    solver_state_y_hat: wp.array[float32],
    solver_state_z_hat: wp.array[float32],
):
    # Retrieve the thread indices as the world and constraint index
    wid, tid = wp.tid()

    # Retrieve the total number of active constraints in the world
    ncts = problem_dim[wid]

    # Retrieve the solver status
    status = solver_status[wid]

    # Skip if row index exceed the problem size or if the solver has already converged
    if tid >= ncts or status.converged > 0:
        return

    # Retrieve the index offset of the vector block of the world
    vio = problem_vio[wid]

    # Compute the index offset of the vector block of the world
    vid = vio + tid

    # Only apply acceleration if not restarting
    if status.restart == 0:
        # Retrieve the previous and current states
        a = solver_state_a[wid]
        y = solver_state_y[vid]
        z = solver_state_z[vid]
        a_p = solver_state_a_p[wid]
        y_p = solver_state_y_p[vid]
        z_p = solver_state_z_p[vid]

        # Compute the current acceleration factor
        factor = (a_p - 1.0) / a

        # Update the primal and dual variables with Nesterov acceleration
        y_hat_new = y + factor * (y - y_p)
        z_hat_new = z + factor * (z - z_p)

        # Store the updated states
        solver_state_y_hat[vid] = y_hat_new
        solver_state_z_hat[vid] = z_hat_new
    else:
        # If restarting, reset the auxiliary primal-dual state to the previous-step values
        solver_state_y_hat[vid] = solver_state_y_p[vid]
        solver_state_z_hat[vid] = solver_state_z_p[vid]


@wp.kernel
def _update_acceleration_and_cache_previous(
    # Inputs:
    problem_dim: wp.array[int32],
    problem_vio: wp.array[int32],
    solver_status: wp.array[PADMMStatus],
    solver_state_a: wp.array[float32],
    solver_state_a_factor: wp.array[float32],
    solver_state_x: wp.array[float32],
    solver_state_y: wp.array[float32],
    solver_state_z: wp.array[float32],
    solver_state_y_p: wp.array[float32],
    solver_state_z_p: wp.array[float32],
    # Outputs:
    solver_state_y_hat: wp.array[float32],
    solver_state_z_hat: wp.array[float32],
    solver_state_x_p_out: wp.array[float32],
    solver_state_y_p_out: wp.array[float32],
    solver_state_z_p_out: wp.array[float32],
    solver_state_a_p_out: wp.array[float32],
):
    """Fused kernel: Nesterov acceleration update + cache previous state."""
    # Retrieve the thread indices as the world and constraint index
    wid, tid = wp.tid()

    # Retrieve the total number of active constraints
    # in the world and the current solver status
    ncts = problem_dim[wid]
    status = solver_status[wid]

    # Skip if row index exceed the problem size
    if tid >= ncts:
        return

    # Retrieve the index offset of the vector block of the world
    vio = problem_vio[wid]
    vid = vio + tid

    # Read current state and old previous state
    x = solver_state_x[vid]
    y = solver_state_y[vid]
    z = solver_state_z[vid]
    y_p = solver_state_y_p[vid]
    z_p = solver_state_z_p[vid]

    # Update the auxiliary primal-dual state with Nesterov acceleration
    # if not restarting, else reset to the previous slack and dual state
    if status.converged == 0:
        if status.restart == 0:
            factor = solver_state_a_factor[wid]
            solver_state_y_hat[vid] = y + factor * (y - y_p)
            solver_state_z_hat[vid] = z + factor * (z - z_p)
        else:
            solver_state_y_hat[vid] = y_p
            solver_state_z_hat[vid] = z_p

    # Cache current → previous state for the next iteration
    solver_state_x_p_out[vid] = x
    solver_state_y_p_out[vid] = y
    solver_state_z_p_out[vid] = z

    # Only one thread needs to cache the scalar acceleration parameter
    if tid == 0:
        solver_state_a_p_out[wid] = solver_state_a[wid]


def make_collect_solver_info_kernel(use_acceleration: bool):
    """
    Creates a kernel to collect solver convergence information after each iteration.

    Specializes the kernel based on whether acceleration is enabled to reduce unnecessary overhead.

    Args:
        use_acceleration (bool): Whether acceleration is enabled in the solver.

    Returns:
        wp.kernel: The kernel function to collect solver convergence information.
    """

    @wp.kernel
    def _collect_solver_convergence_info(
        # Inputs:
        problem_nl: wp.array[int32],
        problem_nc: wp.array[int32],
        problem_cio: wp.array[int32],
        problem_lcgo: wp.array[int32],
        problem_ccgo: wp.array[int32],
        problem_dim: wp.array[int32],
        problem_vio: wp.array[int32],
        problem_mio: wp.array[int32],
        problem_mu: wp.array[float32],
        problem_v_f: wp.array[float32],
        problem_D: wp.array[float32],
        problem_P: wp.array[float32],
        solver_state_sigma: wp.array[vec2f],
        solver_state_s: wp.array[float32],
        solver_state_x: wp.array[float32],
        solver_state_x_p: wp.array[float32],
        solver_state_y: wp.array[float32],
        solver_state_y_p: wp.array[float32],
        solver_state_z: wp.array[float32],
        solver_state_z_p: wp.array[float32],
        solver_state_a: wp.array[float32],
        solver_penalty: wp.array[PADMMPenalty],
        solver_status: wp.array[PADMMStatus],
        # Outputs:
        solver_info_lambdas: wp.array[float32],
        solver_info_v_plus: wp.array[float32],
        solver_info_v_aug: wp.array[float32],
        solver_info_s: wp.array[float32],
        solver_info_offset: wp.array[int32],
        solver_info_num_restarts: wp.array[int32],
        solver_info_num_rho_updates: wp.array[int32],
        solver_info_a: wp.array[float32],
        solver_info_norm_s: wp.array[float32],
        solver_info_norm_x: wp.array[float32],
        solver_info_norm_y: wp.array[float32],
        solver_info_norm_z: wp.array[float32],
        solver_info_f_ccp: wp.array[float32],
        solver_info_f_ncp: wp.array[float32],
        solver_info_r_dx: wp.array[float32],
        solver_info_r_dy: wp.array[float32],
        solver_info_r_dz: wp.array[float32],
        solver_info_r_primal: wp.array[float32],
        solver_info_r_dual: wp.array[float32],
        solver_info_r_compl: wp.array[float32],
        solver_info_r_pd: wp.array[float32],
        solver_info_r_dp: wp.array[float32],
        solver_info_r_comb: wp.array[float32],
        solver_info_r_comb_ratio: wp.array[float32],
        solver_info_r_ncp_primal: wp.array[float32],
        solver_info_r_ncp_dual: wp.array[float32],
        solver_info_r_ncp_compl: wp.array[float32],
        solver_info_r_ncp_natmap: wp.array[float32],
    ):
        # Retrieve the thread index as the world index
        wid = wp.tid()

        # Retrieve the world-specific data
        nl = problem_nl[wid]
        nc = problem_nc[wid]
        ncts = problem_dim[wid]
        cio = problem_cio[wid]
        lcgo = problem_lcgo[wid]
        ccgo = problem_ccgo[wid]
        vio = problem_vio[wid]
        mio = problem_mio[wid]
        rio = solver_info_offset[wid]
        penalty = solver_penalty[wid]
        status = solver_status[wid]
        sigma = solver_state_sigma[wid]

        # Retrieve parameters
        iter = status.iterations - 1

        # Compute additional info
        njc = ncts - (nl + 3 * nc)

        # Compute and store the norms of the current solution state
        norm_s = compute_l2_norm(ncts, vio, solver_state_s)
        norm_x = compute_l2_norm(ncts, vio, solver_state_x)
        norm_y = compute_l2_norm(ncts, vio, solver_state_y)
        norm_z = compute_l2_norm(ncts, vio, solver_state_z)

        # Compute (division safe) residual ratios
        r_pd = status.r_p / (status.r_d + FLOAT32_EPS)
        r_dp = status.r_d / (status.r_p + FLOAT32_EPS)

        # Remove preconditioning from lambdas
        compute_cwise_vec_mul(ncts, vio, problem_P, solver_state_y, solver_info_lambdas)

        # Compute the post-event constraint-space velocity from the current solution: v_plus = v_f + D @ lambda
        compute_gemv(ncts, vio, mio, sigma[0], problem_P, problem_D, solver_state_y, problem_v_f, solver_info_v_plus)

        # Compute the De Saxce correction for each contact as: s = G(v_plus)
        compute_desaxce_corrections(nc, cio, vio, ccgo, problem_mu, solver_info_v_plus, solver_info_s)

        # Compute the CCP optimization objective as: f_ccp = 0.5 * lambda.dot(v_plus + v_f)
        f_ccp = 0.5 * compute_double_dot_product(ncts, vio, solver_info_lambdas, solver_info_v_plus, problem_v_f)

        # Compute the NCP optimization objective as:  f_ncp = f_ccp + lambda.dot(s)
        f_ncp = compute_dot_product(ncts, vio, solver_info_lambdas, solver_info_s)
        f_ncp += f_ccp

        # Compute the augmented post-event constraint-space velocity as: v_aug = v_plus + s
        compute_vector_sum(ncts, vio, solver_info_v_plus, solver_info_s, solver_info_v_aug)

        # Compute the NCP primal residual as: r_p := || lambda - proj_K(lambda) ||_inf
        r_ncp_p, _ = compute_ncp_primal_residual(nl, nc, vio, lcgo, ccgo, cio, problem_mu, solver_info_lambdas)

        # Compute the NCP dual residual as: r_d := || v_plus + s - proj_dual_K(v_plus + s)  ||_inf
        r_ncp_d, _ = compute_ncp_dual_residual(njc, nl, nc, vio, lcgo, ccgo, cio, problem_mu, solver_info_v_aug)

        # Compute the NCP complementarity (lambda _|_ (v_plus + s)) residual as r_c := || lambda.dot(v_plus + s) ||_inf
        r_ncp_c, _ = compute_ncp_complementarity_residual(
            nl, nc, vio, lcgo, ccgo, solver_info_v_aug, solver_info_lambdas
        )

        # Compute the natural-map residuals as: r_natmap = || lambda - proj_K(lambda - (v + s)) ||_inf
        r_ncp_natmap, _ = compute_ncp_natural_map_residual(
            nl, nc, vio, lcgo, ccgo, cio, problem_mu, solver_info_v_aug, solver_info_lambdas
        )

        # Compute the iterate residual as: r_iter := || y - y_p ||_inf
        r_dx = compute_preconditioned_iterate_residual(ncts, vio, problem_P, solver_state_x, solver_state_x_p)
        r_dy = compute_preconditioned_iterate_residual(ncts, vio, problem_P, solver_state_y, solver_state_y_p)
        r_dz = compute_inverse_preconditioned_iterate_residual(ncts, vio, problem_P, solver_state_z, solver_state_z_p)

        # Compute index offset for the info of the current iteration
        iio = rio + iter

        # Store the convergence information in the solver info arrays
        solver_info_num_rho_updates[iio] = penalty.num_updates
        solver_info_norm_s[iio] = norm_s
        solver_info_norm_x[iio] = norm_x
        solver_info_norm_y[iio] = norm_y
        solver_info_norm_z[iio] = norm_z
        solver_info_r_dx[iio] = r_dx
        solver_info_r_dy[iio] = r_dy
        solver_info_r_dz[iio] = r_dz
        solver_info_r_primal[iio] = status.r_p
        solver_info_r_dual[iio] = status.r_d
        solver_info_r_compl[iio] = status.r_c
        solver_info_r_pd[iio] = r_pd
        solver_info_r_dp[iio] = r_dp
        solver_info_r_ncp_primal[iio] = r_ncp_p
        solver_info_r_ncp_dual[iio] = r_ncp_d
        solver_info_r_ncp_compl[iio] = r_ncp_c
        solver_info_r_ncp_natmap[iio] = r_ncp_natmap
        solver_info_f_ccp[iio] = f_ccp
        solver_info_f_ncp[iio] = f_ncp

        # Optionally store acceleration-relevant info if acceleration is enabled
        # NOTE: This is statically evaluated to avoid unnecessary overhead when acceleration is disabled
        if wp.static(use_acceleration):
            solver_info_a[iio] = solver_state_a[wid]
            solver_info_r_comb[iio] = status.r_a
            solver_info_r_comb_ratio[iio] = status.r_a / (status.r_a_pp)
            solver_info_num_restarts[iio] = status.num_restarts

    # Return the generated kernel
    return _collect_solver_convergence_info


def make_collect_solver_info_kernel_sparse(use_acceleration: bool):
    """
    Creates a kernel to collect solver convergence information after each iteration.

    Specializes the kernel based on whether acceleration is enabled to reduce unnecessary overhead.

    Args:
        use_acceleration (bool): Whether acceleration is enabled in the solver.

    Returns:
        wp.kernel: The kernel function to collect solver convergence information.
    """

    @wp.kernel
    def _collect_solver_convergence_info_sparse(
        # Inputs:
        problem_nl: wp.array[int32],
        problem_nc: wp.array[int32],
        problem_cio: wp.array[int32],
        problem_lcgo: wp.array[int32],
        problem_ccgo: wp.array[int32],
        problem_dim: wp.array[int32],
        problem_vio: wp.array[int32],
        problem_mu: wp.array[float32],
        problem_v_f: wp.array[float32],
        problem_P: wp.array[float32],
        solver_state_s: wp.array[float32],
        solver_state_x: wp.array[float32],
        solver_state_x_p: wp.array[float32],
        solver_state_y: wp.array[float32],
        solver_state_y_p: wp.array[float32],
        solver_state_z: wp.array[float32],
        solver_state_z_p: wp.array[float32],
        solver_state_a: wp.array[float32],
        solver_penalty: wp.array[PADMMPenalty],
        solver_status: wp.array[PADMMStatus],
        # Outputs:
        solver_info_lambdas: wp.array[float32],
        solver_info_v_plus: wp.array[float32],
        solver_info_v_aug: wp.array[float32],
        solver_info_s: wp.array[float32],
        solver_info_offset: wp.array[int32],
        solver_info_num_restarts: wp.array[int32],
        solver_info_num_rho_updates: wp.array[int32],
        solver_info_a: wp.array[float32],
        solver_info_norm_s: wp.array[float32],
        solver_info_norm_x: wp.array[float32],
        solver_info_norm_y: wp.array[float32],
        solver_info_norm_z: wp.array[float32],
        solver_info_f_ccp: wp.array[float32],
        solver_info_f_ncp: wp.array[float32],
        solver_info_r_dx: wp.array[float32],
        solver_info_r_dy: wp.array[float32],
        solver_info_r_dz: wp.array[float32],
        solver_info_r_primal: wp.array[float32],
        solver_info_r_dual: wp.array[float32],
        solver_info_r_compl: wp.array[float32],
        solver_info_r_pd: wp.array[float32],
        solver_info_r_dp: wp.array[float32],
        solver_info_r_comb: wp.array[float32],
        solver_info_r_comb_ratio: wp.array[float32],
        solver_info_r_ncp_primal: wp.array[float32],
        solver_info_r_ncp_dual: wp.array[float32],
        solver_info_r_ncp_compl: wp.array[float32],
        solver_info_r_ncp_natmap: wp.array[float32],
    ):
        # Retrieve the thread index as the world index
        wid = wp.tid()

        # Retrieve the world-specific data
        nl = problem_nl[wid]
        nc = problem_nc[wid]
        ncts = problem_dim[wid]
        cio = problem_cio[wid]
        lcgo = problem_lcgo[wid]
        ccgo = problem_ccgo[wid]
        vio = problem_vio[wid]
        rio = solver_info_offset[wid]
        penalty = solver_penalty[wid]
        status = solver_status[wid]

        # Retrieve parameters
        iter = status.iterations - 1

        # Compute additional info
        njc = ncts - (nl + 3 * nc)

        # Compute and store the norms of the current solution state
        norm_s = compute_l2_norm(ncts, vio, solver_state_s)
        norm_x = compute_l2_norm(ncts, vio, solver_state_x)
        norm_y = compute_l2_norm(ncts, vio, solver_state_y)
        norm_z = compute_l2_norm(ncts, vio, solver_state_z)

        # Compute (division safe) residual ratios
        r_pd = status.r_p / (status.r_d + FLOAT32_EPS)
        r_dp = status.r_d / (status.r_p + FLOAT32_EPS)

        # Remove preconditioning from lambdas
        compute_cwise_vec_mul(ncts, vio, problem_P, solver_state_y, solver_info_lambdas)

        # Remove preconditioning from v_plus
        compute_cwise_vec_div(ncts, vio, solver_info_v_plus, problem_P, solver_info_v_plus)

        # Compute the De Saxce correction for each contact as: s = G(v_plus)
        compute_desaxce_corrections(nc, cio, vio, ccgo, problem_mu, solver_info_v_plus, solver_info_s)

        # Compute the CCP optimization objective as: f_ccp = 0.5 * lambda.dot(v_plus + v_f)
        f_ccp = 0.5 * compute_double_dot_product(ncts, vio, solver_info_lambdas, solver_info_v_plus, problem_v_f)

        # Compute the NCP optimization objective as:  f_ncp = f_ccp + lambda.dot(s)
        f_ncp = compute_dot_product(ncts, vio, solver_info_lambdas, solver_info_s)
        f_ncp += f_ccp

        # Compute the augmented post-event constraint-space velocity as: v_aug = v_plus + s
        compute_vector_sum(ncts, vio, solver_info_v_plus, solver_info_s, solver_info_v_aug)

        # Compute the NCP primal residual as: r_p := || lambda - proj_K(lambda) ||_inf
        r_ncp_p, _ = compute_ncp_primal_residual(nl, nc, vio, lcgo, ccgo, cio, problem_mu, solver_info_lambdas)

        # Compute the NCP dual residual as: r_d := || v_plus + s - proj_dual_K(v_plus + s)  ||_inf
        r_ncp_d, _ = compute_ncp_dual_residual(njc, nl, nc, vio, lcgo, ccgo, cio, problem_mu, solver_info_v_aug)

        # Compute the NCP complementarity (lambda _|_ (v_plus + s)) residual as r_c := || lambda.dot(v_plus + s) ||_inf
        r_ncp_c, _ = compute_ncp_complementarity_residual(
            nl, nc, vio, lcgo, ccgo, solver_info_v_aug, solver_info_lambdas
        )

        # Compute the natural-map residuals as: r_natmap = || lambda - proj_K(lambda - (v + s)) ||_inf
        r_ncp_natmap, _ = compute_ncp_natural_map_residual(
            nl, nc, vio, lcgo, ccgo, cio, problem_mu, solver_info_v_aug, solver_info_lambdas
        )

        # Compute the iterate residual as: r_iter := || y - y_p ||_inf
        r_dx = compute_preconditioned_iterate_residual(ncts, vio, problem_P, solver_state_x, solver_state_x_p)
        r_dy = compute_preconditioned_iterate_residual(ncts, vio, problem_P, solver_state_y, solver_state_y_p)
        r_dz = compute_inverse_preconditioned_iterate_residual(ncts, vio, problem_P, solver_state_z, solver_state_z_p)

        # Compute index offset for the info of the current iteration
        iio = rio + iter

        # Store the convergence information in the solver info arrays
        solver_info_num_rho_updates[iio] = penalty.num_updates
        solver_info_norm_s[iio] = norm_s
        solver_info_norm_x[iio] = norm_x
        solver_info_norm_y[iio] = norm_y
        solver_info_norm_z[iio] = norm_z
        solver_info_r_dx[iio] = r_dx
        solver_info_r_dy[iio] = r_dy
        solver_info_r_dz[iio] = r_dz
        solver_info_r_primal[iio] = status.r_p
        solver_info_r_dual[iio] = status.r_d
        solver_info_r_compl[iio] = status.r_c
        solver_info_r_pd[iio] = r_pd
        solver_info_r_dp[iio] = r_dp
        solver_info_r_ncp_primal[iio] = r_ncp_p
        solver_info_r_ncp_dual[iio] = r_ncp_d
        solver_info_r_ncp_compl[iio] = r_ncp_c
        solver_info_r_ncp_natmap[iio] = r_ncp_natmap
        solver_info_f_ccp[iio] = f_ccp
        solver_info_f_ncp[iio] = f_ncp

        # Optionally store acceleration-relevant info if acceleration is enabled
        # NOTE: This is statically evaluated to avoid unnecessary overhead when acceleration is disabled
        if wp.static(use_acceleration):
            solver_info_a[iio] = solver_state_a[wid]
            solver_info_r_comb[iio] = status.r_a
            solver_info_r_comb_ratio[iio] = status.r_a / (status.r_a_pp)
            solver_info_num_restarts[iio] = status.num_restarts

    # Return the generated kernel
    return _collect_solver_convergence_info_sparse


@wp.kernel
def _apply_dual_preconditioner_to_state(
    # Inputs:
    problem_dim: wp.array[int32],
    problem_vio: wp.array[int32],
    problem_P: wp.array[float32],
    # Outputs:
    solver_x: wp.array[float32],
    solver_y: wp.array[float32],
    solver_z: wp.array[float32],
):
    # Retrieve the thread index
    wid, tid = wp.tid()

    # Retrieve the number of active constraints in the world
    ncts = problem_dim[wid]

    # Skip if row index exceed the problem size
    if tid >= ncts:
        return

    # Retrieve the vector index offset of the world
    vio = problem_vio[wid]

    # Compute the global index of the vector entry
    v_i = vio + tid

    # Retrieve the i-th entries of the target vectors
    x_i = solver_x[v_i]
    y_i = solver_y[v_i]
    z_i = solver_z[v_i]

    # Retrieve the i-th entry of the diagonal preconditioner
    P_i = problem_P[v_i]

    # Store the preconditioned i-th entry of the vector
    solver_x[v_i] = P_i * x_i
    solver_y[v_i] = P_i * y_i
    solver_z[v_i] = (1.0 / P_i) * z_i


@wp.kernel
def _apply_dual_preconditioner_to_solution(
    # Inputs:
    problem_dim: wp.array[int32],
    problem_vio: wp.array[int32],
    problem_P: wp.array[float32],
    # Outputs:
    solution_lambdas: wp.array[float32],
    solution_v_plus: wp.array[float32],
):
    # Retrieve the thread index
    wid, tid = wp.tid()

    # Retrieve the number of active constraints in the world
    ncts = problem_dim[wid]

    # Skip if row index exceed the problem size
    if tid >= ncts:
        return

    # Retrieve the vector index offset of the world
    vio = problem_vio[wid]

    # Compute the global index of the vector entry
    v_i = vio + tid

    # Retrieve the i-th entries of the target vectors
    lambdas_i = solution_lambdas[v_i]
    v_plus_i = solution_v_plus[v_i]

    # Retrieve the i-th entry of the diagonal preconditioner
    P_i = problem_P[v_i]

    # Store the preconditioned i-th entry of the vector
    solution_lambdas[v_i] = (1.0 / P_i) * lambdas_i
    solution_v_plus[v_i] = P_i * v_plus_i


@wp.kernel
def _compute_final_desaxce_correction(
    problem_nc: wp.array[int32],
    problem_cio: wp.array[int32],
    problem_ccgo: wp.array[int32],
    problem_vio: wp.array[int32],
    problem_mu: wp.array[float32],
    solver_z: wp.array[float32],
    # Outputs:
    solver_s: wp.array[float32],
):
    # Retrieve the thread index
    wid, cid = wp.tid()

    # Retrieve the number of contact active in the world
    nc = problem_nc[wid]

    # Retrieve the limit constraint group offset of the world
    ccgo = problem_ccgo[wid]

    # Skip if row index exceed the problem size or if the solver has already converged
    if cid >= nc:
        return

    # Retrieve the index offset of the vector block of the world
    cio = problem_cio[wid]

    # Retrieve the index offset of the vector block of the world
    vio = problem_vio[wid]

    # Compute the vector index offset of the corresponding contact constraint
    ccio_k = vio + ccgo + 3 * cid

    # Compute the norm of the tangential components
    vtx = solver_z[ccio_k]
    vty = solver_z[ccio_k + 1]
    vt_norm = wp.sqrt(vtx * vtx + vty * vty)

    # Store De Saxce correction for this block
    solver_s[ccio_k] = 0.0
    solver_s[ccio_k + 1] = 0.0
    solver_s[ccio_k + 2] = problem_mu[cio + cid] * vt_norm


@wp.kernel
def _compute_solution_vectors(
    # Inputs:
    problem_dim: wp.array[int32],
    problem_vio: wp.array[int32],
    solver_s: wp.array[float32],
    solver_y: wp.array[float32],
    solver_z: wp.array[float32],
    # Outputs:
    solver_v_plus: wp.array[float32],
    solver_lambdas: wp.array[float32],
):
    # Retrieve the thread index
    wid, tid = wp.tid()

    # Retrieve the total number of active constraints in the world
    ncts = problem_dim[wid]

    # Skip if row index exceed the problem size or if the solver has already converged
    if tid >= ncts:
        return

    # Retrieve the index offset of the vector block of the world
    vector_offset = problem_vio[wid]

    # Compute the index offset of the vector block of the world
    thread_offset = vector_offset + tid

    # Retrieve the solver state
    z = solver_z[thread_offset]
    s = solver_s[thread_offset]
    y = solver_y[thread_offset]

    # Update constraint velocity: v_plus = z - s;
    solver_v_plus[thread_offset] = z - s

    # Update constraint reactions: lambda = y
    solver_lambdas[thread_offset] = y
