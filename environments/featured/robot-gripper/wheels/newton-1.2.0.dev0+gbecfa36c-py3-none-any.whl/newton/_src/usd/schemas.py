# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Concrete USD schema resolvers used by :mod:`newton.usd`."""

from __future__ import annotations

import warnings
from collections.abc import Sequence
from typing import TYPE_CHECKING, ClassVar

from ..core.types import override
from ..usd.schema_resolver import PrimType, SchemaResolver
from . import utils as usd

if TYPE_CHECKING:
    from pxr import Usd

    from ..sim.builder import ModelBuilder


SchemaAttribute = SchemaResolver.SchemaAttribute


def _physx_gap_from_prim(prim: Usd.Prim) -> float | None:
    """Compute Newton gap from PhysX: contactOffset - restOffset [m].

    Returns None if either attribute is missing or -inf (PhysX uses -inf for "engine default").
    Only when both are finite do we compute a concrete gap.
    """
    contact_offset = usd.get_attribute(prim, "physxCollision:contactOffset")
    rest_offset = usd.get_attribute(prim, "physxCollision:restOffset")
    if contact_offset is None or rest_offset is None:
        return None
    inf = float("-inf")
    if contact_offset == inf or rest_offset == inf:
        return None
    return float(contact_offset) - float(rest_offset)


class SchemaResolverNewton(SchemaResolver):
    """Schema resolver for Newton-authored USD attributes.

    .. note::
        The Newton USD schema is under development and may change in the future.
    """

    name: ClassVar[str] = "newton"
    mapping: ClassVar[dict[PrimType, dict[str, SchemaAttribute]]] = {
        PrimType.SCENE: {
            "max_solver_iterations": SchemaAttribute("newton:maxSolverIterations", -1),
            "time_steps_per_second": SchemaAttribute("newton:timeStepsPerSecond", 1000),
            "gravity_enabled": SchemaAttribute("newton:gravityEnabled", True),
        },
        PrimType.JOINT: {
            # warning: there is no NewtonJointAPI, none of these are schema attributes
            "armature": SchemaAttribute("newton:armature", 0.0),
            "friction": SchemaAttribute("newton:friction", 0.0),
            "limit_linear_ke": SchemaAttribute("newton:linear:limitStiffness", 1.0e4),
            "limit_angular_ke": SchemaAttribute("newton:angular:limitStiffness", 1.0e4),
            "limit_rotX_ke": SchemaAttribute("newton:rotX:limitStiffness", 1.0e4),
            "limit_rotY_ke": SchemaAttribute("newton:rotY:limitStiffness", 1.0e4),
            "limit_rotZ_ke": SchemaAttribute("newton:rotZ:limitStiffness", 1.0e4),
            "limit_linear_kd": SchemaAttribute("newton:linear:limitDamping", 1.0e1),
            "limit_angular_kd": SchemaAttribute("newton:angular:limitDamping", 1.0e1),
            "limit_rotX_kd": SchemaAttribute("newton:rotX:limitDamping", 1.0e1),
            "limit_rotY_kd": SchemaAttribute("newton:rotY:limitDamping", 1.0e1),
            "limit_rotZ_kd": SchemaAttribute("newton:rotZ:limitDamping", 1.0e1),
            "angular_position": SchemaAttribute("newton:angular:position", 0.0),
            "linear_position": SchemaAttribute("newton:linear:position", 0.0),
            "rotX_position": SchemaAttribute("newton:rotX:position", 0.0),
            "rotY_position": SchemaAttribute("newton:rotY:position", 0.0),
            "rotZ_position": SchemaAttribute("newton:rotZ:position", 0.0),
            "angular_velocity": SchemaAttribute("newton:angular:velocity", 0.0),
            "linear_velocity": SchemaAttribute("newton:linear:velocity", 0.0),
            "rotX_velocity": SchemaAttribute("newton:rotX:velocity", 0.0),
            "rotY_velocity": SchemaAttribute("newton:rotY:velocity", 0.0),
            "rotZ_velocity": SchemaAttribute("newton:rotZ:velocity", 0.0),
        },
        PrimType.SHAPE: {
            # Mesh
            "max_hull_vertices": SchemaAttribute("newton:maxHullVertices", -1),
            # Collisions: newton margin == newton:contactMargin, newton gap == newton:contactGap
            "margin": SchemaAttribute("newton:contactMargin", 0.0),
            "gap": SchemaAttribute("newton:contactGap", float("-inf")),
            # Contact stiffness/damping
            "ke": SchemaAttribute("newton:contact_ke", None),
            "kd": SchemaAttribute("newton:contact_kd", None),
        },
        PrimType.BODY: {},
        PrimType.ARTICULATION: {
            "self_collision_enabled": SchemaAttribute("newton:selfCollisionEnabled", True),
        },
        PrimType.MATERIAL: {
            "mu_torsional": SchemaAttribute("newton:torsionalFriction", 0.25),
            "mu_rolling": SchemaAttribute("newton:rollingFriction", 0.0005),
        },
        PrimType.ACTUATOR: {},
    }


class SchemaResolverPhysx(SchemaResolver):
    """Schema resolver for PhysX USD attributes."""

    name: ClassVar[str] = "physx"
    extra_attr_namespaces: ClassVar[list[str]] = [
        # Scene and rigid body
        "physxScene",
        "physxRigidBody",
        # Collisions and meshes
        "physxCollision",
        "physxConvexHullCollision",
        "physxConvexDecompositionCollision",
        "physxTriangleMeshCollision",
        "physxTriangleMeshSimplificationCollision",
        "physxSDFMeshCollision",
        # Materials
        "physxMaterial",
        # Joints and limits
        "physxJoint",
        "physxLimit",
        # Articulations
        "physxArticulation",
        # State attributes (for joint position/velocity initialization)
        "state",
        # Drive attributes
        "drive",
    ]

    mapping: ClassVar[dict[PrimType, dict[str, SchemaAttribute]]] = {
        PrimType.SCENE: {
            "max_solver_iterations": SchemaAttribute("physxScene:maxVelocityIterationCount", 255),
            "time_steps_per_second": SchemaAttribute("physxScene:timeStepsPerSecond", 60),
            "gravity_enabled": SchemaAttribute("physxRigidBody:disableGravity", False, lambda value: not value),
        },
        PrimType.JOINT: {
            "armature": SchemaAttribute("physxJoint:armature", 0.0),
            "velocity_limit": SchemaAttribute("physxJoint:maxJointVelocity", None),
            # Per-axis linear limit aliases
            "limit_transX_ke": SchemaAttribute("physxLimit:linear:stiffness", 0.0),
            "limit_transY_ke": SchemaAttribute("physxLimit:linear:stiffness", 0.0),
            "limit_transZ_ke": SchemaAttribute("physxLimit:linear:stiffness", 0.0),
            "limit_transX_kd": SchemaAttribute("physxLimit:linear:damping", 0.0),
            "limit_transY_kd": SchemaAttribute("physxLimit:linear:damping", 0.0),
            "limit_transZ_kd": SchemaAttribute("physxLimit:linear:damping", 0.0),
            "limit_linear_ke": SchemaAttribute("physxLimit:linear:stiffness", 0.0),
            "limit_angular_ke": SchemaAttribute("physxLimit:angular:stiffness", 0.0),
            "limit_rotX_ke": SchemaAttribute("physxLimit:rotX:stiffness", 0.0),
            "limit_rotY_ke": SchemaAttribute("physxLimit:rotY:stiffness", 0.0),
            "limit_rotZ_ke": SchemaAttribute("physxLimit:rotZ:stiffness", 0.0),
            "limit_linear_kd": SchemaAttribute("physxLimit:linear:damping", 0.0),
            "limit_angular_kd": SchemaAttribute("physxLimit:angular:damping", 0.0),
            "limit_rotX_kd": SchemaAttribute("physxLimit:rotX:damping", 0.0),
            "limit_rotY_kd": SchemaAttribute("physxLimit:rotY:damping", 0.0),
            "limit_rotZ_kd": SchemaAttribute("physxLimit:rotZ:damping", 0.0),
            "angular_position": SchemaAttribute("state:angular:physics:position", 0.0),
            "linear_position": SchemaAttribute("state:linear:physics:position", 0.0),
            "rotX_position": SchemaAttribute("state:rotX:physics:position", 0.0),
            "rotY_position": SchemaAttribute("state:rotY:physics:position", 0.0),
            "rotZ_position": SchemaAttribute("state:rotZ:physics:position", 0.0),
            "angular_velocity": SchemaAttribute("state:angular:physics:velocity", 0.0),
            "linear_velocity": SchemaAttribute("state:linear:physics:velocity", 0.0),
            "rotX_velocity": SchemaAttribute("state:rotX:physics:velocity", 0.0),
            "rotY_velocity": SchemaAttribute("state:rotY:physics:velocity", 0.0),
            "rotZ_velocity": SchemaAttribute("state:rotZ:physics:velocity", 0.0),
        },
        PrimType.SHAPE: {
            # Mesh
            "max_hull_vertices": SchemaAttribute("physxConvexHullCollision:hullVertexLimit", 64),
            # Collisions: newton margin == physx restOffset, newton gap == physx contactOffset - restOffset.
            # PhysX uses -inf to mean "engine default"; treat as unset (None).
            "margin": SchemaAttribute(
                "physxCollision:restOffset", 0.0, lambda v: None if v == float("-inf") else float(v)
            ),
            "gap": SchemaAttribute(
                "physxCollision:contactOffset",
                float("-inf"),
                usd_value_getter=_physx_gap_from_prim,
                attribute_names=("physxCollision:contactOffset", "physxCollision:restOffset"),
            ),
        },
        PrimType.MATERIAL: {
            "stiffness": SchemaAttribute("physxMaterial:compliantContactStiffness", 0.0),
            "damping": SchemaAttribute("physxMaterial:compliantContactDamping", 0.0),
        },
        PrimType.BODY: {
            # Rigid body damping
            "rigid_body_linear_damping": SchemaAttribute("physxRigidBody:linearDamping", 0.0),
            "rigid_body_angular_damping": SchemaAttribute("physxRigidBody:angularDamping", 0.05),
        },
        PrimType.ARTICULATION: {
            "self_collision_enabled": SchemaAttribute("physxArticulation:enabledSelfCollisions", True),
        },
    }


def solref_to_stiffness_damping(solref: Sequence[float] | None) -> tuple[float | None, float | None]:
    """Convert MuJoCo solref (timeconst, dampratio) to internal stiffness and damping.

    Returns a tuple (stiffness, damping).

    Standard mode (timeconst > 0):
        k = 1 / (timeconst^2 * dampratio^2)
        b = 2 / timeconst
    Direct mode (both negative):
        solref encodes (-stiffness, -damping) directly
        k = -timeconst
        b = -dampratio
    """
    if solref is None:
        return None, None

    try:
        timeconst = float(solref[0])
        dampratio = float(solref[1])
    except (TypeError, ValueError, IndexError):
        return None, None

    # Direct mode: both negative → solref encodes (-stiffness, -damping)
    if timeconst < 0.0 and dampratio < 0.0:
        return -timeconst, -dampratio

    # Standard mode: compute stiffness and damping
    if timeconst <= 0.0 or dampratio <= 0.0:
        return None, None

    stiffness = 1.0 / (timeconst * timeconst * dampratio * dampratio)
    damping = 2.0 / timeconst

    return stiffness, damping


def solref_to_stiffness(solref: Sequence[float] | None) -> float | None:
    """Convert MuJoCo solref (timeconst, dampratio) to internal stiffness.

    Standard mode (timeconst > 0): k = 1 / (timeconst^2 * dampratio^2)
    Direct mode (both negative): k = -timeconst (encodes -stiffness directly)
    """
    stiffness, _ = solref_to_stiffness_damping(solref)
    return stiffness


def solref_to_damping(solref: Sequence[float] | None) -> float | None:
    """Convert MuJoCo solref (timeconst, dampratio) to internal damping.

    Standard mode (both positive): b = 2 / timeconst
    Direct mode (both negative): b = -dampratio (encodes -damping directly)
    """
    _, damping = solref_to_stiffness_damping(solref)
    return damping


def _mjc_margin_from_prim(prim: Usd.Prim) -> float | None:
    """Compute Newton margin from MuJoCo: margin - gap [m].

    MuJoCo uses ``margin`` as the full contact detection envelope and ``gap``
    as a sub-threshold that suppresses constraint activation.  Newton stores
    them separately, so: ``newton_margin = mjc_margin - mjc_gap``.

    Returns None if the MuJoCo margin attribute is not authored.
    """
    mjc_margin = usd.get_attribute(prim, "mjc:margin")
    if mjc_margin is None:
        return None
    mjc_gap = usd.get_attribute(prim, "mjc:gap")
    if mjc_gap is None:
        mjc_gap = 0.0
    result = float(mjc_margin) - float(mjc_gap)
    if result < 0.0:
        warnings.warn(
            f"Prim '{prim.GetPath()}': MuJoCo gap ({mjc_gap}) exceeds margin ({mjc_margin}), "
            f"resulting Newton margin is negative ({result}). "
            f"This may indicate an invalid MuJoCo model.",
            stacklevel=4,
        )
    return result


class SchemaResolverMjc(SchemaResolver):
    """Schema resolver for MuJoCo USD attributes."""

    name: ClassVar[str] = "mjc"

    mapping: ClassVar[dict[PrimType, dict[str, SchemaAttribute]]] = {
        PrimType.SCENE: {
            "max_solver_iterations": SchemaAttribute("mjc:option:iterations", 100),
            "time_steps_per_second": SchemaAttribute(
                "mjc:option:timestep", 0.002, lambda s: int(1.0 / s) if (s and s > 0) else None
            ),
            "gravity_enabled": SchemaAttribute("mjc:flag:gravity", True),
        },
        PrimType.JOINT: {
            "armature": SchemaAttribute("mjc:armature", 0.0),
            "friction": SchemaAttribute("mjc:frictionloss", 0.0),
            # Per-axis aliases mapped to solreflimit (MjcJointAPI authors joint limit solref here)
            "limit_transX_ke": SchemaAttribute("mjc:solreflimit", [0.02, 1.0], solref_to_stiffness),
            "limit_transY_ke": SchemaAttribute("mjc:solreflimit", [0.02, 1.0], solref_to_stiffness),
            "limit_transZ_ke": SchemaAttribute("mjc:solreflimit", [0.02, 1.0], solref_to_stiffness),
            "limit_transX_kd": SchemaAttribute("mjc:solreflimit", [0.02, 1.0], solref_to_damping),
            "limit_transY_kd": SchemaAttribute("mjc:solreflimit", [0.02, 1.0], solref_to_damping),
            "limit_transZ_kd": SchemaAttribute("mjc:solreflimit", [0.02, 1.0], solref_to_damping),
            "limit_linear_ke": SchemaAttribute("mjc:solreflimit", [0.02, 1.0], solref_to_stiffness),
            "limit_angular_ke": SchemaAttribute("mjc:solreflimit", [0.02, 1.0], solref_to_stiffness),
            "limit_rotX_ke": SchemaAttribute("mjc:solreflimit", [0.02, 1.0], solref_to_stiffness),
            "limit_rotY_ke": SchemaAttribute("mjc:solreflimit", [0.02, 1.0], solref_to_stiffness),
            "limit_rotZ_ke": SchemaAttribute("mjc:solreflimit", [0.02, 1.0], solref_to_stiffness),
            "limit_linear_kd": SchemaAttribute("mjc:solreflimit", [0.02, 1.0], solref_to_damping),
            "limit_angular_kd": SchemaAttribute("mjc:solreflimit", [0.02, 1.0], solref_to_damping),
            "limit_rotX_kd": SchemaAttribute("mjc:solreflimit", [0.02, 1.0], solref_to_damping),
            "limit_rotY_kd": SchemaAttribute("mjc:solreflimit", [0.02, 1.0], solref_to_damping),
            "limit_rotZ_kd": SchemaAttribute("mjc:solreflimit", [0.02, 1.0], solref_to_damping),
        },
        PrimType.SHAPE: {
            # Mesh
            "max_hull_vertices": SchemaAttribute("mjc:maxhullvert", -1),
            # Collisions: MuJoCo -> Newton conversion applied via getter.
            # newton_margin = mjc_margin - mjc_gap (see _mjc_margin_from_prim).
            "margin": SchemaAttribute(
                "mjc:margin",
                0.0,
                usd_value_getter=_mjc_margin_from_prim,
                attribute_names=("mjc:margin", "mjc:gap"),
            ),
            "gap": SchemaAttribute("mjc:gap", 0.0),
            # Contact stiffness/damping from per-geom solref
            "ke": SchemaAttribute("mjc:solref", [0.02, 1.0], solref_to_stiffness),
            "kd": SchemaAttribute("mjc:solref", [0.02, 1.0], solref_to_damping),
        },
        PrimType.MATERIAL: {
            # Materials
            "mu_torsional": SchemaAttribute("mjc:torsionalfriction", 0.005),
            "mu_rolling": SchemaAttribute("mjc:rollingfriction", 0.0001),
            # Contact models
            "priority": SchemaAttribute("mjc:priority", 0),
            "weight": SchemaAttribute("mjc:solmix", 1.0),
            "stiffness": SchemaAttribute("mjc:solref", [0.02, 1.0], solref_to_stiffness),
            "damping": SchemaAttribute("mjc:solref", [0.02, 1.0], solref_to_damping),
        },
        PrimType.ACTUATOR: {
            # Actuators
            "ctrl_low": SchemaAttribute("mjc:ctrlRange:min", 0.0),
            "ctrl_high": SchemaAttribute("mjc:ctrlRange:max", 0.0),
            "force_low": SchemaAttribute("mjc:forceRange:min", 0.0),
            "force_high": SchemaAttribute("mjc:forceRange:max", 0.0),
            "act_low": SchemaAttribute("mjc:actRange:min", 0.0),
            "act_high": SchemaAttribute("mjc:actRange:max", 0.0),
            "length_low": SchemaAttribute("mjc:lengthRange:min", 0.0),
            "length_high": SchemaAttribute("mjc:lengthRange:max", 0.0),
            "gainPrm": SchemaAttribute("mjc:gainPrm", [1, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
            "gainType": SchemaAttribute("mjc:gainType", "fixed"),
            "biasPrm": SchemaAttribute("mjc:biasPrm", [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
            "biasType": SchemaAttribute("mjc:biasType", "none"),
            "dynPrm": SchemaAttribute("mjc:dynPrm", [1, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
            "dynType": SchemaAttribute("mjc:dynType", "none"),
            "gear": SchemaAttribute("mjc:gear", [1, 0, 0, 0, 0, 0]),
        },
    }

    @override
    def validate_custom_attributes(self, builder: ModelBuilder) -> None:
        """
        Validate that MuJoCo custom attributes have been registered on the builder.

        Users must call :meth:`newton.solvers.SolverMuJoCo.register_custom_attributes` before parsing
        USD files with this resolver.

        Raises:
            RuntimeError: If required MuJoCo custom attributes are not registered.
        """
        has_mujoco_attrs = any(attr.namespace == "mujoco" for attr in builder.custom_attributes.values())
        if not has_mujoco_attrs:
            raise RuntimeError(
                "MuJoCo custom attributes not registered. Call "
                + "SolverMuJoCo.register_custom_attributes(builder) before parsing "
                + "USD with SchemaResolverMjc."
            )
