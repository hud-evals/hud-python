"""Renderer backend contracts for Gizmo.

The editor should depend on this module instead of depending directly on an
OpenGL implementation. Today's app uses Newton's ViewerGL backend; Hydra and
other viewport backends can implement the same contract later.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Literal, Protocol, runtime_checkable


RendererBackendName = Literal["opengl", "hydra"]


@dataclass(frozen=True, slots=True)
class RenderBackendCapabilities:
    name: RendererBackendName
    display_name: str
    realtime: bool
    editable: bool
    usd_native: bool
    hydra: bool
    pbr_materials: bool
    path_tracing: bool
    notes: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class RenderSceneDescriptor:
    """Renderer-neutral scene payload.

    A backend may render directly from a Newton model, a USD stage path, or both.
    USD remains the preferred high-fidelity interchange layer for long-term
    editor/render fidelity.
    """

    scene_path: Path | None = None
    model: Any | None = None
    state: Any | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@runtime_checkable
class RenderBackend(Protocol):
    """Minimal backend interface expected by the Gizmo editor shell."""

    @property
    def capabilities(self) -> RenderBackendCapabilities:
        ...

    def load_scene(self, scene: RenderSceneDescriptor) -> None:
        ...

    def sync_state(self, state: Any) -> None:
        ...

    def frame_selection(self) -> None:
        ...

    def shutdown(self) -> None:
        ...


class ViewerGLRenderBackend:
    """Adapter for Newton's current in-process OpenGL viewer."""

    def __init__(self, viewer: Any) -> None:
        self.viewer = viewer
        self._scene: RenderSceneDescriptor | None = None

    @property
    def capabilities(self) -> RenderBackendCapabilities:
        return RenderBackendCapabilities(
            name="opengl",
            display_name="Newton ViewerGL / OpenGL",
            realtime=True,
            editable=True,
            usd_native=False,
            hydra=False,
            pbr_materials=True,
            path_tracing=False,
            notes=(
                "Primary interactive viewport today.",
                "Fast enough for simulation authoring and debug overlays.",
                "USD material and lighting networks are approximated.",
            ),
        )

    def load_scene(self, scene: RenderSceneDescriptor) -> None:
        self._scene = scene
        if scene.model is not None:
            self.viewer.set_model(scene.model)

    def sync_state(self, state: Any) -> None:
        self.viewer.log_state(state)

    def frame_selection(self) -> None:
        if hasattr(self.viewer, "_frame_camera_on_model"):
            self.viewer._frame_camera_on_model()

    def shutdown(self) -> None:
        if hasattr(self.viewer, "close"):
            self.viewer.close()


class HydraRenderBackend:
    """Placeholder contract for a future USD Hydra viewport backend."""

    @property
    def capabilities(self) -> RenderBackendCapabilities:
        return RenderBackendCapabilities(
            name="hydra",
            display_name="USD Hydra",
            realtime=True,
            editable=False,
            usd_native=True,
            hydra=True,
            pbr_materials=True,
            path_tracing=True,
            notes=(
                "Long-term high-fidelity backend target.",
                "Should render USD stages directly through Hydra delegates.",
                "Not implemented in this source tree yet.",
            ),
        )

    def load_scene(self, scene: RenderSceneDescriptor) -> None:
        del scene
        raise NotImplementedError("USD Hydra backend is planned but not implemented yet.")

    def sync_state(self, state: Any) -> None:
        del state

    def frame_selection(self) -> None:
        return

    def shutdown(self) -> None:
        return


def available_backend_capabilities() -> list[RenderBackendCapabilities]:
    """Return advertised backend capabilities for product planning/UI."""

    return [
        ViewerGLRenderBackend(viewer=None).capabilities,
        HydraRenderBackend().capabilities,
    ]
