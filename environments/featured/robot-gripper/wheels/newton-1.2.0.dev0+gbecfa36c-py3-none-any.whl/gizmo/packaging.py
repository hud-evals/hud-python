"""Packaging helpers for turning Gizmo into a downloadable app."""

from __future__ import annotations

import json
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True, slots=True)
class PackagePlan:
    app_name: str
    platform: str
    entry_point: str
    bundle_command: list[str]
    notes: list[str]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def package_plan(project_root: str | Path | None = None) -> PackagePlan:
    root = Path(project_root or Path(__file__).resolve().parents[1]).resolve()
    platform = sys.platform
    if platform == "darwin":
        command = [
            "python3",
            "-m",
            "PyInstaller",
            "--windowed",
            "--name",
            "Gizmo",
            "--collect-all",
            "newton",
            "--collect-all",
            "gizmo",
            str(root / "gizmo" / "__main__.py"),
        ]
        notes = [
            "Build from a clean virtual environment with Gizmo installed editable first.",
            "Codesigning and notarization are separate release steps.",
            "Bundle size will be large because Newton, MuJoCo, USD, Warp, and renderer dependencies are included.",
        ]
    else:
        command = ["python3", "-m", "PyInstaller", "--name", "Gizmo", str(root / "gizmo" / "__main__.py")]
        notes = [
            "Use this as a smoke packaging plan only; platform-specific installers still need dedicated work.",
            "GPU runtimes and native libraries must be validated per OS.",
        ]
    return PackagePlan(app_name="Gizmo", platform=platform, entry_point="gizmo.__main__:main", bundle_command=command, notes=notes)


def print_package_plan(project_root: str | Path | None = None) -> None:
    print(json.dumps(package_plan(project_root).to_dict(), indent=2, sort_keys=True))
