"""Discovery helpers for Newton examples and bundled assets."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class ExampleRecord:
    """A runnable Newton example."""

    name: str
    category: str
    module_path: str


@dataclass(frozen=True, slots=True)
class AssetRecord:
    """A bundled scene or robot asset."""

    name: str
    path: Path
    kind: str


@dataclass(frozen=True, slots=True)
class NewtonCatalog:
    """Catalog of local Newton examples and bundled importable assets."""

    examples: tuple[ExampleRecord, ...]
    assets: tuple[AssetRecord, ...]

    @classmethod
    def discover(cls) -> "NewtonCatalog":
        import newton.examples

        examples = tuple(
            ExampleRecord(
                name=name,
                category=_category_from_module(module_path),
                module_path=module_path,
            )
            for name, module_path in sorted(newton.examples.get_examples().items())
        )

        asset_dir = Path(newton.examples.get_asset_directory())
        assets = tuple(
            AssetRecord(name=path.name, path=path, kind=_asset_kind(path))
            for path in sorted(asset_dir.iterdir())
            if path.is_file() and _asset_kind(path) in {"USD", "MJCF", "URDF"}
        )

        return cls(examples=examples, assets=assets)


def _category_from_module(module_path: str) -> str:
    parts = module_path.split(".")
    if len(parts) >= 3:
        return parts[2].replace("_", " ").title()
    return "Other"


def _asset_kind(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix in {".usd", ".usda", ".usdc"}:
        return "USD"
    if suffix in {".xml", ".mjcf", ".njcf"}:
        return "MJCF"
    if suffix == ".urdf":
        return "URDF"
    return "Other"
