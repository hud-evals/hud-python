"""Command line entry point for Gizmo."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .catalog import NewtonCatalog
from .experiment import ExperimentConfig, run_experiment
from .importer import inspect_scene
from .packaging import print_package_plan
from .rendering import available_backend_capabilities
from .runtime import RuntimeConfig, run_headless
from .session import init_project


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Launch the native Gizmo desktop app.")
    parser.add_argument("--list-examples", action="store_true", help="Print the discovered Newton examples and exit.")
    parser.add_argument("--inspect", type=Path, help="Import and summarize a USD/MJCF/NJCF scene, then exit.")
    parser.add_argument("--smoke", action="store_true", help="Run non-graphical startup checks and exit.")
    parser.add_argument("--legacy-tk", action="store_true", help="Launch the old Tkinter shell instead of the GL shell.")
    parser.add_argument("--init-project", type=Path, help="Create a Gizmo project workspace and exit.")
    parser.add_argument("--run-headless", type=Path, help="Run a USD/MJCF/XML scene without the desktop UI.")
    parser.add_argument("--experiment", type=str, help="Name the headless run and write experiment artifacts.")
    parser.add_argument("--output-dir", type=Path, help="Directory for headless results or experiment artifacts.")
    parser.add_argument("--steps", type=int, default=240, help="Headless simulation steps.")
    parser.add_argument("--dt", type=float, default=1.0 / 240.0, help="Headless simulation timestep.")
    parser.add_argument("--substeps", type=int, default=1, help="Physics substeps per headless step.")
    parser.add_argument("--backend", default="auto", help="Headless backend: auto, mujoco-cpu, mujoco-warp, mujoco, xpbd.")
    parser.add_argument("--package-plan", action="store_true", help="Print the current desktop packaging plan and exit.")
    parser.add_argument("--render-backends", action="store_true", help="Print renderer backend capabilities and exit.")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    catalog = NewtonCatalog.discover()

    if args.init_project:
        project = init_project(args.init_project)
        print(json.dumps(project.to_dict(), indent=2, sort_keys=True))
        return 0

    if args.package_plan:
        print_package_plan()
        return 0

    if args.render_backends:
        print(json.dumps([item.to_dict() for item in available_backend_capabilities()], indent=2, sort_keys=True))
        return 0

    if args.run_headless:
        if args.experiment:
            output_dir = args.output_dir or Path("outputs") / "experiments"
            result = run_experiment(
                ExperimentConfig(
                    name=args.experiment,
                    scene_path=args.run_headless,
                    output_dir=output_dir,
                    steps=args.steps,
                    dt=args.dt,
                    substeps=args.substeps,
                    backend=args.backend,
                )
            )
        else:
            result = run_headless(
                RuntimeConfig(
                    scene_path=args.run_headless,
                    steps=args.steps,
                    dt=args.dt,
                    substeps=args.substeps,
                    backend=args.backend,
                    output_dir=args.output_dir,
                )
            )
        print(json.dumps(result.to_dict(), indent=2, sort_keys=True))
        return 0

    if args.list_examples:
        for record in catalog.examples:
            print(f"{record.name}\t{record.category}\t{record.module_path}")
        return 0

    if args.inspect:
        scene = inspect_scene(args.inspect)
        print(json.dumps(scene.to_dict(), indent=2, sort_keys=True))
        return 0

    if args.smoke:
        print(
            json.dumps(
                {
                    "examples": len(catalog.examples),
                    "assets": len(catalog.assets),
                    "status": "ok",
                },
                indent=2,
                sort_keys=True,
            )
        )
        return 0

    if args.legacy_tk:
        from .app import GizmoApp

        app = GizmoApp(catalog)
        app.run()
        return 0

    from .gl_app import main as gl_main

    return gl_main([])


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
