"""Tkinter desktop application for Gizmo."""

from __future__ import annotations

import re
import subprocess
import threading
import tkinter as tk
from importlib.util import find_spec
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from .catalog import AssetRecord, ExampleRecord, NewtonCatalog
from .importer import ImportedScene, inspect_scene
from .runner import NewtonProcessRunner


PROJECT_ROOT = Path(__file__).resolve().parents[1]


class GizmoApp:
    """Native desktop shell for browsing, importing, and running Newton scenes."""

    def __init__(self, catalog: NewtonCatalog) -> None:
        self.catalog = catalog
        self.root = tk.Tk()
        self.root.title("Gizmo")
        self.root.geometry("1320x820")
        self.root.minsize(1080, 680)

        self.runner = NewtonProcessRunner(PROJECT_ROOT)
        self.examples_by_id: dict[str, ExampleRecord] = {}
        self.assets_by_id: dict[str, AssetRecord] = {}
        self.current_scene: ImportedScene | None = None
        self.selected_example: ExampleRecord | None = None
        self.selected_asset: AssetRecord | None = None
        self.last_output_path: Path | None = None

        self.viewer_modes = {"Export USD": "usd", "Headless / Log Only": "null"}
        if find_spec("imgui_bundle"):
            self.viewer_modes = {"Live GL Window": "gl", **self.viewer_modes}
        self.viewer_var = tk.StringVar(value=next(iter(self.viewer_modes)))
        self.frames_var = tk.IntVar(value=180)
        self.output_var = tk.StringVar(value=str((PROJECT_ROOT / "outputs" / "gizmo_output.usd").resolve()))
        self.status_var = tk.StringVar(value="Ready")
        self.selection_var = tk.StringVar(value="Select an example or import a scene.")

        self._build_ui()
        self._show_viewport(
            "Gizmo",
            "Select a bundled example or import a USD/MJCF/NJCF scene. Simulations run as separate Newton processes.",
        )
        self._poll_runner_output()

    def run(self) -> None:
        self.root.mainloop()

    def _build_ui(self) -> None:
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(1, weight=1)

        toolbar = ttk.Frame(self.root, padding=(10, 8))
        toolbar.grid(row=0, column=0, sticky="ew")
        toolbar.columnconfigure(10, weight=1)

        ttk.Button(toolbar, text="Import Scene", command=self._choose_scene).grid(row=0, column=0, padx=(0, 8))
        ttk.Button(toolbar, text="Load Asset", command=self._inspect_selected_asset).grid(row=0, column=1, padx=(0, 8))
        ttk.Button(toolbar, text="Run", command=self._run_selected_example).grid(row=0, column=2, padx=(0, 4))
        ttk.Button(toolbar, text="Stop", command=self.runner.stop).grid(row=0, column=3, padx=(0, 16))

        ttk.Label(toolbar, text="Mode").grid(row=0, column=4, sticky="w")
        ttk.Combobox(
            toolbar,
            textvariable=self.viewer_var,
            values=tuple(self.viewer_modes),
            width=18,
            state="readonly",
        ).grid(row=0, column=5, padx=(6, 14))

        ttk.Label(toolbar, text="Frames").grid(row=0, column=6, sticky="w")
        ttk.Spinbox(toolbar, from_=1, to=100000, textvariable=self.frames_var, width=8).grid(
            row=0,
            column=7,
            padx=(6, 14),
        )

        ttk.Entry(toolbar, textvariable=self.output_var).grid(row=0, column=10, sticky="ew", padx=(0, 8))
        ttk.Button(toolbar, text="Output...", command=self._choose_output).grid(row=0, column=11)
        self.open_output_button = ttk.Button(toolbar, text="Open Output", command=self._open_output, state="disabled")
        self.open_output_button.grid(row=0, column=12, padx=(8, 0))

        main = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        main.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 8))

        library = ttk.Frame(main)
        library.columnconfigure(0, weight=1)
        library.rowconfigure(2, weight=1)
        library.rowconfigure(5, weight=1)
        main.add(library, weight=1)

        ttk.Label(library, text="Examples").grid(row=0, column=0, sticky="w", pady=(0, 4))
        ttk.Label(library, textvariable=self.selection_var, foreground="#555555").grid(row=1, column=0, sticky="ew")
        self.example_tree = ttk.Treeview(library, show="tree", height=16)
        self.example_tree.grid(row=2, column=0, sticky="nsew", pady=(6, 12))
        self.example_tree.bind("<<TreeviewSelect>>", self._select_example)
        self.example_tree.bind("<Double-1>", lambda _event: self._run_selected_example())
        self._fill_examples()

        ttk.Label(library, text="Bundled Assets").grid(row=3, column=0, sticky="w", pady=(0, 4))
        ttk.Label(library, text="Load explicitly to avoid accidental long imports.", foreground="#555555").grid(
            row=4,
            column=0,
            sticky="ew",
        )
        self.asset_tree = ttk.Treeview(library, show="tree", height=10)
        self.asset_tree.grid(row=5, column=0, sticky="nsew", pady=(6, 0))
        self.asset_tree.bind("<<TreeviewSelect>>", self._select_asset)
        self.asset_tree.bind("<Double-1>", lambda _event: self._inspect_selected_asset())
        self._fill_assets()

        workspace = ttk.PanedWindow(main, orient=tk.VERTICAL)
        main.add(workspace, weight=5)

        viewport_frame = ttk.Frame(workspace)
        viewport_frame.columnconfigure(0, weight=1)
        viewport_frame.rowconfigure(0, weight=1)
        self.viewport = tk.Canvas(viewport_frame, background="#111318", highlightthickness=0)
        self.viewport.grid(row=0, column=0, sticky="nsew")
        self.viewport.bind("<Configure>", lambda _event: self._redraw_viewport())
        workspace.add(viewport_frame, weight=5)

        lower = ttk.PanedWindow(workspace, orient=tk.HORIZONTAL)
        workspace.add(lower, weight=2)

        inspector_frame = ttk.Labelframe(lower, text="Inspector")
        inspector_frame.columnconfigure(0, weight=1)
        inspector_frame.rowconfigure(0, weight=1)
        self.scene_text = tk.Text(inspector_frame, height=10, wrap="word", state="disabled")
        self.scene_text.grid(row=0, column=0, sticky="nsew", padx=8, pady=8)
        lower.add(inspector_frame, weight=2)

        log_frame = ttk.Labelframe(lower, text="Simulation Log")
        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(0, weight=1)
        self.log_text = tk.Text(log_frame, height=10, wrap="word", state="disabled")
        self.log_text.grid(row=0, column=0, sticky="nsew", padx=8, pady=8)
        lower.add(log_frame, weight=3)

        status = ttk.Label(self.root, textvariable=self.status_var, anchor="w", padding=(10, 6))
        status.grid(row=2, column=0, sticky="ew")

    def _selected_viewer(self) -> str:
        return self.viewer_modes[self.viewer_var.get()]

    def _fill_examples(self) -> None:
        categories: dict[str, str] = {}
        for example in self.catalog.examples:
            parent = categories.get(example.category)
            if parent is None:
                parent = self.example_tree.insert("", "end", text=example.category, open=False)
                categories[example.category] = parent
            item_id = self.example_tree.insert(parent, "end", text=example.name)
            self.examples_by_id[item_id] = example

    def _fill_assets(self) -> None:
        groups: dict[str, str] = {}
        for asset in self.catalog.assets:
            parent = groups.get(asset.kind)
            if parent is None:
                parent = self.asset_tree.insert("", "end", text=asset.kind, open=True)
                groups[asset.kind] = parent
            item_id = self.asset_tree.insert(parent, "end", text=asset.name)
            self.assets_by_id[item_id] = asset

    def _select_example(self, _event: tk.Event) -> None:
        selected = self.example_tree.selection()
        self.selected_example = self.examples_by_id.get(selected[0]) if selected else None
        if self.selected_example is None:
            return
        self.selection_var.set(f"Example: {self.selected_example.name}")
        self._show_scene_text(
            "\n".join(
                (
                    self.selected_example.name,
                    f"Category: {self.selected_example.category}",
                    f"Module: {self.selected_example.module_path}",
                    "",
                    "Press Run to execute this example.",
                )
            )
        )
        self._show_viewport(self.selected_example.name, "Ready to run. Output and status will appear here.")

    def _select_asset(self, _event: tk.Event) -> None:
        selected = self.asset_tree.selection()
        self.selected_asset = self.assets_by_id.get(selected[0]) if selected else None
        if self.selected_asset is None:
            return
        self.selection_var.set(f"Asset: {self.selected_asset.name}")
        self._show_scene_text(
            "\n".join(
                (
                    self.selected_asset.name,
                    f"Type: {self.selected_asset.kind}",
                    f"Path: {self.selected_asset.path}",
                    "",
                    "Press Load Asset to import and inspect it.",
                )
            )
        )
        self._show_viewport(self.selected_asset.name, "Asset selected. Load it to inspect Newton model counts.")

    def _choose_scene(self) -> None:
        filename = filedialog.askopenfilename(
            title="Import USD/MJCF Scene",
            filetypes=(
                ("Newton scenes", "*.usd *.usda *.usdc *.xml *.mjcf *.njcf"),
                ("USD", "*.usd *.usda *.usdc"),
                ("MJCF/NJCF", "*.xml *.mjcf *.njcf"),
                ("All files", "*.*"),
            ),
        )
        if filename:
            self._inspect_scene(Path(filename))

    def _choose_output(self) -> None:
        filename = filedialog.asksaveasfilename(
            title="Choose USD output",
            defaultextension=".usd",
            filetypes=(("USD", "*.usd *.usda"), ("All files", "*.*")),
        )
        if filename:
            self.output_var.set(filename)

    def _inspect_selected_asset(self) -> None:
        if self.selected_asset is None:
            messagebox.showinfo("Load Asset", "Select a bundled USD, MJCF, or NJCF asset first.")
            return
        if self.selected_asset.kind == "URDF":
            self._show_scene_text(
                f"{self.selected_asset.name}\n\nURDF is visible in the asset browser. Import support is currently focused on USD and MJCF/NJCF."
            )
            return
        self._inspect_scene(self.selected_asset.path)

    def _inspect_scene(self, path: Path) -> None:
        self.status_var.set(f"Importing {path.name}...")
        self._show_viewport(path.name, "Importing scene...")
        self._show_scene_text(f"Importing {path}...")

        def worker() -> None:
            try:
                scene = inspect_scene(path)
            except Exception as exc:  # noqa: BLE001
                self.root.after(0, lambda: self._show_import_error(path, exc))
                return
            self.root.after(0, lambda: self._show_scene(scene))

        threading.Thread(target=worker, daemon=True).start()

    def _show_scene(self, scene: ImportedScene) -> None:
        self.current_scene = scene
        lines = [
            scene.path.name,
            f"Path: {scene.path}",
            f"Type: {scene.kind}",
            "",
            f"Bodies: {scene.body_count}",
            f"Joints: {scene.joint_count}",
            f"Shapes: {scene.shape_count}",
            f"Particles: {scene.particle_count}",
            f"Articulations: {scene.articulation_count}",
            f"Worlds: {scene.world_count}",
        ]
        if scene.metadata:
            lines.append("")
            lines.append("Metadata:")
            for key, value in sorted(scene.metadata.items()):
                if isinstance(value, list):
                    lines.append(f"  {key}:")
                    lines.extend(f"    - {item}" for item in value)
                else:
                    lines.append(f"  {key}: {value}")
        self._show_scene_text("\n".join(lines))
        self._show_viewport(
            scene.path.name,
            f"{scene.kind} loaded: {scene.body_count} bodies, {scene.joint_count} joints, {scene.shape_count} shapes",
        )
        self.status_var.set(f"Imported {scene.path.name}")

    def _show_import_error(self, path: Path, exc: Exception) -> None:
        self.status_var.set(f"Import failed: {path.name}")
        self._show_viewport(path.name, "Import failed. See inspector for details.")
        self._show_scene_text(f"Could not import {path}\n\n{type(exc).__name__}: {exc}")

    def _run_selected_example(self) -> None:
        if self.selected_example is None:
            messagebox.showinfo("Run Example", "Select an example first.")
            return

        viewer = self._selected_viewer()
        output_path = Path(self.output_var.get()).expanduser().resolve() if viewer == "usd" else None
        self.last_output_path = output_path
        self.open_output_button.configure(state="disabled")
        try:
            self.runner.run_example(
                self.selected_example.name,
                viewer=viewer,
                num_frames=int(self.frames_var.get()),
                output_path=output_path,
            )
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Run Example", str(exc))
            return

        if viewer == "gl":
            detail = (
                f"Launching {self.selected_example.name} in Newton's live GL viewer.\n"
                "A separate simulation window should appear. Close that window or press Stop to end the run."
            )
        elif viewer == "usd":
            detail = (
                f"Exporting {self.selected_example.name} to USD.\n"
                f"This mode writes a file instead of opening a live viewport: {output_path}"
            )
        else:
            detail = f"Running {self.selected_example.name} headless. Watch the simulation log for progress."
        self._show_viewport(self.selected_example.name, detail)
        self.status_var.set(f"Running {self.selected_example.name}")

    def _poll_runner_output(self) -> None:
        while not self.runner.output.empty():
            self._append_log(self.runner.output.get_nowait())
        self.root.after(100, self._poll_runner_output)

    def _show_viewport(self, title: str, detail: str) -> None:
        self._viewport_title = title
        self._viewport_detail = detail
        self._redraw_viewport()

    def _redraw_viewport(self) -> None:
        title = getattr(self, "_viewport_title", "Gizmo")
        detail = getattr(self, "_viewport_detail", "")
        width = max(self.viewport.winfo_width(), 1)
        height = max(self.viewport.winfo_height(), 1)
        self.viewport.delete("all")
        self.viewport.create_rectangle(0, 0, width, height, fill="#111318", outline="")
        self.viewport.create_line(0, 46, width, 46, fill="#2b3038")
        self.viewport.create_text(24, 23, text=title, fill="#f2f4f8", anchor="w", font=("Helvetica", 18, "bold"))
        self.viewport.create_text(24, 82, text=detail, fill="#c8d0dd", anchor="nw", width=max(width - 48, 120), font=("Helvetica", 13))
        self.viewport.create_rectangle(24, height - 56, width - 24, height - 24, outline="#343b46", fill="#171a20")
        self.viewport.create_text(40, height - 40, text=self.status_var.get(), fill="#8fa3bf", anchor="w", font=("Helvetica", 12))

    def _show_scene_text(self, text: str) -> None:
        self.scene_text.configure(state="normal")
        self.scene_text.delete("1.0", tk.END)
        self.scene_text.insert(tk.END, text)
        self.scene_text.configure(state="disabled")

    def _append_log(self, text: str) -> None:
        self._remember_output_path(text)
        self.log_text.configure(state="normal")
        self.log_text.insert(tk.END, text)
        self.log_text.see(tk.END)
        self.log_text.configure(state="disabled")
        if "[process exited with code 0]" in text:
            self.status_var.set("Simulation finished")
            if self.last_output_path is not None and self.last_output_path.exists():
                self.open_output_button.configure(state="normal")
                self._show_viewport(
                    "USD Export Complete",
                    f"Saved to {self.last_output_path}\nUse Open Output to view it in your installed USD viewer.",
                )
            self._redraw_viewport()
        elif "[process exited with code" in text:
            self.status_var.set("Simulation failed")
            self._redraw_viewport()

    def _remember_output_path(self, text: str) -> None:
        match = re.search(r"USD output saved in:\s*(.+)", text)
        if match:
            self.last_output_path = Path(match.group(1).strip()).expanduser().resolve()

    def _open_output(self) -> None:
        if self.last_output_path is None or not self.last_output_path.exists():
            messagebox.showinfo("Open Output", "No exported USD output is available yet.")
            return
        try:
            subprocess.Popen(["open", str(self.last_output_path)])
        except OSError as exc:
            messagebox.showerror("Open Output", str(exc))
