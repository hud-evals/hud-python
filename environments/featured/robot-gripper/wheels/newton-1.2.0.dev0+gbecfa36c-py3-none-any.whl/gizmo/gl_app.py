"""Single-window OpenGL Gizmo interface."""

from __future__ import annotations

import copy
import gc
import hashlib
import importlib
import subprocess
import sys
import time
import traceback
import warnings
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import warp as wp

import newton
import newton.examples
from newton.viewer import ViewerGL

from .catalog import ExampleRecord, NewtonCatalog
from .rendering import RenderSceneDescriptor, ViewerGLRenderBackend


PROJECT_ROOT = Path(__file__).resolve().parents[1]
wp.config.kernel_cache_dir = str((PROJECT_ROOT / ".cache" / "warp").resolve())


@dataclass(slots=True)
class GizmoMessage:
    title: str
    detail: str
    level: str = "info"


@dataclass(slots=True)
class SceneSourceSummary:
    kind: str
    textures: int = 0
    missing_textures: int = 0
    lights: int = 0
    bodies: int = 0
    joints: int = 0
    meshes: int = 0
    inline_meshes: int = 0
    materials: int = 0
    articulations: int = 0
    notes: tuple[str, ...] = ()


@dataclass(slots=True)
class PhysicsSummary:
    solver: str
    dynamic_bodies: int = 0
    static_bodies: int = 0
    visual_shapes: int = 0
    collision_shapes: int = 0
    visual_only_shapes: int = 0
    collision_only_shapes: int = 0
    visual_collision_shapes: int = 0
    disabled_joints: int = 0
    gravity: tuple[float, float, float] | None = None
    mass_range: tuple[float, float] | None = None
    friction_range: tuple[float, float] | None = None
    restitution_range: tuple[float, float] | None = None


@dataclass(slots=True)
class ImportedVisualOverlay:
    name: str
    source_path: str
    points: Any
    indices: Any
    normals: Any | None = None
    uvs: Any | None = None
    texture: Any | None = None
    color: tuple[float, float, float] | None = None
    roughness: float | None = None
    metallic: float | None = None


@dataclass(slots=True)
class ImportedStateSnapshot:
    body_q: Any | None = None
    body_qd: Any | None = None
    joint_q: Any | None = None
    joint_qd: Any | None = None
    control_joint_target_pos: Any | None = None


@dataclass(slots=True)
class JointDriveControl:
    joint_index: int
    dof_index: int
    coord_index: int
    label: str
    kind: str
    target: float
    lower: float
    upper: float


class GizmoViewer(ViewerGL):
    """Newton ViewerGL with Gizmo chrome instead of the default Newton panel."""

    def __init__(self, *args, **kwargs) -> None:
        self.gizmo: GizmoGLApp | None = None
        super().__init__(*args, **kwargs)
        self.renderer.set_title("Gizmo")

    def _render_ui(self) -> None:
        if self.gizmo is not None:
            self.gizmo.render_ui(self.ui.imgui, self.ui.io)
            self._render_scalar_plots()
            for callback in self._ui_callbacks["free"]:
                callback(self.ui.imgui)
            return
        super()._render_ui()

    def on_mouse_press(self, x: float, y: float, button: int, modifiers: int):
        handled = False
        if self.gizmo is not None:
            handled = self.gizmo.handle_mouse_press(x, y, button, modifiers)
        if not handled:
            super().on_mouse_press(x, y, button, modifiers)

    def on_mouse_drag(self, x: float, y: float, dx: float, dy: float, buttons: int, modifiers: int):
        handled = False
        if self.gizmo is not None:
            handled = self.gizmo.handle_mouse_drag(x, y, dx, dy, buttons, modifiers)
        if not handled:
            super().on_mouse_drag(x, y, dx, dy, buttons, modifiers)

    def on_mouse_release(self, x: float, y: float, button: int, modifiers: int):
        handled = False
        if self.gizmo is not None:
            handled = self.gizmo.handle_mouse_release(x, y, button, modifiers)
        if not handled:
            super().on_mouse_release(x, y, button, modifiers)

    def on_key_press(self, symbol: int, modifiers: int):
        handled = False
        if self.gizmo is not None:
            handled = self.gizmo.handle_key_press(symbol, modifiers)
        if not handled:
            super().on_key_press(symbol, modifiers)


class GizmoGLApp:
    """Viewport-first Gizmo shell running simulations in the same GL window."""

    def __init__(self, catalog: NewtonCatalog, viewer: GizmoViewer, eval_mode: bool = False) -> None:
        self.catalog = catalog
        self.viewer = viewer
        self.eval_mode = eval_mode
        self.viewer.gizmo = self
        if not eval_mode:
            # In eval/observer mode the simulation is owned by an external
            # harness (e.g. a HUD eval), so the GUI must never reset or drive it.
            self.viewer.set_reset_callback(self.reset_example)
        self.render_backend = ViewerGLRenderBackend(viewer)

        self.categories = self._group_examples(catalog.examples)
        self.selected_category = next(iter(self.categories), "Basic")
        self.selected_example_name = self.categories.get(self.selected_category, [None])[0]
        self.current_example_name: str | None = None
        self.current_example: Any | None = None
        self.current_example_class: type | None = None
        self.current_args: Any | None = None
        self.current_module_path: str | None = None
        self.example_side_callback: Any | None = None
        self.current_static_state: Any | None = None
        self.current_source_summary: SceneSourceSummary | None = None
        self.current_scene_path: Path | None = None
        self.imported_model: Any | None = None
        self.imported_state_0: Any | None = None
        self.imported_state_1: Any | None = None
        self.imported_control: Any | None = None
        self.imported_contacts: Any | None = None
        self.imported_solver: Any | None = None
        self.imported_solver_name = ""
        self.imported_use_mujoco_contacts = False
        self.imported_use_mujoco_cpu = False
        self._native_mujoco_last_refresh_reason = ""
        self._native_contact_peak = 0
        self._last_native_contact_log_time = 0.0
        self.imported_simulation_enabled = False
        self.imported_scene_kind = ""
        self.imported_render_dirty = False
        self.imported_pose_dirty = False
        self.imported_initial_snapshot: ImportedStateSnapshot | None = None
        self._body_component_cache: dict[int, list[int]] = {}
        self.imported_visual_overlays: list[ImportedVisualOverlay] = []
        self.imported_visual_overlays_uploaded = False
        self.imported_joint_controls: list[JointDriveControl] = []
        self.imported_physics_summary: PhysicsSummary | None = None
        self.selected_body_index: int | None = None
        self.selected_joint_control: JointDriveControl | None = None
        self._drag_body_index: int | None = None
        self._drag_last_time: float | None = None
        self._base_shape_colors: Any | None = None
        self._highlight_shape_indices: list[int] = []
        self._selection_blue = (0.125, 0.318, 1.0)
        self._last_click_time = 0.0
        self._last_click_xy = (0.0, 0.0)
        self.imported_sim_dt = 1.0 / 60.0
        self.imported_sim_substeps = 1
        self.imported_step_hz = 12.0
        self._last_imported_step_time = 0.0
        self.pending_file_dialog = False
        self._pending_import_path: Path | None = None

        self.messages: list[GizmoMessage] = [
            GizmoMessage("Ready", "Choose an example, or import a USD/MJCF scene. Everything renders in this window.")
        ]
        self.autoload_on_start = False
        self._pending_load: str | None = self.selected_example_name if self.autoload_on_start else None
        self._left_width = 520.0
        self._right_width = 620.0
        self._library_visible = not eval_mode
        self._inspector_visible = True
        self._top_height = 104.0
        self._bottom_height = 68.0
        self._frame_count = 0
        self._ui_scaled = False
        # Eval/observer mode: live status pushed in by the external harness.
        self.eval_scene: str | None = None
        self.eval_step = 0
        self.eval_time = 0.0

    def run(self) -> None:
        while self.viewer.is_running():
            if self._pending_import_path is not None:
                path, self._pending_import_path = self._pending_import_path, None
                self.import_scene(path)

            if self._pending_load is not None:
                name, self._pending_load = self._pending_load, None
                self.load_example(name)

            if self.current_example is None:
                self.viewer.begin_frame(0.0)
                if self.imported_state_0 is not None:
                    self._ensure_imported_visual_overlays_uploaded()
                    self._handle_joint_keyboard_input()
                    step_imported = False
                    if self.imported_simulation_enabled:
                        step_imported = self.viewer.should_step() and self._should_step_imported_scene()
                    elif self.viewer._step_requested:
                        step_imported = self.viewer.should_step()
                    if step_imported:
                        try:
                            self._step_imported_scene(apply_viewer_forces=True)
                            self.imported_render_dirty = True
                        except Exception as exc:  # noqa: BLE001
                            self.imported_simulation_enabled = False
                            self.viewer._paused = True
                            self._push_message("Simulation stopped", f"{type(exc).__name__}: {exc}", "error")
                            self._push_message("Traceback", traceback.format_exc(limit=8), "error")
                    if self.imported_render_dirty:
                        self.viewer.log_state(self.imported_state_0)
                        if self.imported_contacts is not None and self.viewer.show_contacts:
                            self.viewer.log_contacts(self.imported_contacts, self.imported_state_0)
                        self.imported_render_dirty = False
                elif self.current_static_state is not None:
                    self.viewer.log_state(self.current_static_state)
                self.viewer.end_frame()
                continue

            if self.viewer.should_step():
                with wp.ScopedTimer("gizmo.step", active=False):
                    self.current_example.step()

            with wp.ScopedTimer("gizmo.render", active=False):
                self.current_example.render()
            self._frame_count += 1

        self.viewer.close()

    def populate_external(self, *, model: Any, scene_name: str, solver_name: str) -> None:
        """Display an externally-driven simulation (e.g. a HUD eval) read-only.

        The physics is stepped by the external harness; this only wires the
        model and its summaries into the Inspector so the panels render. The
        caller owns the viewport, calling ``viewer.set_model`` once and
        ``viewer.log_state`` every frame. Safe to call again on scene change.

        Args:
            model: The finalized Newton model the harness is simulating.
            scene_name: Human-readable scene id, shown in the HUD Eval panel.
            solver_name: Solver label for the Physics summary (e.g. "SolverMuJoCo").
        """
        self.imported_model = model
        # A non-None static state is the flag the Inspector uses to show stats.
        self.current_static_state = model.state()
        self.current_example = None
        self.current_example_name = scene_name
        self.eval_scene = scene_name
        try:
            self.imported_joint_controls = self._build_joint_drive_controls(model)
        except Exception:  # noqa: BLE001 — display-only; never block the eval
            self.imported_joint_controls = []
        try:
            self.imported_physics_summary = self._summarize_model_physics(model, solver_name)
        except Exception:  # noqa: BLE001
            self.imported_physics_summary = None
        self._push_message("HUD eval", f"Visualizing '{scene_name}' — physics driven by the eval harness.")

    def render_ui(self, imgui, io) -> None:
        self._apply_ui_scale(imgui)
        self._consume_file_dialog()
        display_w = io.display_size[0]
        display_h = io.display_size[1]
        self._update_layout(display_w)
        self._render_top_bar(imgui, display_w)
        if self._library_visible:
            self._render_library(imgui, display_h)
        if self._inspector_visible:
            self._render_inspector(imgui, display_w, display_h)
        self._render_bottom_bar(imgui, display_w, display_h)

    def _apply_ui_scale(self, imgui) -> None:
        if self._ui_scaled:
            return
        style = imgui.get_style()
        style.scale_all_sizes(1.85)
        style.font_scale_main = 2.05
        style.window_padding = imgui.ImVec2(22.0, 18.0)
        style.frame_padding = imgui.ImVec2(18.0, 11.0)
        style.item_spacing = imgui.ImVec2(16.0, 14.0)
        style.window_rounding = 4.0
        style.frame_rounding = 3.0
        self._ui_scaled = True

    def _update_layout(self, display_w: float) -> None:
        self._left_width = min(max(display_w * 0.22, 500.0), 680.0)
        self._right_width = min(max(display_w * 0.27, 580.0), 760.0)

    def load_example(self, name: str | None = None) -> None:
        if name is None:
            name = self.selected_example_name
        if not name:
            return

        examples = {example.name: example for example in self.catalog.examples}
        record = examples.get(name)
        if record is None:
            self._push_message("Example not found", str(name), "error")
            return

        self._push_message("Loading", record.name)
        self.current_example = None
        self.current_example_class = None
        self.current_static_state = None
        self._clear_imported_simulation()
        self.example_side_callback = None
        self.viewer.clear_model()
        gc.collect()

        try:
            module = importlib.import_module(record.module_path)
            parser = getattr(module.Example, "create_parser", newton.examples.create_parser)()
            args = newton.examples.default_args(parser)
            args.viewer = "gl"
            args.headless = False
            args.output_path = str(PROJECT_ROOT / "outputs" / f"{record.name}.usd")
            example = module.Example(self.viewer, args)
        except Exception as exc:  # noqa: BLE001
            self._push_message("Load failed", f"{type(exc).__name__}: {exc}", "error")
            self._push_message("Traceback", traceback.format_exc(limit=8), "error")
            return

        self.current_example = example
        self.current_example_class = type(example)
        self.current_args = copy.deepcopy(args)
        self.current_example_name = record.name
        self.current_module_path = record.module_path
        self.selected_example_name = record.name
        self.viewer._paused = False

        if hasattr(example, "gui"):
            self.example_side_callback = lambda ui, ex=example: ex.gui(ui)

        self._push_message("Running", f"{record.name} is rendering in the main viewport.")

    def import_scene(self, path: str | Path) -> None:
        scene_path = Path(path).expanduser().resolve()
        if not scene_path.exists():
            self._push_message("Import failed", f"File does not exist: {scene_path}", "error")
            return

        self._push_message("Importing", str(scene_path))
        self.current_example = None
        self.current_example_class = None
        self.current_args = None
        self.current_module_path = None
        self.example_side_callback = None
        self.current_source_summary = None
        self.current_scene_path = None
        self._clear_imported_simulation()
        self.viewer.clear_model()
        gc.collect()

        try:
            builder = newton.ModelBuilder()
            newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
            scene_kind = self._detect_scene_kind(scene_path)
            summary = self._summarize_source_scene(scene_path, scene_kind)
            import_path = scene_path
            import_metadata: Any = {}
            if scene_kind == "mjcf":
                import_path, materialized_meshes = self._materialize_inline_mjcf_meshes(scene_path)
                if materialized_meshes:
                    summary.inline_meshes = materialized_meshes
                    self._push_message(
                        "Prepared MJCF meshes",
                        f"Converted {materialized_meshes} inline meshes to cached OBJ files so Newton can import textured visual geometry.",
                    )
            with warnings.catch_warnings(record=True) as caught_warnings:
                warnings.simplefilter("always")
                if scene_kind == "usd":
                    import_metadata = builder.add_usd(
                        str(import_path),
                        load_visual_shapes=True,
                        hide_collision_shapes=True,
                        skip_mesh_approximation=True,
                    )
                elif scene_kind == "mjcf":
                    import_metadata = builder.add_mjcf(str(import_path), parse_meshes=True, parse_visuals=True)
                elif scene_kind == "urdf":
                    import_metadata = builder.add_urdf(str(import_path))
                else:
                    raise ValueError(f"Unsupported scene extension: {scene_path.suffix}")
            model = builder.finalize(skip_validation_joints=True)
            self._prepare_imported_visuals(model, scene_path if scene_kind == "usd" else None)
            state = model.state()
            newton.eval_fk(model, model.joint_q, model.joint_qd, state)
            self.render_backend.load_scene(RenderSceneDescriptor(scene_path=scene_path, model=model))
            self._upload_imported_visual_overlays()
            self._prepare_imported_viewport()
            self._prepare_imported_lighting(scene_path if scene_kind == "usd" else None)
            self._prepare_imported_simulation(model, state, scene_kind, import_metadata)
            self._base_shape_colors = model.shape_color.numpy().copy() if getattr(model, "shape_color", None) is not None else None
            textured_shapes = self._count_textured_shapes(model)
        except Exception as exc:  # noqa: BLE001
            self._push_message("Import failed", f"{type(exc).__name__}: {exc}", "error")
            self._push_message("Traceback", traceback.format_exc(limit=8), "error")
            return

        self.current_static_state = state
        self.current_source_summary = summary
        self.current_scene_path = scene_path
        self.current_example_name = scene_path.name
        self.selected_example_name = None
        self.viewer._paused = True
        self._push_message(
            "Imported",
            f"{scene_path.name} loaded as {scene_kind.upper()} with {model.body_count} bodies, {model.joint_count} joints, and {model.shape_count} shapes.",
        )
        if summary.textures:
            self._push_message(
                "Texture coverage",
                f"Source declares {summary.textures} textures; Newton model has {textured_shapes} textured mesh shapes. Missing texture files: {summary.missing_textures}.",
                "warning" if summary.missing_textures else "info",
            )
        if summary.lights:
            self._push_message(
                "Lighting note",
                f"Source declares {summary.lights} lights. Gizmo uses the first authored USD distant light when available, with neutral realtime ambient/shadow settings for the GL viewport.",
            )
        for warning in caught_warnings[:4]:
            self._push_message("Import warning", str(warning.message), "warning")
        if self.imported_joint_controls:
            self._push_message(
                "Joint controls ready",
                f"{len(self.imported_joint_controls)} single-axis joints can be driven from Inspector > Joint Drives. Press Resume to simulate.",
            )
        if self.imported_physics_summary is not None:
            self._push_message("Physics summary", self._format_physics_summary(self.imported_physics_summary))

    def _clear_imported_simulation(self) -> None:
        self.imported_model = None
        self.imported_state_0 = None
        self.imported_state_1 = None
        self.imported_control = None
        self.imported_contacts = None
        self.imported_solver = None
        self.imported_solver_name = ""
        self.imported_use_mujoco_contacts = False
        self.imported_use_mujoco_cpu = False
        self._native_mujoco_last_refresh_reason = ""
        self._native_contact_peak = 0
        self._last_native_contact_log_time = 0.0
        self.imported_simulation_enabled = False
        self.imported_scene_kind = ""
        self.imported_render_dirty = False
        self.imported_pose_dirty = False
        self.imported_initial_snapshot = None
        self._body_component_cache = {}
        self.imported_visual_overlays = []
        self.imported_visual_overlays_uploaded = False
        self.imported_joint_controls = []
        self.imported_physics_summary = None
        self.selected_body_index = None
        self.selected_joint_control = None
        self._base_shape_colors = None
        self._highlight_shape_indices = []

    def _prepare_imported_visuals(self, model: Any, usd_path: Path | None = None) -> None:
        shape_colors = model.shape_color.numpy() if getattr(model, "shape_color", None) is not None else None
        for source in getattr(model, "shape_source", []):
            if getattr(source, "texture", None) is not None:
                source.color = (1.0, 1.0, 1.0)
        if shape_colors is not None:
            for index, source in enumerate(getattr(model, "shape_source", [])):
                if getattr(source, "texture", None) is not None:
                    shape_colors[index] = (1.0, 1.0, 1.0)
            model.shape_color.assign(shape_colors)
        if usd_path is not None:
            self.imported_visual_overlays = self._build_usd_visual_overlays(model, usd_path)

    @staticmethod
    def _build_usd_visual_overlays(model: Any, usd_path: Path) -> list[ImportedVisualOverlay]:
        if getattr(model, "shape_flags", None) is None:
            return []
        labels = GizmoGLApp._shape_labels(model)
        if not labels:
            return []
        try:
            import numpy as np
            from pxr import Usd, UsdGeom
            from newton._src.usd import utils as usd_utils
        except Exception:
            return []

        stage = Usd.Stage.Open(str(usd_path))
        if stage is None:
            return []

        visible_flag = int(newton.ShapeFlags.VISIBLE)
        collision_flag = int(newton.ShapeFlags.COLLIDE_SHAPES)
        flags = model.shape_flags.numpy()
        label_to_index = {label: index for index, label in enumerate(labels)}
        xform_cache = UsdGeom.XformCache()
        overlays: list[ImportedVisualOverlay] = []

        for index, label in enumerate(labels):
            if not (int(flags[index]) & collision_flag) or int(flags[index]) & visible_flag:
                continue
            visual_label = GizmoGLApp._matching_visual_label(label)
            if not visual_label:
                continue
            visual_index = label_to_index.get(visual_label)
            if visual_index is not None and int(flags[visual_index]) & visible_flag:
                continue

            visual_prim = stage.GetPrimAtPath(visual_label)
            if not visual_prim or not visual_prim.IsValid():
                continue
            try:
                render_mesh = usd_utils.get_mesh(
                    visual_prim,
                    load_normals=True,
                    load_uvs=True,
                    preserve_facevarying_uvs=False,
                )
                material = usd_utils.resolve_material_properties_for_prim(visual_prim)
            except Exception:
                continue

            transform = np.array(xform_cache.GetLocalToWorldTransform(visual_prim), dtype=np.float64)
            local_points = np.asarray(render_mesh.vertices, dtype=np.float64)
            hom_points = np.ones((len(local_points), 4), dtype=np.float64)
            hom_points[:, :3] = local_points
            points = (hom_points @ transform)[:, :3].astype(np.float32)
            normals = None
            if render_mesh.normals is not None:
                normals = np.asarray(render_mesh.normals, dtype=np.float64) @ transform[:3, :3]
                normals = normals.astype(np.float32)
                lengths = np.linalg.norm(normals, axis=1, keepdims=True)
                normals = normals / np.clip(lengths, 1.0e-12, None)

            texture = material.get("texture")
            color = None
            if texture is not None:
                color = (1.0, 1.0, 1.0)
            elif material.get("color") is not None:
                color = tuple(float(c) for c in material["color"])
            else:
                color = (0.72, 0.72, 0.72)

            overlays.append(
                ImportedVisualOverlay(
                    name=f"usd_visual_overlay_{hashlib.sha1(visual_label.encode('utf-8')).hexdigest()[:12]}",
                    source_path=visual_label,
                    points=wp.array(points, dtype=wp.vec3, device=model.device),
                    indices=wp.array(render_mesh.indices.astype(np.int32), dtype=wp.int32, device=model.device),
                    normals=wp.array(normals, dtype=wp.vec3, device=model.device) if normals is not None else None,
                    uvs=wp.array(render_mesh.uvs.astype(np.float32), dtype=wp.vec2, device=model.device)
                    if render_mesh.uvs is not None
                    else None,
                    texture=texture,
                    color=color,
                    roughness=float(material["roughness"]) if material.get("roughness") is not None else None,
                    metallic=float(material["metallic"]) if material.get("metallic") is not None else None,
                )
            )

        return overlays

    def _upload_imported_visual_overlays(self) -> None:
        if self.imported_visual_overlays_uploaded:
            return
        for overlay in self.imported_visual_overlays:
            self.viewer.log_mesh(
                overlay.name,
                overlay.points,
                overlay.indices,
                overlay.normals,
                overlay.uvs,
                texture=overlay.texture,
                hidden=False,
                backface_culling=False,
                color=overlay.color,
                roughness=overlay.roughness,
                metallic=overlay.metallic,
            )
        self.imported_visual_overlays_uploaded = True

    def _ensure_imported_visual_overlays_uploaded(self) -> None:
        if not self.imported_visual_overlays:
            return
        objects = getattr(self.viewer, "objects", {})
        missing = any(overlay.name not in objects for overlay in self.imported_visual_overlays)
        missing_texture = any(
            overlay.texture is not None
            and overlay.name in objects
            and getattr(objects[overlay.name], "texture_id", None) is None
            for overlay in self.imported_visual_overlays
        )
        if missing or missing_texture:
            self.imported_visual_overlays_uploaded = False
            self._upload_imported_visual_overlays()

    @staticmethod
    def _shape_labels(model: Any) -> list[str]:
        raw_labels = getattr(model, "shape_key", None) or getattr(model, "shape_label", None) or []
        return [str(label) for label in raw_labels]

    @staticmethod
    def _matching_visual_label(label: str) -> str | None:
        if label.endswith("_collision"):
            return f"{label[:-10]}_mesh"
        name = label.rsplit("/", 1)[-1]
        if name.endswith("_collision"):
            parent = label.rsplit("/", 1)[0]
            return f"{parent}/{name[:-10]}_mesh"
        return None

    def _prepare_imported_viewport(self) -> None:
        self.viewer.show_visual = True
        self.viewer.show_collision = False
        self.imported_render_dirty = True
        for obj in getattr(self.viewer, "objects", {}).values():
            if hasattr(obj, "backface_culling"):
                obj.backface_culling = False

    def _prepare_imported_lighting(self, usd_path: Path | None = None) -> None:
        import numpy as np

        renderer = self.viewer.renderer
        renderer.draw_shadows = True
        renderer.draw_sky = True
        renderer.spotlight_enabled = False
        renderer._exposure = 1.15
        renderer._diffuse_scale = 0.82
        renderer._specular_scale = 0.45
        renderer.ambient_sky = (0.72, 0.74, 0.8)
        renderer.ambient_ground = (0.42, 0.42, 0.45)
        renderer._light_color = (0.95, 0.94, 0.9)
        renderer._sun_direction = np.array((0.35, -0.45, 0.82), dtype=np.float32)

        if usd_path is None:
            return
        authored = self._read_usd_distant_light(usd_path)
        if authored is not None:
            direction, color, intensity = authored
            renderer._sun_direction = np.array(direction, dtype=np.float32)
            strength = max(0.55, min(1.4, intensity / 500.0))
            renderer._light_color = tuple(max(0.0, min(1.0, c * strength)) for c in color)

    @staticmethod
    def _read_usd_distant_light(usd_path: Path) -> tuple[tuple[float, float, float], tuple[float, float, float], float] | None:
        try:
            from pxr import Usd, UsdGeom, UsdLux
            import numpy as np
        except Exception:
            return None
        stage = Usd.Stage.Open(str(usd_path))
        if stage is None:
            return None
        cache = UsdGeom.XformCache()
        for prim in stage.Traverse():
            light = UsdLux.DistantLight(prim)
            if not light:
                continue
            color_value = light.GetColorAttr().Get() or (1.0, 1.0, 1.0)
            intensity_value = light.GetIntensityAttr().Get()
            intensity = float(intensity_value) if intensity_value is not None else 500.0
            try:
                transform = cache.GetLocalToWorldTransform(prim)
                direction = -np.array(transform.TransformDir((0.0, 0.0, -1.0)), dtype=float)
            except Exception:
                direction = np.array((0.35, -0.45, 0.82), dtype=float)
            norm = float(np.linalg.norm(direction))
            if norm <= 1.0e-6:
                direction = np.array((0.35, -0.45, 0.82), dtype=float)
                norm = float(np.linalg.norm(direction))
            direction = tuple((direction / norm).tolist())
            color = tuple(float(c) for c in color_value)
            return direction, color, intensity
        return None

    def _prepare_imported_simulation(self, model: Any, state: Any, scene_kind: str, metadata: Any) -> None:
        self.imported_model = model
        self.imported_state_0 = state
        self.imported_state_1 = model.state()
        self.imported_control = model.control()
        self.imported_scene_kind = scene_kind
        self._body_component_cache = {}
        self._apply_import_timestep(metadata)
        self.imported_joint_controls = self._build_joint_drive_controls(model)
        fallback_drives = self._prepare_interactive_joint_drives(model, self.imported_joint_controls)
        disabled_loop_drives = self._disable_loop_joint_position_drives(model)
        normalized_collision_groups = self._normalize_imported_collision_groups(model)
        if scene_kind in {"mjcf", "usd"}:
            use_mujoco_cpu = self._should_use_native_mujoco_cpu()
            if use_mujoco_cpu:
                nconmax = max(1024, int(model.shape_count) * 2)
                njmax = max(4096, int(model.joint_count) * 32 + int(model.body_count) * 16)
            else:
                nconmax = max(128, min(1024, int(model.body_count) * 8, int(model.shape_count)))
                njmax = max(256, min(2048, int(model.joint_count) * 16 + int(model.body_count) * 8))
            if use_mujoco_cpu:
                self.imported_step_hz = max(float(self.imported_step_hz), 60.0)
            try:
                self.imported_solver = newton.solvers.SolverMuJoCo(
                    model,
                    nconmax=nconmax,
                    njmax=njmax,
                    use_mujoco_cpu=use_mujoco_cpu,
                    update_data_interval=0 if use_mujoco_cpu else 1,
                )
                self.imported_use_mujoco_cpu = use_mujoco_cpu
                backend = "native CPU" if use_mujoco_cpu else "Warp"
                self.imported_solver_name = f"MuJoCo {backend}"
                self.imported_use_mujoco_contacts = True
                self.imported_contacts = None if use_mujoco_cpu else newton.Contacts(self.imported_solver.get_max_contact_count(), 0)
                enabled_asset_contacts = self._enable_native_mujoco_asset_contacts(model)
            except Exception as exc:  # noqa: BLE001
                self._push_message(
                    "MuJoCo solver unavailable",
                    f"{type(exc).__name__}: {exc}. Falling back to XPBD for this imported scene.",
                    "warning",
                )
                self.imported_solver = newton.solvers.SolverXPBD(model, iterations=10, enable_restitution=True)
                self.imported_solver_name = "XPBD"
                self.imported_use_mujoco_cpu = False
                self.imported_use_mujoco_contacts = False
                self.imported_contacts = model.contacts()
                enabled_asset_contacts = 0
        else:
            self.imported_solver = newton.solvers.SolverXPBD(model, iterations=10, enable_restitution=True)
            self.imported_solver_name = "XPBD"
            self.imported_use_mujoco_cpu = False
            self.imported_use_mujoco_contacts = False
            self.imported_contacts = model.contacts()
            enabled_asset_contacts = 0
        self.imported_physics_summary = self._summarize_model_physics(model, self.imported_solver_name)
        self._sync_joint_targets_to_control()
        self._refresh_native_mujoco_data("initial import")
        self.imported_initial_snapshot = self._capture_imported_snapshot()
        if enabled_asset_contacts:
            self._push_message(
                "Asset contacts enabled",
                f"Enabled native MuJoCo collision masks for {enabled_asset_contacts} imported colliders so separate assets can collide.",
            )
        if normalized_collision_groups:
            self._push_message(
                "Collision groups normalized",
                f"Normalized {normalized_collision_groups} imported collider groups before MuJoCo compilation so independently authored assets can generate broadphase pairs.",
            )
        if fallback_drives:
            self._push_message(
                "Interactive drive fallback",
                f"Prepared fallback drive gains for {fallback_drives} controllable joints. Fallback drives stay disabled until you actively manipulate a joint.",
                "warning",
            )
        if disabled_loop_drives:
            self._push_message(
                "Loop joint drives disabled",
                f"Disabled {disabled_loop_drives} position drives on loop-closure joints to avoid solver fights and shaking. Joint limits and constraints remain active.",
                "warning",
            )
        self._push_message(
            "Solver backend",
            f"{self.imported_solver_name}; native CPU keeps MuJoCo's internal state continuous and only refreshes it after Gizmo edits.",
        )

    @staticmethod
    def _should_use_native_mujoco_cpu() -> bool:
        try:
            return bool(getattr(wp.get_device(), "is_cpu", False))
        except Exception:
            return True

    def _refresh_native_mujoco_data(self, reason: str) -> None:
        if not self.imported_use_mujoco_cpu or self.imported_solver is None or self.imported_state_0 is None:
            return
        update_data = getattr(self.imported_solver, "_update_mjc_data", None)
        mj_data = getattr(self.imported_solver, "mj_data", None)
        if update_data is None or mj_data is None:
            return
        update_data(mj_data, self.imported_model, self.imported_state_0)
        self._native_mujoco_last_refresh_reason = reason

    def _enable_native_mujoco_asset_contacts(self, model: Any) -> int:
        if not self.imported_use_mujoco_cpu or self.imported_solver is None:
            return 0
        mj_model = getattr(self.imported_solver, "mj_model", None)
        geom_to_shape = getattr(self.imported_solver, "mjc_geom_to_newton_shape", None)
        if mj_model is None or geom_to_shape is None:
            return 0
        shape_flags = model.shape_flags.numpy()
        shape_groups = model.shape_collision_group.numpy()
        mapping = geom_to_shape.numpy()
        if mapping.ndim == 2:
            mapping = mapping[0]
        enabled = 0
        for geom_index, shape_index_raw in enumerate(mapping[: mj_model.ngeom]):
            shape_index = int(shape_index_raw)
            collides = (
                0 <= shape_index < len(shape_flags)
                and bool(int(shape_flags[shape_index]) & int(newton.ShapeFlags.COLLIDE_SHAPES))
                and int(shape_groups[shape_index]) != 0
            )
            if collides:
                mj_model.geom_contype[geom_index] = 1
                mj_model.geom_conaffinity[geom_index] = 1
                enabled += 1
            else:
                mj_model.geom_contype[geom_index] = 0
                mj_model.geom_conaffinity[geom_index] = 0
        mj_data = getattr(self.imported_solver, "mj_data", None)
        if mj_data is not None:
            try:
                self.imported_solver._mujoco.mj_setConst(mj_model, mj_data)
            except Exception:
                pass
        return enabled

    @staticmethod
    def _normalize_imported_collision_groups(model: Any) -> int:
        if getattr(model, "shape_flags", None) is None or getattr(model, "shape_collision_group", None) is None:
            return 0
        flags = model.shape_flags.numpy()
        groups = model.shape_collision_group.numpy()
        collide_mask = (flags & int(newton.ShapeFlags.COLLIDE_SHAPES)) != 0
        active = collide_mask & (groups != 0)
        if not bool(active.any()):
            return 0
        changed = int((groups[active] != 1).sum())
        if changed:
            groups[active] = 1
            model.shape_collision_group.assign(groups)
        return changed

    @staticmethod
    def _format_range(label: str, value: tuple[float, float] | None) -> str:
        if value is None:
            return f"{label}=n/a"
        return f"{label}={value[0]:.4g}..{value[1]:.4g}"

    def _format_physics_summary(self, summary: PhysicsSummary) -> str:
        gravity = summary.gravity if summary.gravity is not None else (0.0, 0.0, 0.0)
        return (
            f"{summary.solver}; dynamic bodies={summary.dynamic_bodies}, static bodies={summary.static_bodies}, "
            f"collision shapes={summary.collision_shapes}, visual shapes={summary.visual_shapes}, "
            f"visual-only={summary.visual_only_shapes}, collision-only={summary.collision_only_shapes}, "
            f"gravity=({gravity[0]:.3g}, {gravity[1]:.3g}, {gravity[2]:.3g}), "
            f"{self._format_range('mass', summary.mass_range)}, "
            f"{self._format_range('friction', summary.friction_range)}, "
            f"{self._format_range('restitution', summary.restitution_range)}."
        )

    def _capture_imported_snapshot(self) -> ImportedStateSnapshot | None:
        if self.imported_model is None or self.imported_state_0 is None:
            return None
        control_targets = None
        if self.imported_control is not None and getattr(self.imported_control, "joint_target_pos", None) is not None:
            control_targets = self.imported_control.joint_target_pos.numpy().copy()
        return ImportedStateSnapshot(
            body_q=self.imported_state_0.body_q.numpy().copy()
            if getattr(self.imported_state_0, "body_q", None) is not None
            else None,
            body_qd=self.imported_state_0.body_qd.numpy().copy()
            if getattr(self.imported_state_0, "body_qd", None) is not None
            else None,
            joint_q=self.imported_model.joint_q.numpy().copy()
            if getattr(self.imported_model, "joint_q", None) is not None
            else None,
            joint_qd=self.imported_model.joint_qd.numpy().copy()
            if getattr(self.imported_model, "joint_qd", None) is not None
            else None,
            control_joint_target_pos=control_targets,
        )

    def _restore_imported_snapshot(self, snapshot: ImportedStateSnapshot | None) -> None:
        if snapshot is None or self.imported_model is None or self.imported_state_0 is None:
            return
        if snapshot.joint_q is not None and getattr(self.imported_model, "joint_q", None) is not None:
            self.imported_model.joint_q.assign(snapshot.joint_q)
        if snapshot.joint_qd is not None and getattr(self.imported_model, "joint_qd", None) is not None:
            self.imported_model.joint_qd.assign(snapshot.joint_qd)
        for state in (self.imported_state_0, self.imported_state_1):
            if state is None:
                continue
            if snapshot.body_q is not None and getattr(state, "body_q", None) is not None:
                state.body_q.assign(snapshot.body_q)
            if snapshot.body_qd is not None and getattr(state, "body_qd", None) is not None:
                state.body_qd.assign(snapshot.body_qd)
            if snapshot.joint_q is not None and getattr(state, "joint_q", None) is not None:
                state.joint_q.assign(snapshot.joint_q)
            if snapshot.joint_qd is not None and getattr(state, "joint_qd", None) is not None:
                state.joint_qd.assign(snapshot.joint_qd)
        if (
            snapshot.control_joint_target_pos is not None
            and self.imported_control is not None
            and getattr(self.imported_control, "joint_target_pos", None) is not None
        ):
            self.imported_control.joint_target_pos.assign(snapshot.control_joint_target_pos)
            for control in self.imported_joint_controls:
                if 0 <= control.dof_index < len(snapshot.control_joint_target_pos):
                    control.target = float(snapshot.control_joint_target_pos[control.dof_index])
        self.imported_simulation_enabled = False
        self.viewer._paused = True
        self.imported_render_dirty = True
        self.imported_pose_dirty = False
        self._push_message("Reset", "Imported scene state restored without rebuilding GL resources.")

    def _step_imported_scene(self, *, apply_viewer_forces: bool) -> None:
        if (
            self.imported_model is None
            or self.imported_state_0 is None
            or self.imported_state_1 is None
            or self.imported_control is None
            or self.imported_solver is None
        ):
            return
        if self.imported_pose_dirty:
            self._sync_all_free_joint_q_from_current_body_state()
            self._refresh_native_mujoco_data("pose edit")
            self.imported_pose_dirty = False
        self._sync_joint_targets_to_control()
        target_frame_dt = 1.0 / max(1.0, float(self.imported_step_hz))
        total_dt = min(max(float(self.imported_sim_dt), target_frame_dt), 1.0 / 30.0)
        dt = total_dt / max(1, self.imported_sim_substeps)
        for _ in range(max(1, self.imported_sim_substeps)):
            if self.imported_contacts is not None and not self.imported_use_mujoco_contacts:
                self.imported_model.collide(self.imported_state_0, self.imported_contacts)
            self.imported_state_0.clear_forces()
            if apply_viewer_forces:
                self.viewer.apply_forces(self.imported_state_0)
            self.imported_solver.step(
                self.imported_state_0,
                self.imported_state_1,
                self.imported_control,
                self.imported_contacts,
                dt,
            )
            self.imported_state_0, self.imported_state_1 = self.imported_state_1, self.imported_state_0
            self._record_native_mujoco_contacts()
        if (
            self.imported_use_mujoco_contacts
            and not self.imported_use_mujoco_cpu
            and self.imported_contacts is not None
            and self.viewer.show_contacts
        ):
            self.imported_solver.update_contacts(self.imported_contacts, self.imported_state_0)

    def _record_native_mujoco_contacts(self) -> None:
        if not self.imported_use_mujoco_cpu or self.imported_solver is None:
            return
        mj_data = getattr(self.imported_solver, "mj_data", None)
        if mj_data is None:
            return
        count = int(getattr(mj_data, "ncon", 0))
        self._native_contact_peak = max(self._native_contact_peak, count)
        now = time.perf_counter()
        if count > 0 and now - self._last_native_contact_log_time > 2.0:
            self._last_native_contact_log_time = now
            self._push_message(
                "Native contacts",
                f"MuJoCo currently reports {count} contacts; peak this run={self._native_contact_peak}.",
            )

    def _should_step_imported_scene(self) -> bool:
        hz = max(1.0, float(self.imported_step_hz))
        now = time.perf_counter()
        if self._last_imported_step_time <= 0.0 or now - self._last_imported_step_time >= 1.0 / hz:
            self._last_imported_step_time = now
            return True
        return False

    def _connected_body_component(self, body_index: int) -> list[int]:
        if body_index in self._body_component_cache:
            return self._body_component_cache[body_index]
        if self.imported_model is None or getattr(self.imported_model, "joint_child", None) is None:
            return [body_index]

        joint_child = self.imported_model.joint_child.numpy()
        joint_parent = self.imported_model.joint_parent.numpy()
        neighbors: dict[int, set[int]] = {}
        for parent, child in zip(joint_parent, joint_child, strict=True):
            parent_i = int(parent)
            child_i = int(child)
            if child_i < 0:
                continue
            neighbors.setdefault(child_i, set())
            if parent_i >= 0:
                neighbors.setdefault(parent_i, set()).add(child_i)
                neighbors[child_i].add(parent_i)

        stack = [body_index]
        seen: set[int] = set()
        while stack:
            body = stack.pop()
            if body in seen:
                continue
            seen.add(body)
            stack.extend(neighbors.get(body, ()))
        component = sorted(seen) if seen else [body_index]
        for body in component:
            self._body_component_cache[body] = component
        return component

    def _apply_import_timestep(self, metadata: Any) -> None:
        if not isinstance(metadata, dict):
            return
        physics_dt = metadata.get("physics_dt") or metadata.get("dt") or metadata.get("timestep")
        if isinstance(physics_dt, (int, float)) and physics_dt > 0.0:
            self.imported_sim_dt = float(physics_dt)
            return
        fps = metadata.get("fps")
        if isinstance(fps, (int, float)) and fps > 0.0:
            self.imported_sim_dt = 1.0 / float(fps)

    @staticmethod
    def _prepare_interactive_joint_drives(model: Any, controls: list[JointDriveControl]) -> int:
        if not controls or getattr(model, "joint_target_ke", None) is None or getattr(model, "joint_target_kd", None) is None:
            return 0
        ke = model.joint_target_ke.numpy()
        kd = model.joint_target_kd.numpy()
        changed = 0
        for control in controls:
            if abs(float(ke[control.dof_index])) < 1.0e-6 and abs(float(kd[control.dof_index])) < 1.0e-6:
                ke[control.dof_index] = 120.0
                kd[control.dof_index] = 18.0
                changed += 1
        if changed:
            model.joint_target_ke.assign(ke)
            model.joint_target_kd.assign(kd)
        return changed

    def _enable_joint_drive_for_interaction(self, control: JointDriveControl) -> None:
        model = self.imported_model
        if (
            model is None
            or getattr(model, "joint_target_mode", None) is None
            or getattr(model, "joint_target_ke", None) is None
            or getattr(model, "joint_target_kd", None) is None
        ):
            return
        modes = model.joint_target_mode.numpy()
        ke = model.joint_target_ke.numpy()
        kd = model.joint_target_kd.numpy()
        dof = int(control.dof_index)
        if dof < 0 or dof >= len(modes):
            return
        changed = False
        if int(modes[dof]) == int(newton.JointTargetMode.NONE):
            modes[dof] = int(newton.JointTargetMode.POSITION)
            changed = True
        if abs(float(ke[dof])) < 1.0e-6 and abs(float(kd[dof])) < 1.0e-6:
            ke[dof] = 120.0
            kd[dof] = 18.0
            changed = True
        if changed:
            model.joint_target_mode.assign(modes)
            model.joint_target_ke.assign(ke)
            model.joint_target_kd.assign(kd)
            self._refresh_native_mujoco_data(f"enable drive {control.label}")

    @staticmethod
    def _disable_loop_joint_position_drives(model: Any) -> int:
        if (
            getattr(model, "joint_articulation", None) is None
            or getattr(model, "joint_target_mode", None) is None
            or getattr(model, "joint_target_ke", None) is None
            or getattr(model, "joint_target_kd", None) is None
        ):
            return 0
        articulations = model.joint_articulation.numpy()
        qd_starts = model.joint_qd_start.numpy()
        modes = model.joint_target_mode.numpy()
        ke = model.joint_target_ke.numpy()
        kd = model.joint_target_kd.numpy()
        disabled = 0
        for joint_index, articulation in enumerate(articulations):
            if int(articulation) >= 0:
                continue
            start = int(qd_starts[joint_index])
            end = int(qd_starts[joint_index + 1])
            for dof_index in range(start, end):
                if 0 <= dof_index < len(modes) and int(modes[dof_index]) != int(newton.JointTargetMode.NONE):
                    modes[dof_index] = int(newton.JointTargetMode.NONE)
                    ke[dof_index] = 0.0
                    kd[dof_index] = 0.0
                    disabled += 1
        if disabled:
            model.joint_target_mode.assign(modes)
            model.joint_target_ke.assign(ke)
            model.joint_target_kd.assign(kd)
        return disabled

    @staticmethod
    def _body_label(model: Any, body_index: int) -> str:
        for attr in ("body_label", "body_key", "body_name"):
            labels = getattr(model, attr, None)
            if labels is not None and 0 <= body_index < len(labels):
                return str(labels[body_index]).rsplit("/", 1)[-1]
        return f"body_{body_index}"

    @staticmethod
    def _summarize_model_physics(model: Any, solver_name: str) -> PhysicsSummary:
        flags = model.shape_flags.numpy()
        body_inv_mass = model.body_inv_mass.numpy() if getattr(model, "body_inv_mass", None) is not None else []
        body_mass = model.body_mass.numpy() if getattr(model, "body_mass", None) is not None else []
        friction = model.shape_material_mu.numpy() if getattr(model, "shape_material_mu", None) is not None else []
        restitution = (
            model.shape_material_restitution.numpy()
            if getattr(model, "shape_material_restitution", None) is not None
            else []
        )
        visual = [bool(flag & int(newton.ShapeFlags.VISIBLE)) for flag in flags]
        collide = [bool(flag & int(newton.ShapeFlags.COLLIDE_SHAPES)) for flag in flags]
        gravity = None
        if getattr(model, "gravity", None) is not None and model.world_count:
            g = model.gravity.numpy()[0]
            gravity = (float(g[0]), float(g[1]), float(g[2]))
        disabled_joints = 0
        if getattr(model, "joint_enabled", None) is not None:
            disabled_joints = sum(1 for enabled in model.joint_enabled.numpy() if not bool(enabled))
        return PhysicsSummary(
            solver=solver_name,
            dynamic_bodies=sum(1 for inv_mass in body_inv_mass if float(inv_mass) > 0.0),
            static_bodies=sum(1 for inv_mass in body_inv_mass if float(inv_mass) == 0.0),
            visual_shapes=sum(visual),
            collision_shapes=sum(collide),
            visual_only_shapes=sum(1 for v, c in zip(visual, collide, strict=True) if v and not c),
            collision_only_shapes=sum(1 for v, c in zip(visual, collide, strict=True) if c and not v),
            visual_collision_shapes=sum(1 for v, c in zip(visual, collide, strict=True) if v and c),
            disabled_joints=disabled_joints,
            gravity=gravity,
            mass_range=GizmoGLApp._positive_range(body_mass),
            friction_range=GizmoGLApp._value_range(friction),
            restitution_range=GizmoGLApp._value_range(restitution),
        )

    @staticmethod
    def _positive_range(values: Any) -> tuple[float, float] | None:
        filtered = [float(value) for value in values if float(value) > 0.0]
        if not filtered:
            return None
        return min(filtered), max(filtered)

    @staticmethod
    def _value_range(values: Any) -> tuple[float, float] | None:
        filtered = [float(value) for value in values]
        if not filtered:
            return None
        return min(filtered), max(filtered)

    def _sync_joint_targets_to_control(self) -> None:
        if self.imported_control is None or not self.imported_joint_controls:
            return
        targets = self.imported_control.joint_target_pos.numpy()
        for control in self.imported_joint_controls:
            if 0 <= control.dof_index < len(targets):
                targets[control.dof_index] = control.target
        self.imported_control.joint_target_pos.assign(targets)

    def _set_joint_control_target(self, control: JointDriveControl, value: float) -> None:
        value = max(control.lower, min(control.upper, float(value)))
        control.target = value
        self._enable_joint_drive_for_interaction(control)
        self._sync_joint_targets_to_control()
        if self.imported_simulation_enabled:
            self.imported_render_dirty = True
            self._push_message(
                "Joint target",
                f"{control.label} target={value:.4g}. Updated actuator target only; scene pose is left under MuJoCo ownership during Run.",
            )
            return
        if self.imported_model is not None and getattr(self.imported_model, "joint_q", None) is not None:
            joint_q = self.imported_model.joint_q.numpy()
            if 0 <= control.coord_index < len(joint_q):
                joint_q[control.coord_index] = value
                self.imported_model.joint_q.assign(joint_q)
                self._copy_model_joint_coordinates_to_states()
        if self.imported_state_0 is not None and self.imported_model is not None:
            if getattr(self.imported_model, "joint_qd", None) is not None:
                self.imported_model.joint_qd.fill_(0.0)
                self._copy_model_joint_coordinates_to_states()
            newton.eval_fk(self.imported_model, self.imported_model.joint_q, self.imported_model.joint_qd, self.imported_state_0)
            if self.imported_state_1 is not None:
                newton.eval_fk(
                    self.imported_model,
                    self.imported_model.joint_q,
                    self.imported_model.joint_qd,
                    self.imported_state_1,
                )
        self.imported_render_dirty = True
        self.imported_pose_dirty = True

    def _select_body(self, body_index: int | None) -> None:
        self.selected_body_index = body_index
        self.selected_joint_control = None
        self._drag_body_index = None
        self._drag_last_time = None
        self._apply_selection_highlight(body_index)
        if body_index is None or self.imported_model is None:
            return
        child_joints = self.imported_model.joint_child.numpy()
        selected = [control for control in self.imported_joint_controls if int(child_joints[control.joint_index]) == body_index]
        if not selected:
            label = self._body_label(self.imported_model, body_index)
            self._push_message("Selected body", self._selected_body_detail(body_index, label))
            return
        self.selected_joint_control = selected[0]
        self._push_message(
            "Selected joint",
            f"{self.selected_joint_control.label}. Right-drag, use [ and ] / arrow keys, or adjust the Inspector slider to articulate.",
        )

    def _selected_body_detail(self, body_index: int, label: str) -> str:
        if self.imported_model is None:
            return f"{label}. Right-drag to lift or move it with viewport picking."
        dynamic = "unknown"
        if getattr(self.imported_model, "body_inv_mass", None) is not None:
            inv_mass = float(self.imported_model.body_inv_mass.numpy()[body_index])
            dynamic = "dynamic" if inv_mass > 0.0 else "static/kinematic"
        component = self._connected_body_component(body_index)
        root_joint = "none"
        if getattr(self.imported_model, "joint_child", None) is not None:
            joint_child = self.imported_model.joint_child.numpy()
            joint_parent = self.imported_model.joint_parent.numpy()
            joint_type = self.imported_model.joint_type.numpy()
            for joint_index, child in enumerate(joint_child):
                if int(child) == body_index:
                    parent = int(joint_parent[joint_index])
                    kind = newton.JointType(int(joint_type[joint_index])).name
                    root_joint = f"{kind} from {'world' if parent < 0 else self._body_label(self.imported_model, parent)}"
                    break
        return (
            f"{label} ({dynamic}, component bodies={len(component)}, joint={root_joint}). "
            "Right-drag to move it; Shift+right-drag lifts vertically. During Run, Gizmo refreshes native MuJoCo state after this edit."
        )

    def _apply_selection_highlight(self, body_index: int | None) -> None:
        model = self.imported_model
        if model is None or getattr(model, "shape_color", None) is None:
            return
        colors = self._base_shape_colors.copy() if self._base_shape_colors is not None else model.shape_color.numpy()
        self._highlight_shape_indices = []
        if body_index is not None and getattr(model, "shape_body", None) is not None:
            for index, shape_body in enumerate(model.shape_body.numpy()):
                if int(shape_body) == body_index:
                    colors[index] = self._selection_blue
                    self._highlight_shape_indices.append(index)
        model.shape_color.assign(colors)
        self.imported_render_dirty = True

    def _pick_body_at(self, x: float, y: float) -> int | None:
        if self.viewer.picking is None or self.imported_state_0 is None:
            return None
        fb_x, fb_y = self.viewer._to_framebuffer_coords(x, y)
        ray_start, ray_dir = self.viewer.camera.get_world_ray(fb_x, fb_y)
        self.viewer.picking.pick(self.imported_state_0, ray_start, ray_dir)
        body_index = int(self.viewer.picking.pick_body.numpy()[0])
        self.viewer.picking.release()
        return body_index if body_index >= 0 else None

    def handle_mouse_press(self, x: float, y: float, button: int, modifiers: int) -> bool:
        if self.current_example is not None or self.imported_state_0 is None:
            return False
        try:
            import pyglet
        except Exception:
            return False
        if button != pyglet.window.mouse.RIGHT:
            return False
        body_index = self._pick_body_at(x, y)
        self._select_body(body_index)
        return body_index is not None

    def handle_key_press(self, symbol: int, modifiers: int) -> bool:
        if self.eval_mode:
            return False  # joint articulation is owned by the eval harness
        if self.selected_joint_control is None:
            return False
        try:
            import pyglet
        except Exception:
            return False
        step = 0.04 if self.selected_joint_control.kind == "PRISMATIC" else 0.08
        if modifiers & pyglet.window.key.MOD_SHIFT:
            step *= 4.0
        if symbol in {pyglet.window.key.BRACKETLEFT, pyglet.window.key.LEFT}:
            self._set_joint_control_target(self.selected_joint_control, self.selected_joint_control.target - step)
            return True
        if symbol in {pyglet.window.key.BRACKETRIGHT, pyglet.window.key.RIGHT}:
            self._set_joint_control_target(self.selected_joint_control, self.selected_joint_control.target + step)
            return True
        return False

    def handle_mouse_drag(self, x: float, y: float, dx: float, dy: float, buttons: int, modifiers: int) -> bool:
        if self.eval_mode:
            return False  # let the camera orbit, but never move bodies/joints
        if self.selected_joint_control is None and self.selected_body_index is None:
            return False
        try:
            import pyglet
        except Exception:
            return False
        if not (buttons & pyglet.window.mouse.RIGHT):
            return False
        if self.selected_joint_control is None or (modifiers & pyglet.window.key.MOD_SHIFT):
            return self._move_selected_body(dx, dy, modifiers)
        scale = 0.003 if self.selected_joint_control.kind == "PRISMATIC" else 0.006
        self._set_joint_control_target(
            self.selected_joint_control,
            self.selected_joint_control.target + float(dx - dy) * scale,
        )
        return True

    def handle_mouse_release(self, x: float, y: float, button: int, modifiers: int) -> bool:
        del x, y, modifiers
        try:
            import pyglet
        except Exception:
            return False
        if button != pyglet.window.mouse.RIGHT:
            return False
        self._drag_body_index = None
        self._drag_last_time = None
        return False

    def _move_selected_body(self, dx: float, dy: float, modifiers: int) -> bool:
        if self.imported_state_0 is None or self.selected_body_index is None:
            return False
        try:
            import numpy as np
            import pyglet
        except Exception:
            return False
        body_q = self.imported_state_0.body_q.numpy()
        body_index = int(self.selected_body_index)
        if body_index < 0 or body_index >= len(body_q):
            return False
        pan_scale = self.viewer._camera_pan_scale() if hasattr(self.viewer, "_camera_pan_scale") else 0.01
        move_scale = float(pan_scale) * 1.35
        right = np.array(self.viewer.camera.get_right(), dtype=float)
        up = np.array(self.viewer.camera.get_up(), dtype=float)
        world_up = np.zeros(3, dtype=float)
        world_up[int(getattr(self.viewer.camera, "up_axis", 2))] = 1.0
        if modifiers & pyglet.window.key.MOD_SHIFT:
            delta = world_up * float(dy) * move_scale
        else:
            delta = right * float(dx) * move_scale + up * float(dy) * move_scale
        now = time.perf_counter()
        elapsed = 0.0
        if self._drag_body_index == body_index and self._drag_last_time is not None:
            elapsed = max(1.0 / 240.0, min(now - self._drag_last_time, 0.1))
        self._drag_body_index = body_index
        self._drag_last_time = now
        linear_velocity = delta / elapsed if elapsed > 0.0 else np.zeros(3, dtype=float)
        speed = float(np.linalg.norm(linear_velocity))
        if speed > 25.0:
            linear_velocity *= 25.0 / speed
        component = self._connected_body_component(body_index)
        for body in component:
            if 0 <= body < len(body_q):
                body_q[body, 0:3] += delta
        self.imported_state_0.body_q.assign(body_q)
        if getattr(self.imported_state_0, "body_qd", None) is not None:
            body_qd = self.imported_state_0.body_qd.numpy()
            for body in component:
                if 0 <= body < len(body_qd):
                    body_qd[body, 0:3] = linear_velocity
                    body_qd[body, 3:6] = 0.0
            self.imported_state_0.body_qd.assign(body_qd)
        self._sync_free_joint_q_from_body_q(component, body_q, preserve_velocity=self.imported_simulation_enabled)
        if self.imported_state_1 is not None and getattr(self.imported_state_1, "body_q", None) is not None:
            state_1_q = self.imported_state_1.body_q.numpy()
            for body in component:
                if 0 <= body < len(state_1_q):
                    state_1_q[body] = body_q[body]
            self.imported_state_1.body_q.assign(state_1_q)
            if getattr(self.imported_state_1, "body_qd", None) is not None and getattr(self.imported_state_0, "body_qd", None) is not None:
                self.imported_state_1.body_qd.assign(self.imported_state_0.body_qd)
        self.imported_render_dirty = True
        self.imported_pose_dirty = True
        if self.imported_simulation_enabled:
            self._refresh_native_mujoco_data(f"drag body {self._body_label(self.imported_model, body_index) if self.imported_model is not None else body_index}")
            self.imported_pose_dirty = False
        return True

    def _sync_free_joint_q_from_body_q(self, body_indices: list[int], body_q: Any, *, preserve_velocity: bool = False) -> None:
        model = self.imported_model
        if model is None or getattr(model, "joint_type", None) is None or getattr(model, "joint_q", None) is None:
            return
        try:
            import numpy as np
        except Exception:
            return
        joint_types = model.joint_type.numpy()
        joint_children = model.joint_child.numpy()
        q_starts = model.joint_q_start.numpy()
        joint_q = model.joint_q.numpy()
        free_type = int(newton.JointType.FREE)
        moved = set(int(body) for body in body_indices)
        changed = False
        for joint_index, joint_type in enumerate(joint_types):
            if int(joint_type) != free_type:
                continue
            child = int(joint_children[joint_index])
            if child not in moved or child < 0 or child >= len(body_q):
                continue
            start = int(q_starts[joint_index])
            if start < 0 or start + 7 > len(joint_q):
                continue
            pose = np.asarray(body_q[child])
            joint_q[start : start + 3] = pose[0:3]
            joint_q[start + 3 : start + 7] = pose[3:7]
            changed = True
        if changed:
            model.joint_q.assign(joint_q)
            if preserve_velocity and self.imported_state_0 is not None and getattr(model, "joint_qd", None) is not None:
                try:
                    newton.eval_ik(model, self.imported_state_0, model.joint_q, model.joint_qd)
                except Exception:
                    pass
            elif getattr(model, "joint_qd", None) is not None:
                model.joint_qd.fill_(0.0)
            self._copy_model_joint_coordinates_to_states()

    def _handle_joint_keyboard_input(self) -> None:
        if self.eval_mode:
            return
        if self.selected_joint_control is None or self.viewer.ui is None:
            return
        try:
            import pyglet
        except Exception:
            return
        if self.viewer._ui_is_capturing_keyboard():
            return
        direction = 0.0
        if self.viewer.renderer.is_key_down(pyglet.window.key.BRACKETLEFT):
            direction -= 1.0
        if self.viewer.renderer.is_key_down(pyglet.window.key.BRACKETRIGHT):
            direction += 1.0
        if direction == 0.0:
            return
        step = 0.01 if self.selected_joint_control.kind == "PRISMATIC" else 0.02
        self._set_joint_control_target(
            self.selected_joint_control,
            self.selected_joint_control.target + direction * step,
        )

    @staticmethod
    def _build_joint_drive_controls(model: Any) -> list[JointDriveControl]:
        joint_types = model.joint_type.numpy()
        q_starts = model.joint_q_start.numpy()
        qd_starts = model.joint_qd_start.numpy()
        joint_q = model.joint_q.numpy()
        lower = model.joint_limit_lower.numpy()
        upper = model.joint_limit_upper.numpy()
        articulations = model.joint_articulation.numpy() if getattr(model, "joint_articulation", None) is not None else None
        labels = getattr(model, "joint_label", None) or []
        controls: list[JointDriveControl] = []
        for joint_index, joint_type in enumerate(joint_types):
            kind = newton.JointType(int(joint_type)).name
            if int(joint_type) not in {int(newton.JointType.PRISMATIC), int(newton.JointType.REVOLUTE)}:
                continue
            if articulations is not None and int(articulations[joint_index]) < 0:
                continue
            coord_index = int(q_starts[joint_index])
            next_coord_index = int(q_starts[joint_index + 1])
            dof_index = int(qd_starts[joint_index])
            next_dof_index = int(qd_starts[joint_index + 1])
            if next_coord_index - coord_index != 1 or next_dof_index - dof_index != 1:
                continue
            lo = float(lower[dof_index])
            hi = float(upper[dof_index])
            if lo < -1.0e8 or hi > 1.0e8 or lo >= hi:
                center = float(joint_q[coord_index])
                span = 1.0 if int(joint_type) == int(newton.JointType.PRISMATIC) else 1.57079632679
                lo, hi = center - span, center + span
            label = str(labels[joint_index]) if joint_index < len(labels) else f"joint_{joint_index}"
            controls.append(
                JointDriveControl(
                    joint_index=joint_index,
                    dof_index=dof_index,
                    coord_index=coord_index,
                    label=label.rsplit("/", 1)[-1],
                    kind=kind,
                    target=float(joint_q[coord_index]),
                    lower=lo,
                    upper=hi,
                )
            )
        return controls

    @staticmethod
    def _count_textured_shapes(model: Any) -> int:
        return sum(1 for source in getattr(model, "shape_source", []) if getattr(source, "texture", None) is not None)

    def _summarize_source_scene(self, path: Path, scene_kind: str) -> SceneSourceSummary:
        if scene_kind == "mjcf":
            return self._summarize_mjcf_source(path)
        if scene_kind == "usd":
            return self._summarize_usd_source(path)
        return SceneSourceSummary(kind=scene_kind)

    @staticmethod
    def _summarize_mjcf_source(path: Path) -> SceneSourceSummary:
        root = ET.parse(path).getroot()
        texture_files = [texture.get("file") for texture in root.findall(".//texture") if texture.get("file")]
        missing = sum(1 for file_name in texture_files if not (path.parent / file_name).exists())
        meshes = root.findall(".//mesh")
        return SceneSourceSummary(
            kind="mjcf",
            textures=len(texture_files),
            missing_textures=missing,
            lights=len(root.findall(".//light")),
            bodies=len(root.findall(".//body")),
            joints=len(root.findall(".//joint")) + len(root.findall(".//freejoint")),
            meshes=len(meshes),
            inline_meshes=sum(1 for mesh in meshes if "vertex" in mesh.attrib and "face" in mesh.attrib),
            materials=len(root.findall(".//material")),
        )

    @staticmethod
    def _summarize_usd_source(path: Path) -> SceneSourceSummary:
        text = path.read_text(errors="ignore")
        texture_paths = []
        for line in text.splitlines():
            if "inputs:file" not in line or "@" not in line:
                continue
            parts = line.split("@")
            if len(parts) >= 3:
                texture_paths.append(parts[1])
        missing = sum(1 for file_name in texture_paths if not (path.parent / file_name).exists())
        return SceneSourceSummary(
            kind="usd",
            textures=len(texture_paths),
            missing_textures=missing,
            lights=text.count("DistantLight") + text.count("SphereLight") + text.count("DomeLight"),
            bodies=text.count("PhysicsRigidBodyAPI"),
            joints=text.count("PhysicsRevoluteJoint")
            + text.count("PhysicsPrismaticJoint")
            + text.count("PhysicsFixedJoint"),
            meshes=text.count("def Mesh"),
            materials=text.count("UsdPreviewSurface") + text.count("OmniPBR"),
            articulations=text.count("PhysicsArticulationRootAPI"),
        )

    def _materialize_inline_mjcf_meshes(self, scene_path: Path) -> tuple[Path, int]:
        tree = ET.parse(scene_path)
        root = tree.getroot()
        inline_meshes = [
            mesh for mesh in root.findall(".//mesh") if "vertex" in mesh.attrib and "face" in mesh.attrib and "file" not in mesh.attrib
        ]
        if not inline_meshes:
            return scene_path, 0

        stat = scene_path.stat()
        cache_key = hashlib.sha256(f"{scene_path}:{stat.st_mtime_ns}:{stat.st_size}".encode("utf-8")).hexdigest()[:16]
        cache_root = PROJECT_ROOT / ".cache" / "gizmo_mjcf" / cache_key
        mesh_root = cache_root / "meshes"
        mesh_root.mkdir(parents=True, exist_ok=True)

        for index, mesh in enumerate(inline_meshes):
            raw_name = mesh.get("name") or f"mesh_{index}"
            safe_name = self._safe_asset_name(raw_name)
            obj_name = f"{index:04d}_{safe_name}.obj"
            self._write_inline_mjcf_mesh_obj(mesh_root / obj_name, mesh.attrib)
            for attr in ("vertex", "face", "texcoord", "normal"):
                mesh.attrib.pop(attr, None)
            mesh.set("file", f"meshes/{obj_name}")

        for texture in root.findall(".//texture"):
            texture_file = texture.get("file")
            if texture_file and not Path(texture_file).is_absolute():
                texture.set("file", str((scene_path.parent / texture_file).resolve()))

        materialized_path = cache_root / f"{scene_path.stem}.materialized.xml"
        tree.write(materialized_path, encoding="utf-8", xml_declaration=True)
        return materialized_path, len(inline_meshes)

    @staticmethod
    def _safe_asset_name(name: str) -> str:
        safe = "".join(ch if ch.isalnum() or ch in {"_", "-"} else "_" for ch in name)
        return safe[:80] or "mesh"

    @staticmethod
    def _write_inline_mjcf_mesh_obj(path: Path, attrib: dict[str, str]) -> None:
        vertices = GizmoGLApp._parse_float_groups(attrib.get("vertex", ""), 3)
        faces = GizmoGLApp._parse_int_groups(attrib.get("face", ""), 3)
        uvs = GizmoGLApp._parse_float_groups(attrib.get("texcoord", ""), 2)
        has_vertex_uvs = len(uvs) == len(vertices)

        with path.open("w", encoding="ascii") as file:
            file.write("# Generated by Gizmo from inline MJCF mesh data.\n")
            for x, y, z in vertices:
                file.write(f"v {x:.9g} {y:.9g} {z:.9g}\n")
            if has_vertex_uvs:
                for u, v in uvs:
                    file.write(f"vt {u:.9g} {v:.9g}\n")
            for a, b, c in faces:
                if has_vertex_uvs:
                    file.write(f"f {a + 1}/{a + 1} {b + 1}/{b + 1} {c + 1}/{c + 1}\n")
                else:
                    file.write(f"f {a + 1} {b + 1} {c + 1}\n")

    @staticmethod
    def _parse_float_groups(raw: str, group_size: int) -> list[tuple[float, ...]]:
        values = [float(value) for value in raw.split()]
        if len(values) % group_size:
            raise ValueError(f"Inline mesh float data is not divisible into groups of {group_size}.")
        return [tuple(values[i : i + group_size]) for i in range(0, len(values), group_size)]

    @staticmethod
    def _parse_int_groups(raw: str, group_size: int) -> list[tuple[int, ...]]:
        values = [int(value) for value in raw.split()]
        if len(values) % group_size:
            raise ValueError(f"Inline mesh index data is not divisible into groups of {group_size}.")
        return [tuple(values[i : i + group_size]) for i in range(0, len(values), group_size)]

    @staticmethod
    def _detect_scene_kind(path: Path) -> str:
        suffix = path.suffix.lower()
        if suffix in {".usd", ".usda", ".usdc"}:
            return "usd"
        if suffix in {".mjcf", ".njcf"}:
            return "mjcf"
        if suffix == ".urdf":
            return "urdf"
        if suffix == ".unisim":
            raise ValueError(
                "UniSim is Gizmo's authoring/interchange JSON, not the preferred physics runtime format. "
                "Export this scene as USD or MJCF/XML before importing into the simulator."
            )
        if suffix != ".xml":
            raise ValueError(f"Unsupported scene extension: {path.suffix}")

        try:
            root_name = ET.parse(path).getroot().tag.split("}")[-1].lower()
        except ET.ParseError as exc:
            raise ValueError(f"XML parse failed: {exc}") from exc

        if root_name == "mujoco":
            return "mjcf"
        if root_name == "robot":
            return "urdf"
        raise ValueError(
            f"Unsupported XML root <{root_name}>. Expected MJCF <mujoco> or URDF <robot>."
        )

    def open_import_dialog(self) -> None:
        if self.viewer.ui is None or not self.viewer.ui.is_available:
            self._push_message("Import unavailable", "The native file dialog is not available.", "error")
            return
        self.viewer.ui.open_load_file_dialog("Import USD / MJCF Scene")
        self.pending_file_dialog = True

    def _consume_file_dialog(self) -> None:
        if not self.pending_file_dialog or self.viewer.ui is None:
            return
        result = self.viewer.ui.consume_file_dialog_result()
        if result:
            self.pending_file_dialog = False
            self._pending_import_path = Path(result)

    def reset_example(self) -> None:
        if self.current_example is None and self.current_scene_path is not None:
            self._restore_imported_snapshot(self.imported_initial_snapshot)
        elif self.current_example_name is not None:
            self._pending_load = self.current_example_name

    def run_selected(self) -> None:
        if self.current_example is None and self.imported_state_0 is not None:
            self._sync_all_free_joint_q_from_current_body_state()
            self._refresh_native_mujoco_data("run start")
            self.imported_pose_dirty = False
            self._last_imported_step_time = 0.0
            self.viewer._paused = False
            self.imported_simulation_enabled = True
            self._push_message(
                "Running simulation",
                f"Running imported scene with {self.imported_solver_name} at {self.imported_step_hz:.0f} Hz; authored gravity, body masses, contacts, friction, restitution, joints, and solver properties are used from the imported Newton model. MuJoCo data refresh: {self._native_mujoco_last_refresh_reason or 'continuous'}.",
            )
            return
        self.load_example(self.selected_example_name)

    def _sync_all_free_joint_q_from_current_body_state(self) -> None:
        if self.imported_state_0 is None or getattr(self.imported_state_0, "body_q", None) is None:
            return
        body_q = self.imported_state_0.body_q.numpy()
        body_count = len(body_q)
        self._sync_free_joint_q_from_body_q(list(range(body_count)), body_q)
        if self.imported_model is not None and getattr(self.imported_model, "joint_q", None) is not None:
            try:
                newton.eval_ik(self.imported_model, self.imported_state_0, self.imported_model.joint_q, self.imported_model.joint_qd)
                self._copy_model_joint_coordinates_to_states()
            except Exception as exc:  # noqa: BLE001
                self._push_message("Pose sync warning", f"{type(exc).__name__}: {exc}", "warning")
        if self.imported_state_1 is not None and getattr(self.imported_state_1, "body_q", None) is not None:
            self.imported_state_1.body_q.assign(body_q)
        if (
            self.imported_state_1 is not None
            and getattr(self.imported_state_0, "body_qd", None) is not None
            and getattr(self.imported_state_1, "body_qd", None) is not None
        ):
            self.imported_state_1.body_qd.assign(self.imported_state_0.body_qd.numpy())

    def _copy_model_joint_coordinates_to_states(self) -> None:
        if self.imported_model is None:
            return
        joint_q = self.imported_model.joint_q.numpy() if getattr(self.imported_model, "joint_q", None) is not None else None
        joint_qd = self.imported_model.joint_qd.numpy() if getattr(self.imported_model, "joint_qd", None) is not None else None
        for state in (self.imported_state_0, self.imported_state_1):
            if state is None:
                continue
            if joint_q is not None and getattr(state, "joint_q", None) is not None:
                state.joint_q.assign(joint_q)
            if joint_qd is not None and getattr(state, "joint_qd", None) is not None:
                state.joint_qd.assign(joint_qd)

    def _render_top_bar(self, imgui, display_w: float) -> None:
        flags = self._window_flags(imgui, movable=False)
        imgui.set_next_window_pos(imgui.ImVec2(0, 0))
        imgui.set_next_window_size(imgui.ImVec2(display_w, self._top_height))
        if imgui.begin("##gizmo_top_bar", flags=flags):
            imgui.text("Gizmo")
            imgui.same_line()
            imgui.text_disabled("  Simulation Platform")
            imgui.same_line()
            imgui.dummy(imgui.ImVec2(24, 1))
            imgui.same_line()

            if not self.eval_mode and imgui.button("Hide Library" if self._library_visible else "Show Library"):
                self._library_visible = not self._library_visible
            if not self.eval_mode:
                imgui.same_line()
            if imgui.button("Hide Inspector" if self._inspector_visible else "Show Inspector"):
                self._inspector_visible = not self._inspector_visible
            imgui.same_line()

            if not self.eval_mode:
                # Scene loading and simulation control belong to the external
                # harness in eval mode, so these buttons are hidden there.
                if imgui.button("Import Scene"):
                    self.open_import_dialog()
                imgui.same_line()
                if imgui.button("Run"):
                    self.run_selected()
                imgui.same_line()
                if imgui.button("Pause" if not self.viewer._paused else "Resume"):
                    if self.current_example is None and self.imported_state_0 is not None:
                        if self.viewer._paused:
                            self.run_selected()
                        else:
                            self.viewer._paused = True
                            self.imported_simulation_enabled = False
                    else:
                        self.viewer._paused = not self.viewer._paused
                imgui.same_line()
                imgui.begin_disabled(not self.viewer._paused)
                if imgui.button("Step"):
                    self.viewer._step_requested = True
                imgui.end_disabled()
                imgui.same_line()
                if imgui.button("Reset"):
                    self.reset_example()
                imgui.same_line()
            if imgui.button("Frame"):
                self.viewer._frame_camera_on_model()

            imgui.same_line()
            if self.eval_mode:
                imgui.text_disabled(f"  ● HUD eval — {self.eval_scene or 'no scene'}")
            else:
                imgui.text_disabled(f"  Current: {self.current_example_name or 'None'}")
        imgui.end()

    def _render_library(self, imgui, display_h: float) -> None:
        flags = self._window_flags(imgui, movable=False)
        imgui.set_next_window_pos(imgui.ImVec2(0, self._top_height))
        imgui.set_next_window_size(imgui.ImVec2(self._left_width, display_h - self._top_height - self._bottom_height))
        if imgui.begin("Library", flags=flags):
            if imgui.button("Collapse"):
                self._library_visible = False
                imgui.end()
                return
            imgui.separator()
            imgui.text_disabled("Examples")
            if imgui.button("Import USD / MJCF"):
                self.open_import_dialog()
            imgui.separator()
            imgui.separator()

            for category in self.categories:
                selected = category == self.selected_category
                clicked, _ = imgui.selectable(category, selected)
                if clicked:
                    self.selected_category = category
                    names = self.categories[category]
                    self.selected_example_name = names[0] if names else None

            imgui.separator()
            imgui.text_disabled(self.selected_category)
            for name in self.categories.get(self.selected_category, []):
                selected = name == self.selected_example_name
                clicked, _ = imgui.selectable(name, selected)
                if clicked:
                    self.selected_example_name = name
                if imgui.is_item_hovered() and imgui.is_mouse_double_clicked(0):
                    self.selected_example_name = name
                    self.load_example(name)
        imgui.end()

    def _render_inspector(self, imgui, display_w: float, display_h: float) -> None:
        flags = self._window_flags(imgui, movable=False)
        x = display_w - self._right_width
        imgui.set_next_window_pos(imgui.ImVec2(x, self._top_height))
        imgui.set_next_window_size(imgui.ImVec2(self._right_width, display_h - self._top_height - self._bottom_height))
        if imgui.begin("Inspector", flags=flags):
            if imgui.button("Collapse"):
                self._inspector_visible = False
                imgui.end()
                return
            imgui.separator()
            if self.eval_mode:
                imgui.text_disabled("HUD Eval")
                imgui.text(f"Scene: {self.eval_scene or '—'}")
                imgui.text(f"Step: {self.eval_step}     t = {self.eval_time:.3f} s")
                imgui.separator()
            imgui.text_disabled("Scene")
            imgui.separator()

            if self.current_example is None:
                if self.current_static_state is None:
                    imgui.text_wrapped("No simulation loaded.")
                else:
                    imgui.text(f"Scene: {self.current_example_name}")
                    model = self.viewer.model
                    if model is not None:
                        imgui.separator()
                        imgui.text(f"Bodies: {model.body_count}")
                        imgui.text(f"Shapes: {model.shape_count}")
                        imgui.text(f"Joints: {model.joint_count}")
                        imgui.text(f"Particles: {model.particle_count}")
                        imgui.text(f"Triangles: {model.tri_count}")
                        imgui.text(f"Tetrahedra: {model.tet_count}")
                    self._render_source_summary(imgui)
                    self._render_physics_summary(imgui)
                    self._render_joint_drives(imgui)
            else:
                imgui.text(f"Example: {self.current_example_name}")
                if self.current_module_path:
                    imgui.text_wrapped(f"Module: {self.current_module_path}")
                model = getattr(self.current_example, "model", None)
                if model is not None:
                    imgui.separator()
                    imgui.text(f"Bodies: {model.body_count}")
                    imgui.text(f"Shapes: {model.shape_count}")
                    imgui.text(f"Joints: {model.joint_count}")
                    imgui.text(f"Particles: {model.particle_count}")
                    imgui.text(f"Triangles: {model.tri_count}")
                    imgui.text(f"Tetrahedra: {model.tet_count}")

            imgui.separator()
            if imgui.collapsing_header("Viewport", flags=imgui.TreeNodeFlags_.default_open.value):
                changed, self.viewer.show_visual = imgui.checkbox("Visuals", self.viewer.show_visual)
                self.imported_render_dirty = self.imported_render_dirty or bool(changed)
                changed, self.viewer.show_collision = imgui.checkbox("Collision", self.viewer.show_collision)
                self.imported_render_dirty = self.imported_render_dirty or bool(changed)
                changed, self.viewer.show_joints = imgui.checkbox("Joints", self.viewer.show_joints)
                self.imported_render_dirty = self.imported_render_dirty or bool(changed)
                changed, self.viewer.show_contacts = imgui.checkbox("Contacts", self.viewer.show_contacts)
                self.imported_render_dirty = self.imported_render_dirty or bool(changed)
                changed, self.viewer.show_particles = imgui.checkbox("Particles", self.viewer.show_particles)
                self.imported_render_dirty = self.imported_render_dirty or bool(changed)
                _, self.viewer.renderer.draw_shadows = imgui.checkbox("Shadows", self.viewer.renderer.draw_shadows)
                _, self.viewer.renderer.draw_sky = imgui.checkbox("Sky", self.viewer.renderer.draw_sky)
                _, self.viewer.renderer.draw_wireframe = imgui.checkbox("Wireframe", self.viewer.renderer.draw_wireframe)

            if self.example_side_callback is not None:
                imgui.separator()
                if imgui.collapsing_header("Example Controls", flags=imgui.TreeNodeFlags_.default_open.value):
                    self.example_side_callback(imgui)

            imgui.separator()
            if imgui.collapsing_header("Log", flags=imgui.TreeNodeFlags_.default_open.value):
                if imgui.button("Copy Logs"):
                    self._copy_logs_to_clipboard(imgui)
                imgui.same_line()
                imgui.text_disabled("Right-click any log line for copy options.")
                for index, message in enumerate(self.messages[-12:]):
                    if message.level == "error":
                        imgui.push_style_color(imgui.Col_.text, imgui.ImVec4(1.0, 0.38, 0.38, 1.0))
                        imgui.text(message.title)
                        imgui.pop_style_color()
                    else:
                        imgui.text(message.title)
                    self._render_log_context_menu(imgui, f"log_title_{index}")
                    imgui.text_wrapped(message.detail)
                    self._render_log_context_menu(imgui, f"log_detail_{index}")
                    imgui.spacing()
        imgui.end()

    def _logs_text(self) -> str:
        return "\n".join(f"[{message.level.upper()}] {message.title}\n{message.detail}" for message in self.messages)

    def _copy_logs_to_clipboard(self, imgui) -> None:
        text = self._logs_text()
        try:
            subprocess.run(["pbcopy"], input=text, text=True, check=True)
            return
        except Exception:
            pass
        imgui.set_clipboard_text(text)

    def _render_log_context_menu(self, imgui, popup_id: str) -> None:
        if imgui.begin_popup_context_item(popup_id):
            if imgui.menu_item_simple("Copy All Logs"):
                self._copy_logs_to_clipboard(imgui)
                imgui.close_current_popup()
            imgui.end_popup()

    def _render_source_summary(self, imgui) -> None:
        summary = self.current_source_summary
        if summary is None:
            return
        imgui.separator()
        if imgui.collapsing_header("Source Fidelity", flags=imgui.TreeNodeFlags_.default_open.value):
            imgui.text(f"Format: {summary.kind.upper()}")
            imgui.text(f"Meshes: {summary.meshes}")
            if summary.inline_meshes:
                imgui.text(f"Inline meshes prepared: {summary.inline_meshes}")
            imgui.text(f"Textures: {summary.textures}")
            imgui.text(f"Missing texture files: {summary.missing_textures}")
            imgui.text(f"Materials: {summary.materials}")
            imgui.text(f"Lights: {summary.lights}")
            imgui.text(f"Authored joints: {summary.joints}")
            if summary.articulations:
                imgui.text(f"Articulation roots: {summary.articulations}")
            if summary.lights:
                imgui.text_wrapped("Authored lights are detected. USD distant lights are mapped into the realtime viewport light; other light types are approximated by ambient fill for now.")

    def _render_physics_summary(self, imgui) -> None:
        summary = self.imported_physics_summary
        if summary is None:
            return
        imgui.separator()
        if imgui.collapsing_header("Physics", flags=imgui.TreeNodeFlags_.default_open.value):
            imgui.text(f"Solver: {summary.solver}")
            if summary.gravity is not None:
                gx, gy, gz = summary.gravity
                imgui.text(f"Gravity: {gx:.2f}, {gy:.2f}, {gz:.2f}")
            imgui.text(f"Dynamic bodies: {summary.dynamic_bodies}")
            imgui.text(f"Static bodies: {summary.static_bodies}")
            if summary.mass_range is not None:
                lo, hi = summary.mass_range
                imgui.text(f"Mass range: {lo:.3g} - {hi:.3g}")
            if summary.friction_range is not None:
                lo, hi = summary.friction_range
                imgui.text(f"Friction range: {lo:.3g} - {hi:.3g}")
            if summary.restitution_range is not None:
                lo, hi = summary.restitution_range
                imgui.text(f"Restitution range: {lo:.3g} - {hi:.3g}")
            imgui.text(f"Visual shapes: {summary.visual_shapes}")
            imgui.text(f"Collision shapes: {summary.collision_shapes}")
            imgui.text(f"Visual-only shapes: {summary.visual_only_shapes}")
            imgui.text(f"Collision-only shapes: {summary.collision_only_shapes}")
            imgui.text(f"Visual+collision shapes: {summary.visual_collision_shapes}")
            if summary.disabled_joints:
                imgui.text(f"Disabled joints: {summary.disabled_joints}")

    def _render_joint_drives(self, imgui) -> None:
        if not self.imported_joint_controls:
            return
        imgui.separator()
        if imgui.collapsing_header("Joint Drives", flags=imgui.TreeNodeFlags_.default_open.value):
            if self.selected_joint_control is not None:
                imgui.text(f"Selected: {self.selected_joint_control.label}")
            if self.eval_mode:
                imgui.text_wrapped("Joints are driven by the agent during the eval. Right-click a part to inspect it; these controls are read-only here.")
            else:
                imgui.text_wrapped("Right-click a movable part to select it. Right-drag a selected joint to articulate, or right-drag a selected free body to move it. Hold Shift while right-dragging a body for pure vertical lift.")
                changed, step_hz = imgui.slider_float("Sim Hz", float(self.imported_step_hz), 1.0, 60.0, "%.0f")
                if changed:
                    self.imported_step_hz = float(step_hz)
                changed, substeps = imgui.slider_int("Substeps", int(self.imported_sim_substeps), 1, 12)
                if changed:
                    self.imported_sim_substeps = int(substeps)
            imgui.begin_disabled(self.eval_mode)
            for control in self.imported_joint_controls[:24]:
                label = f"{control.label} ({control.kind.lower()})"
                changed, value = imgui.slider_float(label, control.target, control.lower, control.upper, "%.3f")
                if changed:
                    self._set_joint_control_target(control, float(value))
            imgui.end_disabled()
            if len(self.imported_joint_controls) > 24:
                imgui.text_disabled(f"{len(self.imported_joint_controls) - 24} more controllable joints hidden for now.")

    def _render_bottom_bar(self, imgui, display_w: float, display_h: float) -> None:
        flags = self._window_flags(imgui, movable=False)
        imgui.set_next_window_pos(imgui.ImVec2(0, display_h - self._bottom_height))
        imgui.set_next_window_size(imgui.ImVec2(display_w, self._bottom_height))
        if imgui.begin("##gizmo_status", flags=flags):
            status = self.messages[-1] if self.messages else GizmoMessage("Ready", "")
            imgui.text_disabled(status.title)
            imgui.same_line()
            imgui.text(status.detail[:180])
        imgui.end()

    def _push_message(self, title: str, detail: str, level: str = "info") -> None:
        self.messages.append(GizmoMessage(title, detail, level))
        self.messages = self.messages[-20:]

    @staticmethod
    def _group_examples(examples: tuple[ExampleRecord, ...]) -> dict[str, list[str]]:
        groups: dict[str, list[str]] = {}
        for example in examples:
            groups.setdefault(example.category, []).append(example.name)
        return dict(sorted((category, sorted(names)) for category, names in groups.items()))

    @staticmethod
    def _window_flags(imgui, *, movable: bool) -> int:
        flags = (
            imgui.WindowFlags_.no_collapse.value
            | imgui.WindowFlags_.no_saved_settings.value
            | imgui.WindowFlags_.no_bring_to_front_on_focus.value
        )
        if not movable:
            flags |= imgui.WindowFlags_.no_move.value | imgui.WindowFlags_.no_resize.value
        return flags


def main(argv: list[str] | None = None) -> int:
    del argv
    wp.config.kernel_cache_dir = str((PROJECT_ROOT / ".cache" / "warp").resolve())
    catalog = NewtonCatalog.discover()
    viewer = GizmoViewer(width=1600, height=1000, vsync=True, headless=False)
    app = GizmoGLApp(catalog, viewer)
    app.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
