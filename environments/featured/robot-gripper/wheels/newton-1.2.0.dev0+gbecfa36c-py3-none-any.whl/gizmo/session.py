"""Project and session files for Gizmo workspaces."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


PROJECT_FILE = "gizmo.project.json"


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


@dataclass(frozen=True, slots=True)
class GizmoProject:
    """A durable Gizmo workspace descriptor."""

    name: str
    root: Path
    created_at: str
    version: int = 1

    @property
    def project_file(self) -> Path:
        return self.root / PROJECT_FILE

    @property
    def scenes_dir(self) -> Path:
        return self.root / "scenes"

    @property
    def experiments_dir(self) -> Path:
        return self.root / "experiments"

    @property
    def outputs_dir(self) -> Path:
        return self.root / "outputs"

    @property
    def logs_dir(self) -> Path:
        return self.root / "logs"

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["root"] = str(self.root)
        return data

    def write(self) -> None:
        self.project_file.write_text(json.dumps(self.to_dict(), indent=2, sort_keys=True) + "\n")

    @classmethod
    def from_file(cls, path: str | Path) -> "GizmoProject":
        project_path = Path(path).expanduser().resolve()
        if project_path.is_dir():
            project_path = project_path / PROJECT_FILE
        data = json.loads(project_path.read_text())
        return cls(
            name=str(data["name"]),
            root=Path(data["root"]).expanduser().resolve(),
            created_at=str(data["created_at"]),
            version=int(data.get("version", 1)),
        )


@dataclass(slots=True)
class GizmoSession:
    """A saved app/runtime session."""

    project: str
    scene_path: str | None = None
    selected_body: str | None = None
    selected_joint: str | None = None
    camera: dict[str, Any] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)
    created_at: str = field(default_factory=utc_now_iso)
    version: int = 1

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def write(self, path: str | Path) -> Path:
        session_path = Path(path).expanduser().resolve()
        session_path.parent.mkdir(parents=True, exist_ok=True)
        session_path.write_text(json.dumps(self.to_dict(), indent=2, sort_keys=True) + "\n")
        return session_path


def init_project(root: str | Path, *, name: str | None = None) -> GizmoProject:
    """Create a Gizmo project folder with standard subdirectories."""

    project_root = Path(root).expanduser().resolve()
    project_root.mkdir(parents=True, exist_ok=True)
    for dirname in ("scenes", "experiments", "outputs", "logs"):
        (project_root / dirname).mkdir(exist_ok=True)
    project = GizmoProject(name=name or project_root.name, root=project_root, created_at=utc_now_iso())
    project.write()
    readme = project_root / "README.md"
    if not readme.exists():
        readme.write_text(
            "# Gizmo Project\n\n"
            "- `scenes/`: authored USD/MJCF/XML assets.\n"
            "- `experiments/`: experiment configs and results.\n"
            "- `outputs/`: generated USD, videos, checkpoints, and metrics.\n"
            "- `logs/`: runtime logs.\n"
        )
    return project
