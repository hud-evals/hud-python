"""Optional Gymnasium-compatible wrappers for Gizmo scenes."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .runtime import RuntimeConfig, import_model, _build_solver


class GizmoSceneEnv:
    """Minimal Gymnasium-style scene environment.

    The first RL milestone is a stable API boundary. This environment exposes a
    no-op action interface and body-position observations; task-specific reward
    functions and action adapters can subclass it.
    """

    metadata = {"render_modes": []}

    def __init__(self, scene_path: str | Path, *, dt: float = 1.0 / 240.0, backend: str = "auto") -> None:
        try:
            import gymnasium as gym
            from gymnasium import spaces
            import numpy as np
        except Exception as exc:  # noqa: BLE001
            raise RuntimeError("Install gymnasium to use GizmoSceneEnv.") from exc

        self._gym = gym
        self._spaces = spaces
        self._np = np
        self.scene_path = Path(scene_path).expanduser().resolve()
        self.dt = float(dt)
        self.backend = backend
        self.model = None
        self.state_0 = None
        self.state_1 = None
        self.control = None
        self.solver = None
        self.contacts = None
        self.use_mujoco_cpu = False
        self.action_space = spaces.Discrete(1)
        self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(1,), dtype=np.float32)

    def reset(self, *, seed: int | None = None, options: dict[str, Any] | None = None):
        del options
        if seed is not None:
            self._np.random.seed(seed)
        import newton

        self.model, kind, _metadata, _warnings = import_model(self.scene_path)
        self.state_0 = self.model.state()
        self.state_1 = self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.solver, _name, self.use_mujoco_cpu, self.contacts = _build_solver(self.model, kind, self.backend)
        obs = self._observe()
        self.observation_space = self._spaces.Box(low=-self._np.inf, high=self._np.inf, shape=obs.shape, dtype=self._np.float32)
        return obs, {}

    def step(self, action):
        del action
        if self.model is None or self.solver is None or self.state_0 is None or self.state_1 is None or self.control is None:
            raise RuntimeError("Call reset() before step().")
        if self.contacts is not None and not self.use_mujoco_cpu:
            self.model.collide(self.state_0, self.contacts)
        self.state_0.clear_forces()
        self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.dt)
        self.state_0, self.state_1 = self.state_1, self.state_0
        obs = self._observe()
        return obs, 0.0, False, False, {}

    def close(self) -> None:
        self.model = None
        self.solver = None

    def _observe(self):
        if self.state_0 is None or getattr(self.state_0, "body_q", None) is None:
            return self._np.zeros((1,), dtype=self._np.float32)
        body_q = self.state_0.body_q.numpy()
        return self._np.asarray(body_q[:, 0:3], dtype=self._np.float32).reshape(-1)


def make_env(scene_path: str | Path, **kwargs: Any) -> GizmoSceneEnv:
    return GizmoSceneEnv(scene_path, **kwargs)
