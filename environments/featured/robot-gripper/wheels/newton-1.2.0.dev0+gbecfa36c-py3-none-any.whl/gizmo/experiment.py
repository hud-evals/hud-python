"""Experiment launcher for headless Gizmo simulations."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from .runtime import RuntimeConfig, RuntimeResult, run_headless
from .session import utc_now_iso


@dataclass(frozen=True, slots=True)
class ExperimentConfig:
    name: str
    scene_path: Path
    output_dir: Path
    steps: int = 240
    dt: float = 1.0 / 240.0
    substeps: int = 1
    seed: int = 0
    backend: str = "auto"

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["scene_path"] = str(self.scene_path)
        data["output_dir"] = str(self.output_dir)
        return data


def run_experiment(config: ExperimentConfig) -> RuntimeResult:
    """Run one experiment and write reproducible artifacts."""

    run_id = f"{utc_now_iso().replace(':', '').replace('-', '')}_{config.name}"
    run_dir = config.output_dir.expanduser().resolve() / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "config.json").write_text(json.dumps(config.to_dict(), indent=2, sort_keys=True) + "\n")
    runtime_config = RuntimeConfig(
        scene_path=config.scene_path,
        steps=config.steps,
        dt=config.dt,
        substeps=config.substeps,
        backend=config.backend,
        output_dir=run_dir,
    )
    result = run_headless(runtime_config)
    with (run_dir / "metrics.jsonl").open("w") as file:
        for sample in result.samples:
            file.write(json.dumps(asdict(sample), sort_keys=True) + "\n")
    return result
