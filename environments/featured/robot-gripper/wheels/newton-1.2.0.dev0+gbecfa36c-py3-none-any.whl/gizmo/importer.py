"""Scene import and summary services for Gizmo."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
import warnings


SUPPORTED_IMPORT_SUFFIXES = {".usd", ".usda", ".usdc", ".xml", ".mjcf", ".njcf"}
PROJECT_ROOT = Path(__file__).resolve().parents[1]


@dataclass(frozen=True, slots=True)
class ImportedScene:
    """Summary of a scene imported into a Newton ModelBuilder."""

    path: Path
    kind: str
    body_count: int
    joint_count: int
    shape_count: int
    particle_count: int
    articulation_count: int
    world_count: int
    metadata: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": str(self.path),
            "kind": self.kind,
            "body_count": self.body_count,
            "joint_count": self.joint_count,
            "shape_count": self.shape_count,
            "particle_count": self.particle_count,
            "articulation_count": self.articulation_count,
            "world_count": self.world_count,
            "metadata": self.metadata,
        }


def inspect_scene(path: str | Path) -> ImportedScene:
    """Import a USD/MJCF/NJCF file into Newton and return structural counts."""

    scene_path = Path(path).expanduser().resolve()
    if not scene_path.exists():
        raise FileNotFoundError(scene_path)
    if scene_path.suffix.lower() not in SUPPORTED_IMPORT_SUFFIXES:
        raise ValueError(f"Unsupported scene type: {scene_path.suffix}")

    import warp as wp

    wp.config.kernel_cache_dir = str((PROJECT_ROOT / ".cache" / "warp").resolve())

    import newton

    builder = newton.ModelBuilder()
    kind = _scene_kind(scene_path)
    result: Any

    with warnings.catch_warnings(record=True) as caught_warnings:
        warnings.simplefilter("always")
        if kind == "USD":
            result = builder.add_usd(str(scene_path), skip_mesh_approximation=True)
        else:
            result = builder.add_mjcf(str(scene_path), parse_meshes=True)

    metadata = _clean_metadata(result)
    if caught_warnings:
        metadata["warnings"] = [str(item.message) for item in caught_warnings]
    return ImportedScene(
        path=scene_path,
        kind=kind,
        body_count=builder.body_count,
        joint_count=builder.joint_count,
        shape_count=builder.shape_count,
        particle_count=builder.particle_count,
        articulation_count=builder.articulation_count,
        world_count=builder.world_count,
        metadata=metadata,
    )


def _scene_kind(path: Path) -> str:
    if path.suffix.lower() in {".usd", ".usda", ".usdc"}:
        return "USD"
    return "MJCF"


def _clean_metadata(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        return {}

    allowed_keys = {
        "fps",
        "duration",
        "up_axis",
        "mass_unit",
        "linear_unit",
        "physics_dt",
        "max_solver_iterations",
        "actuator_count",
    }
    clean: dict[str, Any] = {}
    for key in allowed_keys:
        if key not in value:
            continue
        item = value[key]
        if isinstance(item, (str, int, float, bool)) or item is None:
            clean[key] = item
        else:
            clean[key] = str(item)
    return clean
