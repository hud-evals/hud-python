"""Subprocess runner for Newton examples."""

from __future__ import annotations

import os
import queue
import subprocess
import sys
import threading
from pathlib import Path


class NewtonProcessRunner:
    """Runs one Newton simulation process at a time and streams output."""

    def __init__(self, project_root: Path | None = None) -> None:
        self.project_root = Path(project_root or Path(__file__).resolve().parents[1]).resolve()
        self.output: queue.Queue[str] = queue.Queue()
        self._process: subprocess.Popen[str] | None = None
        self._lock = threading.Lock()

    @property
    def is_running(self) -> bool:
        with self._lock:
            return self._process is not None and self._process.poll() is None

    def run_example(
        self,
        example_name: str,
        *,
        viewer: str,
        num_frames: int,
        output_path: Path | None = None,
    ) -> None:
        if self.is_running:
            raise RuntimeError("A simulation is already running.")
        if output_path is not None:
            output_path.parent.mkdir(parents=True, exist_ok=True)

        command = [
            sys.executable,
            "-m",
            "newton.examples",
            example_name,
            "--viewer",
            viewer,
            "--num-frames",
            str(num_frames),
            "--warp-config",
            f"kernel_cache_dir={str((self.project_root / '.cache' / 'warp').resolve())!r}",
        ]
        if output_path is not None:
            command.extend(["--output-path", str(output_path)])

        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"
        existing_pythonpath = env.get("PYTHONPATH")
        env["PYTHONPATH"] = (
            str(self.project_root)
            if not existing_pythonpath
            else os.pathsep.join((str(self.project_root), existing_pythonpath))
        )

        process = subprocess.Popen(
            command,
            cwd=self.project_root,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )

        with self._lock:
            self._process = process

        self.output.put(f"$ {' '.join(command)}\n")
        threading.Thread(target=self._stream_output, args=(process,), daemon=True).start()

    def stop(self) -> None:
        with self._lock:
            process = self._process
        if process is None or process.poll() is not None:
            return
        process.terminate()

    def _stream_output(self, process: subprocess.Popen[str]) -> None:
        assert process.stdout is not None
        for line in process.stdout:
            self.output.put(line)
        code = process.wait()
        self.output.put(f"\n[process exited with code {code}]\n")
        with self._lock:
            if self._process is process:
                self._process = None
